package com.beroutes.aa.repository.search;

import com.beroutes.aa.domain.Valuation;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

/**
 * Spring Data Elasticsearch repository for the {@link Valuation} entity.
 */
public interface ValuationSearchRepository extends ElasticsearchRepository<Valuation, Long> {
}
