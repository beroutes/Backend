/**
 * View Models used by Spring MVC REST controllers.
 */
package com.beroutes.aa.web.rest.vm;
