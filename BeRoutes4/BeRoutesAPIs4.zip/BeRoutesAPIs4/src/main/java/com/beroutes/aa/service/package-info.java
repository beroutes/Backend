/**
 * Service layer beans.
 */
package com.beroutes.aa.service;
