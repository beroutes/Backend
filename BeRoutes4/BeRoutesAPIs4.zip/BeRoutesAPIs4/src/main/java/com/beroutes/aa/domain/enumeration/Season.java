package com.beroutes.aa.domain.enumeration;

/**
 * The Season enumeration.
 */
public enum Season {
    SPRING, SUMMER, AUTUMN, WINTER
}
