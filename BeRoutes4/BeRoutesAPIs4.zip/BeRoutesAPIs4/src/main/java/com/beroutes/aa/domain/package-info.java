/**
 * JPA domain objects.
 */
package com.beroutes.aa.domain;
