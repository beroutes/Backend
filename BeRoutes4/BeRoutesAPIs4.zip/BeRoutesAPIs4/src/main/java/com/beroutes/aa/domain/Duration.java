package com.beroutes.aa.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;

import org.springframework.data.elasticsearch.annotations.FieldType;
import java.io.Serializable;
import java.util.Objects;

/**
 * A Duration.
 */
@Entity
@Table(name = "duration")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@org.springframework.data.elasticsearch.annotations.Document(indexName = "duration")
public class Duration implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "description_duration")
    private String descriptionDuration;

    @Column(name = "minutes")
    private Integer minutes;

    @Column(name = "hours")
    private Integer hours;

    @Column(name = "days")
    private Integer days;

    @Column(name = "weeks")
    private Integer weeks;

    @Column(name = "years")
    private Integer years;

    @OneToOne(mappedBy = "duration")
    @JsonIgnore
    private Location location;

    @OneToOne(mappedBy = "duration")
    @JsonIgnore
    private TravelRoute travelRoute;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescriptionDuration() {
        return descriptionDuration;
    }

    public Duration descriptionDuration(String descriptionDuration) {
        this.descriptionDuration = descriptionDuration;
        return this;
    }

    public void setDescriptionDuration(String descriptionDuration) {
        this.descriptionDuration = descriptionDuration;
    }

    public Integer getMinutes() {
        return minutes;
    }

    public Duration minutes(Integer minutes) {
        this.minutes = minutes;
        return this;
    }

    public void setMinutes(Integer minutes) {
        this.minutes = minutes;
    }

    public Integer getHours() {
        return hours;
    }

    public Duration hours(Integer hours) {
        this.hours = hours;
        return this;
    }

    public void setHours(Integer hours) {
        this.hours = hours;
    }

    public Integer getDays() {
        return days;
    }

    public Duration days(Integer days) {
        this.days = days;
        return this;
    }

    public void setDays(Integer days) {
        this.days = days;
    }

    public Integer getWeeks() {
        return weeks;
    }

    public Duration weeks(Integer weeks) {
        this.weeks = weeks;
        return this;
    }

    public void setWeeks(Integer weeks) {
        this.weeks = weeks;
    }

    public Integer getYears() {
        return years;
    }

    public Duration years(Integer years) {
        this.years = years;
        return this;
    }

    public void setYears(Integer years) {
        this.years = years;
    }

    public Location getLocation() {
        return location;
    }

    public Duration location(Location location) {
        this.location = location;
        return this;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public TravelRoute getTravelRoute() {
        return travelRoute;
    }

    public Duration travelRoute(TravelRoute travelRoute) {
        this.travelRoute = travelRoute;
        return this;
    }

    public void setTravelRoute(TravelRoute travelRoute) {
        this.travelRoute = travelRoute;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Duration)) {
            return false;
        }
        return id != null && id.equals(((Duration) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "Duration{" +
            "id=" + getId() +
            ", descriptionDuration='" + getDescriptionDuration() + "'" +
            ", minutes=" + getMinutes() +
            ", hours=" + getHours() +
            ", days=" + getDays() +
            ", weeks=" + getWeeks() +
            ", years=" + getYears() +
            "}";
    }
}
