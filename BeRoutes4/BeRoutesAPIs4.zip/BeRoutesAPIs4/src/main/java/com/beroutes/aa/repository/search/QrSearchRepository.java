package com.beroutes.aa.repository.search;

import com.beroutes.aa.domain.Qr;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

/**
 * Spring Data Elasticsearch repository for the {@link Qr} entity.
 */
public interface QrSearchRepository extends ElasticsearchRepository<Qr, Long> {
}
