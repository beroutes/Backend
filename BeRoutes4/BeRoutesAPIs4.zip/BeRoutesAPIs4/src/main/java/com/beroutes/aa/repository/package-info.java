/**
 * Spring Data JPA repositories.
 */
package com.beroutes.aa.repository;
