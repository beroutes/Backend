/**
 * MapStruct mappers for mapping domain objects and Data Transfer Objects.
 */
package com.beroutes.aa.service.mapper;
