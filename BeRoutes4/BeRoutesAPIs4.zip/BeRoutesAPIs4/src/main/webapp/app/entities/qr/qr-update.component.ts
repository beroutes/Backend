import { Component, OnInit } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';

import { IQr, Qr } from 'app/shared/model/qr.model';
import { QrService } from './qr.service';

@Component({
  selector: 'jhi-qr-update',
  templateUrl: './qr-update.component.html'
})
export class QrUpdateComponent implements OnInit {
  isSaving = false;

  editForm = this.fb.group({
    id: [],
    data1: [],
    data2: [],
    data3: []
  });

  constructor(protected qrService: QrService, protected activatedRoute: ActivatedRoute, private fb: FormBuilder) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ qr }) => {
      this.updateForm(qr);
    });
  }

  updateForm(qr: IQr): void {
    this.editForm.patchValue({
      id: qr.id,
      data1: qr.data1,
      data2: qr.data2,
      data3: qr.data3
    });
  }

  previousState(): void {
    window.history.back();
  }

  save(): void {
    this.isSaving = true;
    const qr = this.createFromForm();
    if (qr.id !== undefined) {
      this.subscribeToSaveResponse(this.qrService.update(qr));
    } else {
      this.subscribeToSaveResponse(this.qrService.create(qr));
    }
  }

  private createFromForm(): IQr {
    return {
      ...new Qr(),
      id: this.editForm.get(['id'])!.value,
      data1: this.editForm.get(['data1'])!.value,
      data2: this.editForm.get(['data2'])!.value,
      data3: this.editForm.get(['data3'])!.value
    };
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<IQr>>): void {
    result.subscribe(
      () => this.onSaveSuccess(),
      () => this.onSaveError()
    );
  }

  protected onSaveSuccess(): void {
    this.isSaving = false;
    this.previousState();
  }

  protected onSaveError(): void {
    this.isSaving = false;
  }
}
