import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

@NgModule({
  imports: [
    RouterModule.forChild([
      {
        path: 'region',
        loadChildren: () => import('./region/region.module').then(m => m.BeRoutesAaRegionModule)
      },
      {
        path: 'city',
        loadChildren: () => import('./city/city.module').then(m => m.BeRoutesAaCityModule)
      },
      {
        path: 'country',
        loadChildren: () => import('./country/country.module').then(m => m.BeRoutesAaCountryModule)
      },
      {
        path: 'location',
        loadChildren: () => import('./location/location.module').then(m => m.BeRoutesAaLocationModule)
      },
      {
        path: 'travel-route',
        loadChildren: () => import('./travel-route/travel-route.module').then(m => m.BeRoutesAaTravelRouteModule)
      },
      {
        path: 'user-profile',
        loadChildren: () => import('./user-profile/user-profile.module').then(m => m.BeRoutesAaUserProfileModule)
      },
      {
        path: 'follower',
        loadChildren: () => import('./follower/follower.module').then(m => m.BeRoutesAaFollowerModule)
      },
      {
        path: 'duration',
        loadChildren: () => import('./duration/duration.module').then(m => m.BeRoutesAaDurationModule)
      },
      {
        path: 'category',
        loadChildren: () => import('./category/category.module').then(m => m.BeRoutesAaCategoryModule)
      },
      {
        path: 'photo',
        loadChildren: () => import('./photo/photo.module').then(m => m.BeRoutesAaPhotoModule)
      },
      {
        path: 'valuation',
        loadChildren: () => import('./valuation/valuation.module').then(m => m.BeRoutesAaValuationModule)
      },
      {
        path: 'qr',
        loadChildren: () => import('./qr/qr.module').then(m => m.BeRoutesAaQrModule)
      }
      /* jhipster-needle-add-entity-route - JHipster will add entity modules routes here */
    ])
  ]
})
export class BeRoutesAaEntityModule {}
