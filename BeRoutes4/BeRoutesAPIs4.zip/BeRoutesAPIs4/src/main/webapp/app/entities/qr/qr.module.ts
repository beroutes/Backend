import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { BeRoutesAaSharedModule } from 'app/shared/shared.module';
import { QrComponent } from './qr.component';
import { QrDetailComponent } from './qr-detail.component';
import { QrUpdateComponent } from './qr-update.component';
import { QrDeleteDialogComponent } from './qr-delete-dialog.component';
import { qrRoute } from './qr.route';

@NgModule({
  imports: [BeRoutesAaSharedModule, RouterModule.forChild(qrRoute)],
  declarations: [QrComponent, QrDetailComponent, QrUpdateComponent, QrDeleteDialogComponent],
  entryComponents: [QrDeleteDialogComponent]
})
export class BeRoutesAaQrModule {}
