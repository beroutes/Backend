import { Component, OnInit } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';

import { IFollower, Follower } from 'app/shared/model/follower.model';
import { FollowerService } from './follower.service';
import { IUserProfile } from 'app/shared/model/user-profile.model';
import { UserProfileService } from 'app/entities/user-profile/user-profile.service';

@Component({
  selector: 'jhi-follower-update',
  templateUrl: './follower-update.component.html'
})
export class FollowerUpdateComponent implements OnInit {
  isSaving = false;
  userprofiles: IUserProfile[] = [];

  editForm = this.fb.group({
    id: [],
    accepted: [],
    userProfile: []
  });

  constructor(
    protected followerService: FollowerService,
    protected userProfileService: UserProfileService,
    protected activatedRoute: ActivatedRoute,
    private fb: FormBuilder
  ) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ follower }) => {
      this.updateForm(follower);

      this.userProfileService.query().subscribe((res: HttpResponse<IUserProfile[]>) => (this.userprofiles = res.body || []));
    });
  }

  updateForm(follower: IFollower): void {
    this.editForm.patchValue({
      id: follower.id,
      accepted: follower.accepted,
      userProfile: follower.userProfile
    });
  }

  previousState(): void {
    window.history.back();
  }

  save(): void {
    this.isSaving = true;
    const follower = this.createFromForm();
    if (follower.id !== undefined) {
      this.subscribeToSaveResponse(this.followerService.update(follower));
    } else {
      this.subscribeToSaveResponse(this.followerService.create(follower));
    }
  }

  private createFromForm(): IFollower {
    return {
      ...new Follower(),
      id: this.editForm.get(['id'])!.value,
      accepted: this.editForm.get(['accepted'])!.value,
      userProfile: this.editForm.get(['userProfile'])!.value
    };
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<IFollower>>): void {
    result.subscribe(
      () => this.onSaveSuccess(),
      () => this.onSaveError()
    );
  }

  protected onSaveSuccess(): void {
    this.isSaving = false;
    this.previousState();
  }

  protected onSaveError(): void {
    this.isSaving = false;
  }

  trackById(index: number, item: IUserProfile): any {
    return item.id;
  }
}
