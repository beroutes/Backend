import { IUserProfile } from 'app/shared/model/user-profile.model';

export interface IFollower {
  id?: number;
  accepted?: boolean;
  userProfile?: IUserProfile;
}

export class Follower implements IFollower {
  constructor(public id?: number, public accepted?: boolean, public userProfile?: IUserProfile) {
    this.accepted = this.accepted || false;
  }
}
