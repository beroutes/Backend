import { ILocation } from 'app/shared/model/location.model';

export interface IQr {
  id?: number;
  data1?: number;
  data2?: number;
  data3?: number;
  location?: ILocation;
}

export class Qr implements IQr {
  constructor(public id?: number, public data1?: number, public data2?: number, public data3?: number, public location?: ILocation) {}
}
