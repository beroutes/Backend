import { IRegion } from 'app/shared/model/region.model';
import { ICity } from 'app/shared/model/city.model';
import { ILocation } from 'app/shared/model/location.model';
import { IUserProfile } from 'app/shared/model/user-profile.model';

export interface ICountry {
  id?: number;
  countryName?: string;
  region?: IRegion;
  city?: ICity;
  location?: ILocation;
  userProfile?: IUserProfile;
}

export class Country implements ICountry {
  constructor(
    public id?: number,
    public countryName?: string,
    public region?: IRegion,
    public city?: ICity,
    public location?: ILocation,
    public userProfile?: IUserProfile
  ) {}
}
