/**
 * JPA domain objects.
 */
package com.beroutes.jh.domain;
