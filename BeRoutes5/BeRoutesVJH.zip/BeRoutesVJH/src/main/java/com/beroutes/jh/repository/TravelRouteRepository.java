package com.beroutes.jh.repository;

import com.beroutes.jh.domain.TravelRoute;

import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

/**
 * Spring Data  repository for the TravelRoute entity.
 */
@SuppressWarnings("unused")
@Repository
public interface TravelRouteRepository extends JpaRepository<TravelRoute, Long> {
}
