package com.beroutes.jh.repository.search;

import com.beroutes.jh.domain.TravelRoute;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

/**
 * Spring Data Elasticsearch repository for the {@link TravelRoute} entity.
 */
public interface TravelRouteSearchRepository extends ElasticsearchRepository<TravelRoute, Long> {
}
