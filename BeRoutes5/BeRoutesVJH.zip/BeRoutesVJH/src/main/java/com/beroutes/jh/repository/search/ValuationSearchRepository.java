package com.beroutes.jh.repository.search;

import com.beroutes.jh.domain.Valuation;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

/**
 * Spring Data Elasticsearch repository for the {@link Valuation} entity.
 */
public interface ValuationSearchRepository extends ElasticsearchRepository<Valuation, Long> {
}
