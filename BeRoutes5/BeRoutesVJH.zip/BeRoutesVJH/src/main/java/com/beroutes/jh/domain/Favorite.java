package com.beroutes.jh.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;

import org.springframework.data.elasticsearch.annotations.FieldType;
import java.io.Serializable;
import java.util.Objects;

/**
 * A Favorite.
 */
@Entity
@Table(name = "favorite")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@org.springframework.data.elasticsearch.annotations.Document(indexName = "favorite")
public class Favorite implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "jhi_like")
    private Boolean like;

    @Column(name = "not_like")
    private Boolean notLike;

    @ManyToOne
    @JsonIgnoreProperties("favorites")
    private TravelRoute travelRoute;

    @ManyToOne
    @JsonIgnoreProperties("favorites")
    private UserProfile userProfile;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Boolean isLike() {
        return like;
    }

    public Favorite like(Boolean like) {
        this.like = like;
        return this;
    }

    public void setLike(Boolean like) {
        this.like = like;
    }

    public Boolean isNotLike() {
        return notLike;
    }

    public Favorite notLike(Boolean notLike) {
        this.notLike = notLike;
        return this;
    }

    public void setNotLike(Boolean notLike) {
        this.notLike = notLike;
    }

    public TravelRoute getTravelRoute() {
        return travelRoute;
    }

    public Favorite travelRoute(TravelRoute travelRoute) {
        this.travelRoute = travelRoute;
        return this;
    }

    public void setTravelRoute(TravelRoute travelRoute) {
        this.travelRoute = travelRoute;
    }

    public UserProfile getUserProfile() {
        return userProfile;
    }

    public Favorite userProfile(UserProfile userProfile) {
        this.userProfile = userProfile;
        return this;
    }

    public void setUserProfile(UserProfile userProfile) {
        this.userProfile = userProfile;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Favorite)) {
            return false;
        }
        return id != null && id.equals(((Favorite) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "Favorite{" +
            "id=" + getId() +
            ", like='" + isLike() + "'" +
            ", notLike='" + isNotLike() + "'" +
            "}";
    }
}
