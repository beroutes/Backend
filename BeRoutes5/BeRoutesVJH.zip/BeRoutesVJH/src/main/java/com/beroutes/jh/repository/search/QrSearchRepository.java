package com.beroutes.jh.repository.search;

import com.beroutes.jh.domain.Qr;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

/**
 * Spring Data Elasticsearch repository for the {@link Qr} entity.
 */
public interface QrSearchRepository extends ElasticsearchRepository<Qr, Long> {
}
