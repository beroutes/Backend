package com.beroutes.jh.domain.enumeration;

/**
 * The CategoryTwo enumeration.
 */
public enum CategoryTwo {
    CHEAP, LUXURY, LONELY, FRIENDS, ROMANTIC, KIDS, SPORT, RELAXATION, ART, FOOD, NATURE, CITY
}
