package com.beroutes.jh.repository;

import com.beroutes.jh.domain.Qr;

import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

/**
 * Spring Data  repository for the Qr entity.
 */
@SuppressWarnings("unused")
@Repository
public interface QrRepository extends JpaRepository<Qr, Long> {
}
