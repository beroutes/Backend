/**
 * Spring Data Elasticsearch repositories.
 */
package com.beroutes.jh.repository.search;
