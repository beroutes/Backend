package com.beroutes.jh.repository.search;

import com.beroutes.jh.domain.Following;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

/**
 * Spring Data Elasticsearch repository for the {@link Following} entity.
 */
public interface FollowingSearchRepository extends ElasticsearchRepository<Following, Long> {
}
