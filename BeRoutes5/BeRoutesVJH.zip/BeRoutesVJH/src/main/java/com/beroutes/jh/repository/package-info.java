/**
 * Spring Data JPA repositories.
 */
package com.beroutes.jh.repository;
