package com.beroutes.jh.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;

import org.springframework.data.elasticsearch.annotations.FieldType;
import java.io.Serializable;
import java.util.Objects;
import java.util.HashSet;
import java.util.Set;

/**
 * A Following.
 */
@Entity
@Table(name = "following")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@org.springframework.data.elasticsearch.annotations.Document(indexName = "following")
public class Following implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "follow")
    private Boolean follow;

    @Column(name = "accepted")
    private Boolean accepted;

    @Column(name = "user_follower")
    private Long userFollower;

    @Column(name = "user_followed")
    private Long userFollowed;

    @OneToMany(mappedBy = "following")
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<UserProfile> userProfiles = new HashSet<>();

    @ManyToOne
    @JsonIgnoreProperties("followings")
    private UserProfile userProfile;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Boolean isFollow() {
        return follow;
    }

    public Following follow(Boolean follow) {
        this.follow = follow;
        return this;
    }

    public void setFollow(Boolean follow) {
        this.follow = follow;
    }

    public Boolean isAccepted() {
        return accepted;
    }

    public Following accepted(Boolean accepted) {
        this.accepted = accepted;
        return this;
    }

    public void setAccepted(Boolean accepted) {
        this.accepted = accepted;
    }

    public Long getUserFollower() {
        return userFollower;
    }

    public Following userFollower(Long userFollower) {
        this.userFollower = userFollower;
        return this;
    }

    public void setUserFollower(Long userFollower) {
        this.userFollower = userFollower;
    }

    public Long getUserFollowed() {
        return userFollowed;
    }

    public Following userFollowed(Long userFollowed) {
        this.userFollowed = userFollowed;
        return this;
    }

    public void setUserFollowed(Long userFollowed) {
        this.userFollowed = userFollowed;
    }

    public Set<UserProfile> getUserProfiles() {
        return userProfiles;
    }

    public Following userProfiles(Set<UserProfile> userProfiles) {
        this.userProfiles = userProfiles;
        return this;
    }

    public Following addUserProfile(UserProfile userProfile) {
        this.userProfiles.add(userProfile);
        userProfile.setFollowing(this);
        return this;
    }

    public Following removeUserProfile(UserProfile userProfile) {
        this.userProfiles.remove(userProfile);
        userProfile.setFollowing(null);
        return this;
    }

    public void setUserProfiles(Set<UserProfile> userProfiles) {
        this.userProfiles = userProfiles;
    }

    public UserProfile getUserProfile() {
        return userProfile;
    }

    public Following userProfile(UserProfile userProfile) {
        this.userProfile = userProfile;
        return this;
    }

    public void setUserProfile(UserProfile userProfile) {
        this.userProfile = userProfile;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Following)) {
            return false;
        }
        return id != null && id.equals(((Following) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "Following{" +
            "id=" + getId() +
            ", follow='" + isFollow() + "'" +
            ", accepted='" + isAccepted() + "'" +
            ", userFollower=" + getUserFollower() +
            ", userFollowed=" + getUserFollowed() +
            "}";
    }
}
