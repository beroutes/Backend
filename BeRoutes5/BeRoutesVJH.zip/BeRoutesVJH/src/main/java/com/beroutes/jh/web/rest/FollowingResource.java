package com.beroutes.jh.web.rest;

import com.beroutes.jh.domain.Following;
import com.beroutes.jh.service.FollowingService;
import com.beroutes.jh.web.rest.errors.BadRequestAlertException;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.PaginationUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * REST controller for managing {@link com.beroutes.jh.domain.Following}.
 */
@RestController
@RequestMapping("/api")
public class FollowingResource {

    private final Logger log = LoggerFactory.getLogger(FollowingResource.class);

    private static final String ENTITY_NAME = "following";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final FollowingService followingService;

    public FollowingResource(FollowingService followingService) {
        this.followingService = followingService;
    }

    /**
     * {@code POST  /followings} : Create a new following.
     *
     * @param following the following to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new following, or with status {@code 400 (Bad Request)} if the following has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("/followings")
    public ResponseEntity<Following> createFollowing(@RequestBody Following following) throws URISyntaxException {
        log.debug("REST request to save Following : {}", following);
        if (following.getId() != null) {
            throw new BadRequestAlertException("A new following cannot already have an ID", ENTITY_NAME, "idexists");
        }
        Following result = followingService.save(following);
        return ResponseEntity.created(new URI("/api/followings/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, false, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /followings} : Updates an existing following.
     *
     * @param following the following to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated following,
     * or with status {@code 400 (Bad Request)} if the following is not valid,
     * or with status {@code 500 (Internal Server Error)} if the following couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/followings")
    public ResponseEntity<Following> updateFollowing(@RequestBody Following following) throws URISyntaxException {
        log.debug("REST request to update Following : {}", following);
        if (following.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        Following result = followingService.save(following);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, false, ENTITY_NAME, following.getId().toString()))
            .body(result);
    }

    /**
     * {@code GET  /followings} : get all the followings.
     *
     * @param pageable the pagination information.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of followings in body.
     */
    @GetMapping("/followings")
    public ResponseEntity<List<Following>> getAllFollowings(Pageable pageable) {
        log.debug("REST request to get a page of Followings");
        Page<Following> page = followingService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(ServletUriComponentsBuilder.fromCurrentRequest(), page);
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * {@code GET  /followings/:id} : get the "id" following.
     *
     * @param id the id of the following to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the following, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/followings/{id}")
    public ResponseEntity<Following> getFollowing(@PathVariable Long id) {
        log.debug("REST request to get Following : {}", id);
        Optional<Following> following = followingService.findOne(id);
        return ResponseUtil.wrapOrNotFound(following);
    }

    /**
     * {@code DELETE  /followings/:id} : delete the "id" following.
     *
     * @param id the id of the following to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/followings/{id}")
    public ResponseEntity<Void> deleteFollowing(@PathVariable Long id) {
        log.debug("REST request to delete Following : {}", id);
        followingService.delete(id);
        return ResponseEntity.noContent().headers(HeaderUtil.createEntityDeletionAlert(applicationName, false, ENTITY_NAME, id.toString())).build();
    }

    /**
     * {@code SEARCH  /_search/followings?query=:query} : search for the following corresponding
     * to the query.
     *
     * @param query the query of the following search.
     * @param pageable the pagination information.
     * @return the result of the search.
     */
    @GetMapping("/_search/followings")
    public ResponseEntity<List<Following>> searchFollowings(@RequestParam String query, Pageable pageable) {
        log.debug("REST request to search for a page of Followings for query {}", query);
        Page<Following> page = followingService.search(query, pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(ServletUriComponentsBuilder.fromCurrentRequest(), page);
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }
}
