/**
 * Data Transfer Objects.
 */
package com.beroutes.jh.service.dto;
