package com.beroutes.jh.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;

import org.springframework.data.elasticsearch.annotations.FieldType;
import java.io.Serializable;
import java.util.Objects;

/**
 * A Photo.
 */
@Entity
@Table(name = "photo")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@org.springframework.data.elasticsearch.annotations.Document(indexName = "photo")
public class Photo implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "title_photo")
    private String titlePhoto;

    @Column(name = "description_photo")
    private String descriptionPhoto;

    @Column(name = "photo_main")
    private Boolean photoMain;

    @Column(name = "photo_map")
    private Boolean photoMap;

    @Column(name = "photo_location")
    private Boolean photoLocation;

    @Column(name = "url_photo")
    private String urlPhoto;

    @Column(name = "code_photo")
    private Integer codePhoto;

    @Lob
    @Column(name = "image_route")
    private byte[] imageRoute;

    @Column(name = "image_route_content_type")
    private String imageRouteContentType;

    @OneToOne(mappedBy = "photo")
    @JsonIgnore
    private Location location;

    @OneToOne(mappedBy = "photo")
    @JsonIgnore
    private UserProfile userProfile;

    @ManyToOne
    @JsonIgnoreProperties("photos")
    private TravelRoute travelRoute;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitlePhoto() {
        return titlePhoto;
    }

    public Photo titlePhoto(String titlePhoto) {
        this.titlePhoto = titlePhoto;
        return this;
    }

    public void setTitlePhoto(String titlePhoto) {
        this.titlePhoto = titlePhoto;
    }

    public String getDescriptionPhoto() {
        return descriptionPhoto;
    }

    public Photo descriptionPhoto(String descriptionPhoto) {
        this.descriptionPhoto = descriptionPhoto;
        return this;
    }

    public void setDescriptionPhoto(String descriptionPhoto) {
        this.descriptionPhoto = descriptionPhoto;
    }

    public Boolean isPhotoMain() {
        return photoMain;
    }

    public Photo photoMain(Boolean photoMain) {
        this.photoMain = photoMain;
        return this;
    }

    public void setPhotoMain(Boolean photoMain) {
        this.photoMain = photoMain;
    }

    public Boolean isPhotoMap() {
        return photoMap;
    }

    public Photo photoMap(Boolean photoMap) {
        this.photoMap = photoMap;
        return this;
    }

    public void setPhotoMap(Boolean photoMap) {
        this.photoMap = photoMap;
    }

    public Boolean isPhotoLocation() {
        return photoLocation;
    }

    public Photo photoLocation(Boolean photoLocation) {
        this.photoLocation = photoLocation;
        return this;
    }

    public void setPhotoLocation(Boolean photoLocation) {
        this.photoLocation = photoLocation;
    }

    public String getUrlPhoto() {
        return urlPhoto;
    }

    public Photo urlPhoto(String urlPhoto) {
        this.urlPhoto = urlPhoto;
        return this;
    }

    public void setUrlPhoto(String urlPhoto) {
        this.urlPhoto = urlPhoto;
    }

    public Integer getCodePhoto() {
        return codePhoto;
    }

    public Photo codePhoto(Integer codePhoto) {
        this.codePhoto = codePhoto;
        return this;
    }

    public void setCodePhoto(Integer codePhoto) {
        this.codePhoto = codePhoto;
    }

    public byte[] getImageRoute() {
        return imageRoute;
    }

    public Photo imageRoute(byte[] imageRoute) {
        this.imageRoute = imageRoute;
        return this;
    }

    public void setImageRoute(byte[] imageRoute) {
        this.imageRoute = imageRoute;
    }

    public String getImageRouteContentType() {
        return imageRouteContentType;
    }

    public Photo imageRouteContentType(String imageRouteContentType) {
        this.imageRouteContentType = imageRouteContentType;
        return this;
    }

    public void setImageRouteContentType(String imageRouteContentType) {
        this.imageRouteContentType = imageRouteContentType;
    }

    public Location getLocation() {
        return location;
    }

    public Photo location(Location location) {
        this.location = location;
        return this;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public UserProfile getUserProfile() {
        return userProfile;
    }

    public Photo userProfile(UserProfile userProfile) {
        this.userProfile = userProfile;
        return this;
    }

    public void setUserProfile(UserProfile userProfile) {
        this.userProfile = userProfile;
    }

    public TravelRoute getTravelRoute() {
        return travelRoute;
    }

    public Photo travelRoute(TravelRoute travelRoute) {
        this.travelRoute = travelRoute;
        return this;
    }

    public void setTravelRoute(TravelRoute travelRoute) {
        this.travelRoute = travelRoute;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Photo)) {
            return false;
        }
        return id != null && id.equals(((Photo) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "Photo{" +
            "id=" + getId() +
            ", titlePhoto='" + getTitlePhoto() + "'" +
            ", descriptionPhoto='" + getDescriptionPhoto() + "'" +
            ", photoMain='" + isPhotoMain() + "'" +
            ", photoMap='" + isPhotoMap() + "'" +
            ", photoLocation='" + isPhotoLocation() + "'" +
            ", urlPhoto='" + getUrlPhoto() + "'" +
            ", codePhoto=" + getCodePhoto() +
            ", imageRoute='" + getImageRoute() + "'" +
            ", imageRouteContentType='" + getImageRouteContentType() + "'" +
            "}";
    }
}
