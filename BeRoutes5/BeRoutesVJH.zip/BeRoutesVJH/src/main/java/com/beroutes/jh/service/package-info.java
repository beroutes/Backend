/**
 * Service layer beans.
 */
package com.beroutes.jh.service;
