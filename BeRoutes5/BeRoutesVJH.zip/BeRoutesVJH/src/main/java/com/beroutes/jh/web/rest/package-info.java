/**
 * Spring MVC REST controllers.
 */
package com.beroutes.jh.web.rest;
