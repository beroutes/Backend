package com.beroutes.jh.service.impl;

import com.beroutes.jh.service.FollowingService;
import com.beroutes.jh.domain.Following;
import com.beroutes.jh.repository.FollowingRepository;
import com.beroutes.jh.repository.search.FollowingSearchRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing {@link Following}.
 */
@Service
@Transactional
public class FollowingServiceImpl implements FollowingService {

    private final Logger log = LoggerFactory.getLogger(FollowingServiceImpl.class);

    private final FollowingRepository followingRepository;

    private final FollowingSearchRepository followingSearchRepository;

    public FollowingServiceImpl(FollowingRepository followingRepository, FollowingSearchRepository followingSearchRepository) {
        this.followingRepository = followingRepository;
        this.followingSearchRepository = followingSearchRepository;
    }

    /**
     * Save a following.
     *
     * @param following the entity to save.
     * @return the persisted entity.
     */
    @Override
    public Following save(Following following) {
        log.debug("Request to save Following : {}", following);
        Following result = followingRepository.save(following);
        followingSearchRepository.save(result);
        return result;
    }

    /**
     * Get all the followings.
     *
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    @Override
    @Transactional(readOnly = true)
    public Page<Following> findAll(Pageable pageable) {
        log.debug("Request to get all Followings");
        return followingRepository.findAll(pageable);
    }

    /**
     * Get one following by id.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<Following> findOne(Long id) {
        log.debug("Request to get Following : {}", id);
        return followingRepository.findById(id);
    }

    /**
     * Delete the following by id.
     *
     * @param id the id of the entity.
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete Following : {}", id);
        followingRepository.deleteById(id);
        followingSearchRepository.deleteById(id);
    }

    /**
     * Search for the following corresponding to the query.
     *
     * @param query the query of the search.
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    @Override
    @Transactional(readOnly = true)
    public Page<Following> search(String query, Pageable pageable) {
        log.debug("Request to search for a page of Followings for query {}", query);
        return followingSearchRepository.search(queryStringQuery(query), pageable);    }
}
