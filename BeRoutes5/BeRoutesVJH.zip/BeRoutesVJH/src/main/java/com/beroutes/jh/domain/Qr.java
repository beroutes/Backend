package com.beroutes.jh.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;

import org.springframework.data.elasticsearch.annotations.FieldType;
import java.io.Serializable;
import java.util.Objects;

/**
 * A Qr.
 */
@Entity
@Table(name = "qr")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@org.springframework.data.elasticsearch.annotations.Document(indexName = "qr")
public class Qr implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "qr_description")
    private String qrDescription;

    @Column(name = "data_1")
    private Double data1;

    @Column(name = "data_2")
    private Double data2;

    @Column(name = "data_3")
    private Double data3;

    @OneToOne(mappedBy = "qr")
    @JsonIgnore
    private Location location;

    @ManyToOne
    @JsonIgnoreProperties("qrs")
    private TravelRoute travelRoute;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getQrDescription() {
        return qrDescription;
    }

    public Qr qrDescription(String qrDescription) {
        this.qrDescription = qrDescription;
        return this;
    }

    public void setQrDescription(String qrDescription) {
        this.qrDescription = qrDescription;
    }

    public Double getData1() {
        return data1;
    }

    public Qr data1(Double data1) {
        this.data1 = data1;
        return this;
    }

    public void setData1(Double data1) {
        this.data1 = data1;
    }

    public Double getData2() {
        return data2;
    }

    public Qr data2(Double data2) {
        this.data2 = data2;
        return this;
    }

    public void setData2(Double data2) {
        this.data2 = data2;
    }

    public Double getData3() {
        return data3;
    }

    public Qr data3(Double data3) {
        this.data3 = data3;
        return this;
    }

    public void setData3(Double data3) {
        this.data3 = data3;
    }

    public Location getLocation() {
        return location;
    }

    public Qr location(Location location) {
        this.location = location;
        return this;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public TravelRoute getTravelRoute() {
        return travelRoute;
    }

    public Qr travelRoute(TravelRoute travelRoute) {
        this.travelRoute = travelRoute;
        return this;
    }

    public void setTravelRoute(TravelRoute travelRoute) {
        this.travelRoute = travelRoute;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Qr)) {
            return false;
        }
        return id != null && id.equals(((Qr) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "Qr{" +
            "id=" + getId() +
            ", qrDescription='" + getQrDescription() + "'" +
            ", data1=" + getData1() +
            ", data2=" + getData2() +
            ", data3=" + getData3() +
            "}";
    }
}
