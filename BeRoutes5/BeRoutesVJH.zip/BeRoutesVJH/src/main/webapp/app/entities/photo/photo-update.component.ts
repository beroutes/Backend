import { Component, OnInit } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { JhiDataUtils, JhiFileLoadError, JhiEventManager, JhiEventWithContent } from 'ng-jhipster';

import { IPhoto, Photo } from 'app/shared/model/photo.model';
import { PhotoService } from './photo.service';
import { AlertError } from 'app/shared/alert/alert-error.model';
import { ITravelRoute } from 'app/shared/model/travel-route.model';
import { TravelRouteService } from 'app/entities/travel-route/travel-route.service';

@Component({
  selector: 'jhi-photo-update',
  templateUrl: './photo-update.component.html'
})
export class PhotoUpdateComponent implements OnInit {
  isSaving = false;
  travelroutes: ITravelRoute[] = [];

  editForm = this.fb.group({
    id: [],
    titlePhoto: [],
    descriptionPhoto: [],
    photoMain: [],
    photoMap: [],
    photoLocation: [],
    urlPhoto: [],
    codePhoto: [],
    imageRoute: [],
    imageRouteContentType: [],
    travelRoute: []
  });

  constructor(
    protected dataUtils: JhiDataUtils,
    protected eventManager: JhiEventManager,
    protected photoService: PhotoService,
    protected travelRouteService: TravelRouteService,
    protected activatedRoute: ActivatedRoute,
    private fb: FormBuilder
  ) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ photo }) => {
      this.updateForm(photo);

      this.travelRouteService.query().subscribe((res: HttpResponse<ITravelRoute[]>) => (this.travelroutes = res.body || []));
    });
  }

  updateForm(photo: IPhoto): void {
    this.editForm.patchValue({
      id: photo.id,
      titlePhoto: photo.titlePhoto,
      descriptionPhoto: photo.descriptionPhoto,
      photoMain: photo.photoMain,
      photoMap: photo.photoMap,
      photoLocation: photo.photoLocation,
      urlPhoto: photo.urlPhoto,
      codePhoto: photo.codePhoto,
      imageRoute: photo.imageRoute,
      imageRouteContentType: photo.imageRouteContentType,
      travelRoute: photo.travelRoute
    });
  }

  byteSize(base64String: string): string {
    return this.dataUtils.byteSize(base64String);
  }

  openFile(contentType: string, base64String: string): void {
    this.dataUtils.openFile(contentType, base64String);
  }

  setFileData(event: Event, field: string, isImage: boolean): void {
    this.dataUtils.loadFileToForm(event, this.editForm, field, isImage).subscribe(null, (err: JhiFileLoadError) => {
      this.eventManager.broadcast(
        new JhiEventWithContent<AlertError>('beRoutesJhApp.error', { message: err.message })
      );
    });
  }

  previousState(): void {
    window.history.back();
  }

  save(): void {
    this.isSaving = true;
    const photo = this.createFromForm();
    if (photo.id !== undefined) {
      this.subscribeToSaveResponse(this.photoService.update(photo));
    } else {
      this.subscribeToSaveResponse(this.photoService.create(photo));
    }
  }

  private createFromForm(): IPhoto {
    return {
      ...new Photo(),
      id: this.editForm.get(['id'])!.value,
      titlePhoto: this.editForm.get(['titlePhoto'])!.value,
      descriptionPhoto: this.editForm.get(['descriptionPhoto'])!.value,
      photoMain: this.editForm.get(['photoMain'])!.value,
      photoMap: this.editForm.get(['photoMap'])!.value,
      photoLocation: this.editForm.get(['photoLocation'])!.value,
      urlPhoto: this.editForm.get(['urlPhoto'])!.value,
      codePhoto: this.editForm.get(['codePhoto'])!.value,
      imageRouteContentType: this.editForm.get(['imageRouteContentType'])!.value,
      imageRoute: this.editForm.get(['imageRoute'])!.value,
      travelRoute: this.editForm.get(['travelRoute'])!.value
    };
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<IPhoto>>): void {
    result.subscribe(
      () => this.onSaveSuccess(),
      () => this.onSaveError()
    );
  }

  protected onSaveSuccess(): void {
    this.isSaving = false;
    this.previousState();
  }

  protected onSaveError(): void {
    this.isSaving = false;
  }

  trackById(index: number, item: ITravelRoute): any {
    return item.id;
  }
}
