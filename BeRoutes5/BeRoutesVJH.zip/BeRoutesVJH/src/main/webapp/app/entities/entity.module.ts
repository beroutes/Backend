import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

@NgModule({
  imports: [
    RouterModule.forChild([
      {
        path: 'country',
        loadChildren: () => import('./country/country.module').then(m => m.BeRoutesJhCountryModule)
      },
      {
        path: 'location',
        loadChildren: () => import('./location/location.module').then(m => m.BeRoutesJhLocationModule)
      },
      {
        path: 'travel-route',
        loadChildren: () => import('./travel-route/travel-route.module').then(m => m.BeRoutesJhTravelRouteModule)
      },
      {
        path: 'user-profile',
        loadChildren: () => import('./user-profile/user-profile.module').then(m => m.BeRoutesJhUserProfileModule)
      },
      {
        path: 'following',
        loadChildren: () => import('./following/following.module').then(m => m.BeRoutesJhFollowingModule)
      },
      {
        path: 'photo',
        loadChildren: () => import('./photo/photo.module').then(m => m.BeRoutesJhPhotoModule)
      },
      {
        path: 'valuation',
        loadChildren: () => import('./valuation/valuation.module').then(m => m.BeRoutesJhValuationModule)
      },
      {
        path: 'qr',
        loadChildren: () => import('./qr/qr.module').then(m => m.BeRoutesJhQrModule)
      },
      {
        path: 'favorite',
        loadChildren: () => import('./favorite/favorite.module').then(m => m.BeRoutesJhFavoriteModule)
      }
      /* jhipster-needle-add-entity-route - JHipster will add entity modules routes here */
    ])
  ]
})
export class BeRoutesJhEntityModule {}
