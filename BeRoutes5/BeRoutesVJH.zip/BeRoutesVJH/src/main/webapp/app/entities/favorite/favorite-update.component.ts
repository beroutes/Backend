import { Component, OnInit } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';

import { IFavorite, Favorite } from 'app/shared/model/favorite.model';
import { FavoriteService } from './favorite.service';
import { ITravelRoute } from 'app/shared/model/travel-route.model';
import { TravelRouteService } from 'app/entities/travel-route/travel-route.service';
import { IUserProfile } from 'app/shared/model/user-profile.model';
import { UserProfileService } from 'app/entities/user-profile/user-profile.service';

type SelectableEntity = ITravelRoute | IUserProfile;

@Component({
  selector: 'jhi-favorite-update',
  templateUrl: './favorite-update.component.html'
})
export class FavoriteUpdateComponent implements OnInit {
  isSaving = false;
  travelroutes: ITravelRoute[] = [];
  userprofiles: IUserProfile[] = [];

  editForm = this.fb.group({
    id: [],
    like: [],
    notLike: [],
    travelRoute: [],
    userProfile: []
  });

  constructor(
    protected favoriteService: FavoriteService,
    protected travelRouteService: TravelRouteService,
    protected userProfileService: UserProfileService,
    protected activatedRoute: ActivatedRoute,
    private fb: FormBuilder
  ) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ favorite }) => {
      this.updateForm(favorite);

      this.travelRouteService.query().subscribe((res: HttpResponse<ITravelRoute[]>) => (this.travelroutes = res.body || []));

      this.userProfileService.query().subscribe((res: HttpResponse<IUserProfile[]>) => (this.userprofiles = res.body || []));
    });
  }

  updateForm(favorite: IFavorite): void {
    this.editForm.patchValue({
      id: favorite.id,
      like: favorite.like,
      notLike: favorite.notLike,
      travelRoute: favorite.travelRoute,
      userProfile: favorite.userProfile
    });
  }

  previousState(): void {
    window.history.back();
  }

  save(): void {
    this.isSaving = true;
    const favorite = this.createFromForm();
    if (favorite.id !== undefined) {
      this.subscribeToSaveResponse(this.favoriteService.update(favorite));
    } else {
      this.subscribeToSaveResponse(this.favoriteService.create(favorite));
    }
  }

  private createFromForm(): IFavorite {
    return {
      ...new Favorite(),
      id: this.editForm.get(['id'])!.value,
      like: this.editForm.get(['like'])!.value,
      notLike: this.editForm.get(['notLike'])!.value,
      travelRoute: this.editForm.get(['travelRoute'])!.value,
      userProfile: this.editForm.get(['userProfile'])!.value
    };
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<IFavorite>>): void {
    result.subscribe(
      () => this.onSaveSuccess(),
      () => this.onSaveError()
    );
  }

  protected onSaveSuccess(): void {
    this.isSaving = false;
    this.previousState();
  }

  protected onSaveError(): void {
    this.isSaving = false;
  }

  trackById(index: number, item: SelectableEntity): any {
    return item.id;
  }
}
