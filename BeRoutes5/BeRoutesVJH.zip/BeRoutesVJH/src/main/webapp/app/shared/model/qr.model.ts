import { ILocation } from 'app/shared/model/location.model';
import { ITravelRoute } from 'app/shared/model/travel-route.model';

export interface IQr {
  id?: number;
  qrDescription?: string;
  data1?: number;
  data2?: number;
  data3?: number;
  location?: ILocation;
  travelRoute?: ITravelRoute;
}

export class Qr implements IQr {
  constructor(
    public id?: number,
    public qrDescription?: string,
    public data1?: number,
    public data2?: number,
    public data3?: number,
    public location?: ILocation,
    public travelRoute?: ITravelRoute
  ) {}
}
