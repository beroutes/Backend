export const enum CategoryTwo {
  CHEAP = 'CHEAP',
  LUXURY = 'LUXURY',
  LONELY = 'LONELY',
  FRIENDS = 'FRIENDS',
  ROMANTIC = 'ROMANTIC',
  KIDS = 'KIDS',
  SPORT = 'SPORT',
  RELAXATION = 'RELAXATION',
  ART = 'ART',
  FOOD = 'FOOD',
  NATURE = 'NATURE',
  CITY = 'CITY'
}
