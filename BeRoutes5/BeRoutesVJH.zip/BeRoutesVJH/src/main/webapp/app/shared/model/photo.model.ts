import { ILocation } from 'app/shared/model/location.model';
import { IUserProfile } from 'app/shared/model/user-profile.model';
import { ITravelRoute } from 'app/shared/model/travel-route.model';

export interface IPhoto {
  id?: number;
  titlePhoto?: string;
  descriptionPhoto?: string;
  photoMain?: boolean;
  photoMap?: boolean;
  photoLocation?: boolean;
  urlPhoto?: string;
  codePhoto?: number;
  imageRouteContentType?: string;
  imageRoute?: any;
  location?: ILocation;
  userProfile?: IUserProfile;
  travelRoute?: ITravelRoute;
}

export class Photo implements IPhoto {
  constructor(
    public id?: number,
    public titlePhoto?: string,
    public descriptionPhoto?: string,
    public photoMain?: boolean,
    public photoMap?: boolean,
    public photoLocation?: boolean,
    public urlPhoto?: string,
    public codePhoto?: number,
    public imageRouteContentType?: string,
    public imageRoute?: any,
    public location?: ILocation,
    public userProfile?: IUserProfile,
    public travelRoute?: ITravelRoute
  ) {
    this.photoMain = this.photoMain || false;
    this.photoMap = this.photoMap || false;
    this.photoLocation = this.photoLocation || false;
  }
}
