import { IUserProfile } from 'app/shared/model/user-profile.model';

export interface IFollowing {
  id?: number;
  follow?: boolean;
  accepted?: boolean;
  userFollower?: number;
  userFollowed?: number;
  userProfiles?: IUserProfile[];
  userProfile?: IUserProfile;
}

export class Following implements IFollowing {
  constructor(
    public id?: number,
    public follow?: boolean,
    public accepted?: boolean,
    public userFollower?: number,
    public userFollowed?: number,
    public userProfiles?: IUserProfile[],
    public userProfile?: IUserProfile
  ) {
    this.follow = this.follow || false;
    this.accepted = this.accepted || false;
  }
}
