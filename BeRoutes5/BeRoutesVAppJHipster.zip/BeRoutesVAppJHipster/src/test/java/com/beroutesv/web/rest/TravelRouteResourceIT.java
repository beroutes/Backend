package com.beroutesv.web.rest;

import com.beroutesv.BeRoutesVApp;
import com.beroutesv.domain.TravelRoute;
import com.beroutesv.domain.Country;
import com.beroutesv.domain.Location;
import com.beroutesv.domain.Photo;
import com.beroutesv.domain.Valuation;
import com.beroutesv.domain.Qr;
import com.beroutesv.domain.UserProfile;
import com.beroutesv.repository.TravelRouteRepository;
import com.beroutesv.repository.search.TravelRouteSearchRepository;
import com.beroutesv.service.TravelRouteService;
import com.beroutesv.service.dto.TravelRouteCriteria;
import com.beroutesv.service.TravelRouteQueryService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;
import javax.persistence.EntityManager;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.elasticsearch.index.query.QueryBuilders.queryStringQuery;
import static org.hamcrest.Matchers.hasItem;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.beroutesv.domain.enumeration.Continent;
import com.beroutesv.domain.enumeration.Season;
import com.beroutesv.domain.enumeration.Category;
/**
 * Integration tests for the {@link TravelRouteResource} REST controller.
 */
@SpringBootTest(classes = BeRoutesVApp.class)
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
@WithMockUser
public class TravelRouteResourceIT {

    private static final String DEFAULT_TITLE_ROUTE = "AAAAAAAAAA";
    private static final String UPDATED_TITLE_ROUTE = "BBBBBBBBBB";

    private static final String DEFAULT_DESTINATION = "AAAAAAAAAA";
    private static final String UPDATED_DESTINATION = "BBBBBBBBBB";

    private static final Continent DEFAULT_CONTINENT = Continent.ASIA;
    private static final Continent UPDATED_CONTINENT = Continent.AFRICA;

    private static final Integer DEFAULT_DAYS = 1;
    private static final Integer UPDATED_DAYS = 2;
    private static final Integer SMALLER_DAYS = 1 - 1;

    private static final Integer DEFAULT_WEEKS = 1;
    private static final Integer UPDATED_WEEKS = 2;
    private static final Integer SMALLER_WEEKS = 1 - 1;

    private static final Season DEFAULT_SEASON = Season.SPRING;
    private static final Season UPDATED_SEASON = Season.SUMMER;

    private static final Double DEFAULT_BUDGET = 1D;
    private static final Double UPDATED_BUDGET = 2D;
    private static final Double SMALLER_BUDGET = 1D - 1D;

    private static final Category DEFAULT_CATEGORY = Category.CHEAP;
    private static final Category UPDATED_CATEGORY = Category.LUXURY;

    private static final Double DEFAULT_VALUE_AVERAGE = 1D;
    private static final Double UPDATED_VALUE_AVERAGE = 2D;
    private static final Double SMALLER_VALUE_AVERAGE = 1D - 1D;

    private static final String DEFAULT_DESCRIPTION_ROUTE_SUMMARY = "AAAAAAAAAA";
    private static final String UPDATED_DESCRIPTION_ROUTE_SUMMARY = "BBBBBBBBBB";

    private static final String DEFAULT_DESCRIPTION_ROUTE = "AAAAAAAAAA";
    private static final String UPDATED_DESCRIPTION_ROUTE = "BBBBBBBBBB";

    private static final Integer DEFAULT_STEPS = 1;
    private static final Integer UPDATED_STEPS = 2;
    private static final Integer SMALLER_STEPS = 1 - 1;

    private static final String DEFAULT_SUMMARY_MAP = "AAAAAAAAAA";
    private static final String UPDATED_SUMMARY_MAP = "BBBBBBBBBB";

    private static final LocalDate DEFAULT_CREATED_AT = LocalDate.ofEpochDay(0L);
    private static final LocalDate UPDATED_CREATED_AT = LocalDate.now(ZoneId.systemDefault());
    private static final LocalDate SMALLER_CREATED_AT = LocalDate.ofEpochDay(-1L);

    private static final LocalDate DEFAULT_UPDATED_AT = LocalDate.ofEpochDay(0L);
    private static final LocalDate UPDATED_UPDATED_AT = LocalDate.now(ZoneId.systemDefault());
    private static final LocalDate SMALLER_UPDATED_AT = LocalDate.ofEpochDay(-1L);

    private static final Boolean DEFAULT_QR_ACTIVATION = false;
    private static final Boolean UPDATED_QR_ACTIVATION = true;

    @Autowired
    private TravelRouteRepository travelRouteRepository;

    @Autowired
    private TravelRouteService travelRouteService;

    /**
     * This repository is mocked in the com.beroutesv.repository.search test package.
     *
     * @see com.beroutesv.repository.search.TravelRouteSearchRepositoryMockConfiguration
     */
    @Autowired
    private TravelRouteSearchRepository mockTravelRouteSearchRepository;

    @Autowired
    private TravelRouteQueryService travelRouteQueryService;

    @Autowired
    private EntityManager em;

    @Autowired
    private MockMvc restTravelRouteMockMvc;

    private TravelRoute travelRoute;

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static TravelRoute createEntity(EntityManager em) {
        TravelRoute travelRoute = new TravelRoute()
            .titleRoute(DEFAULT_TITLE_ROUTE)
            .destination(DEFAULT_DESTINATION)
            .continent(DEFAULT_CONTINENT)
            .days(DEFAULT_DAYS)
            .weeks(DEFAULT_WEEKS)
            .season(DEFAULT_SEASON)
            .budget(DEFAULT_BUDGET)
            .category(DEFAULT_CATEGORY)
            .valueAverage(DEFAULT_VALUE_AVERAGE)
            .descriptionRouteSummary(DEFAULT_DESCRIPTION_ROUTE_SUMMARY)
            .descriptionRoute(DEFAULT_DESCRIPTION_ROUTE)
            .steps(DEFAULT_STEPS)
            .summaryMap(DEFAULT_SUMMARY_MAP)
            .createdAt(DEFAULT_CREATED_AT)
            .updatedAt(DEFAULT_UPDATED_AT)
            .qrActivation(DEFAULT_QR_ACTIVATION);
        return travelRoute;
    }
    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static TravelRoute createUpdatedEntity(EntityManager em) {
        TravelRoute travelRoute = new TravelRoute()
            .titleRoute(UPDATED_TITLE_ROUTE)
            .destination(UPDATED_DESTINATION)
            .continent(UPDATED_CONTINENT)
            .days(UPDATED_DAYS)
            .weeks(UPDATED_WEEKS)
            .season(UPDATED_SEASON)
            .budget(UPDATED_BUDGET)
            .category(UPDATED_CATEGORY)
            .valueAverage(UPDATED_VALUE_AVERAGE)
            .descriptionRouteSummary(UPDATED_DESCRIPTION_ROUTE_SUMMARY)
            .descriptionRoute(UPDATED_DESCRIPTION_ROUTE)
            .steps(UPDATED_STEPS)
            .summaryMap(UPDATED_SUMMARY_MAP)
            .createdAt(UPDATED_CREATED_AT)
            .updatedAt(UPDATED_UPDATED_AT)
            .qrActivation(UPDATED_QR_ACTIVATION);
        return travelRoute;
    }

    @BeforeEach
    public void initTest() {
        travelRoute = createEntity(em);
    }

    @Test
    @Transactional
    public void createTravelRoute() throws Exception {
        int databaseSizeBeforeCreate = travelRouteRepository.findAll().size();

        // Create the TravelRoute
        restTravelRouteMockMvc.perform(post("/api/travel-routes")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(travelRoute)))
            .andExpect(status().isCreated());

        // Validate the TravelRoute in the database
        List<TravelRoute> travelRouteList = travelRouteRepository.findAll();
        assertThat(travelRouteList).hasSize(databaseSizeBeforeCreate + 1);
        TravelRoute testTravelRoute = travelRouteList.get(travelRouteList.size() - 1);
        assertThat(testTravelRoute.getTitleRoute()).isEqualTo(DEFAULT_TITLE_ROUTE);
        assertThat(testTravelRoute.getDestination()).isEqualTo(DEFAULT_DESTINATION);
        assertThat(testTravelRoute.getContinent()).isEqualTo(DEFAULT_CONTINENT);
        assertThat(testTravelRoute.getDays()).isEqualTo(DEFAULT_DAYS);
        assertThat(testTravelRoute.getWeeks()).isEqualTo(DEFAULT_WEEKS);
        assertThat(testTravelRoute.getSeason()).isEqualTo(DEFAULT_SEASON);
        assertThat(testTravelRoute.getBudget()).isEqualTo(DEFAULT_BUDGET);
        assertThat(testTravelRoute.getCategory()).isEqualTo(DEFAULT_CATEGORY);
        assertThat(testTravelRoute.getValueAverage()).isEqualTo(DEFAULT_VALUE_AVERAGE);
        assertThat(testTravelRoute.getDescriptionRouteSummary()).isEqualTo(DEFAULT_DESCRIPTION_ROUTE_SUMMARY);
        assertThat(testTravelRoute.getDescriptionRoute()).isEqualTo(DEFAULT_DESCRIPTION_ROUTE);
        assertThat(testTravelRoute.getSteps()).isEqualTo(DEFAULT_STEPS);
        assertThat(testTravelRoute.getSummaryMap()).isEqualTo(DEFAULT_SUMMARY_MAP);
        assertThat(testTravelRoute.getCreatedAt()).isEqualTo(DEFAULT_CREATED_AT);
        assertThat(testTravelRoute.getUpdatedAt()).isEqualTo(DEFAULT_UPDATED_AT);
        assertThat(testTravelRoute.isQrActivation()).isEqualTo(DEFAULT_QR_ACTIVATION);

        // Validate the TravelRoute in Elasticsearch
        verify(mockTravelRouteSearchRepository, times(1)).save(testTravelRoute);
    }

    @Test
    @Transactional
    public void createTravelRouteWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = travelRouteRepository.findAll().size();

        // Create the TravelRoute with an existing ID
        travelRoute.setId(1L);

        // An entity with an existing ID cannot be created, so this API call must fail
        restTravelRouteMockMvc.perform(post("/api/travel-routes")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(travelRoute)))
            .andExpect(status().isBadRequest());

        // Validate the TravelRoute in the database
        List<TravelRoute> travelRouteList = travelRouteRepository.findAll();
        assertThat(travelRouteList).hasSize(databaseSizeBeforeCreate);

        // Validate the TravelRoute in Elasticsearch
        verify(mockTravelRouteSearchRepository, times(0)).save(travelRoute);
    }


    @Test
    @Transactional
    public void getAllTravelRoutes() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList
        restTravelRouteMockMvc.perform(get("/api/travel-routes?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(travelRoute.getId().intValue())))
            .andExpect(jsonPath("$.[*].titleRoute").value(hasItem(DEFAULT_TITLE_ROUTE)))
            .andExpect(jsonPath("$.[*].destination").value(hasItem(DEFAULT_DESTINATION)))
            .andExpect(jsonPath("$.[*].continent").value(hasItem(DEFAULT_CONTINENT.toString())))
            .andExpect(jsonPath("$.[*].days").value(hasItem(DEFAULT_DAYS)))
            .andExpect(jsonPath("$.[*].weeks").value(hasItem(DEFAULT_WEEKS)))
            .andExpect(jsonPath("$.[*].season").value(hasItem(DEFAULT_SEASON.toString())))
            .andExpect(jsonPath("$.[*].budget").value(hasItem(DEFAULT_BUDGET.doubleValue())))
            .andExpect(jsonPath("$.[*].category").value(hasItem(DEFAULT_CATEGORY.toString())))
            .andExpect(jsonPath("$.[*].valueAverage").value(hasItem(DEFAULT_VALUE_AVERAGE.doubleValue())))
            .andExpect(jsonPath("$.[*].descriptionRouteSummary").value(hasItem(DEFAULT_DESCRIPTION_ROUTE_SUMMARY)))
            .andExpect(jsonPath("$.[*].descriptionRoute").value(hasItem(DEFAULT_DESCRIPTION_ROUTE)))
            .andExpect(jsonPath("$.[*].steps").value(hasItem(DEFAULT_STEPS)))
            .andExpect(jsonPath("$.[*].summaryMap").value(hasItem(DEFAULT_SUMMARY_MAP)))
            .andExpect(jsonPath("$.[*].createdAt").value(hasItem(DEFAULT_CREATED_AT.toString())))
            .andExpect(jsonPath("$.[*].updatedAt").value(hasItem(DEFAULT_UPDATED_AT.toString())))
            .andExpect(jsonPath("$.[*].qrActivation").value(hasItem(DEFAULT_QR_ACTIVATION.booleanValue())));
    }
    
    @Test
    @Transactional
    public void getTravelRoute() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get the travelRoute
        restTravelRouteMockMvc.perform(get("/api/travel-routes/{id}", travelRoute.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.id").value(travelRoute.getId().intValue()))
            .andExpect(jsonPath("$.titleRoute").value(DEFAULT_TITLE_ROUTE))
            .andExpect(jsonPath("$.destination").value(DEFAULT_DESTINATION))
            .andExpect(jsonPath("$.continent").value(DEFAULT_CONTINENT.toString()))
            .andExpect(jsonPath("$.days").value(DEFAULT_DAYS))
            .andExpect(jsonPath("$.weeks").value(DEFAULT_WEEKS))
            .andExpect(jsonPath("$.season").value(DEFAULT_SEASON.toString()))
            .andExpect(jsonPath("$.budget").value(DEFAULT_BUDGET.doubleValue()))
            .andExpect(jsonPath("$.category").value(DEFAULT_CATEGORY.toString()))
            .andExpect(jsonPath("$.valueAverage").value(DEFAULT_VALUE_AVERAGE.doubleValue()))
            .andExpect(jsonPath("$.descriptionRouteSummary").value(DEFAULT_DESCRIPTION_ROUTE_SUMMARY))
            .andExpect(jsonPath("$.descriptionRoute").value(DEFAULT_DESCRIPTION_ROUTE))
            .andExpect(jsonPath("$.steps").value(DEFAULT_STEPS))
            .andExpect(jsonPath("$.summaryMap").value(DEFAULT_SUMMARY_MAP))
            .andExpect(jsonPath("$.createdAt").value(DEFAULT_CREATED_AT.toString()))
            .andExpect(jsonPath("$.updatedAt").value(DEFAULT_UPDATED_AT.toString()))
            .andExpect(jsonPath("$.qrActivation").value(DEFAULT_QR_ACTIVATION.booleanValue()));
    }


    @Test
    @Transactional
    public void getTravelRoutesByIdFiltering() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        Long id = travelRoute.getId();

        defaultTravelRouteShouldBeFound("id.equals=" + id);
        defaultTravelRouteShouldNotBeFound("id.notEquals=" + id);

        defaultTravelRouteShouldBeFound("id.greaterThanOrEqual=" + id);
        defaultTravelRouteShouldNotBeFound("id.greaterThan=" + id);

        defaultTravelRouteShouldBeFound("id.lessThanOrEqual=" + id);
        defaultTravelRouteShouldNotBeFound("id.lessThan=" + id);
    }


    @Test
    @Transactional
    public void getAllTravelRoutesByTitleRouteIsEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where titleRoute equals to DEFAULT_TITLE_ROUTE
        defaultTravelRouteShouldBeFound("titleRoute.equals=" + DEFAULT_TITLE_ROUTE);

        // Get all the travelRouteList where titleRoute equals to UPDATED_TITLE_ROUTE
        defaultTravelRouteShouldNotBeFound("titleRoute.equals=" + UPDATED_TITLE_ROUTE);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByTitleRouteIsNotEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where titleRoute not equals to DEFAULT_TITLE_ROUTE
        defaultTravelRouteShouldNotBeFound("titleRoute.notEquals=" + DEFAULT_TITLE_ROUTE);

        // Get all the travelRouteList where titleRoute not equals to UPDATED_TITLE_ROUTE
        defaultTravelRouteShouldBeFound("titleRoute.notEquals=" + UPDATED_TITLE_ROUTE);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByTitleRouteIsInShouldWork() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where titleRoute in DEFAULT_TITLE_ROUTE or UPDATED_TITLE_ROUTE
        defaultTravelRouteShouldBeFound("titleRoute.in=" + DEFAULT_TITLE_ROUTE + "," + UPDATED_TITLE_ROUTE);

        // Get all the travelRouteList where titleRoute equals to UPDATED_TITLE_ROUTE
        defaultTravelRouteShouldNotBeFound("titleRoute.in=" + UPDATED_TITLE_ROUTE);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByTitleRouteIsNullOrNotNull() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where titleRoute is not null
        defaultTravelRouteShouldBeFound("titleRoute.specified=true");

        // Get all the travelRouteList where titleRoute is null
        defaultTravelRouteShouldNotBeFound("titleRoute.specified=false");
    }
                @Test
    @Transactional
    public void getAllTravelRoutesByTitleRouteContainsSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where titleRoute contains DEFAULT_TITLE_ROUTE
        defaultTravelRouteShouldBeFound("titleRoute.contains=" + DEFAULT_TITLE_ROUTE);

        // Get all the travelRouteList where titleRoute contains UPDATED_TITLE_ROUTE
        defaultTravelRouteShouldNotBeFound("titleRoute.contains=" + UPDATED_TITLE_ROUTE);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByTitleRouteNotContainsSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where titleRoute does not contain DEFAULT_TITLE_ROUTE
        defaultTravelRouteShouldNotBeFound("titleRoute.doesNotContain=" + DEFAULT_TITLE_ROUTE);

        // Get all the travelRouteList where titleRoute does not contain UPDATED_TITLE_ROUTE
        defaultTravelRouteShouldBeFound("titleRoute.doesNotContain=" + UPDATED_TITLE_ROUTE);
    }


    @Test
    @Transactional
    public void getAllTravelRoutesByDestinationIsEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where destination equals to DEFAULT_DESTINATION
        defaultTravelRouteShouldBeFound("destination.equals=" + DEFAULT_DESTINATION);

        // Get all the travelRouteList where destination equals to UPDATED_DESTINATION
        defaultTravelRouteShouldNotBeFound("destination.equals=" + UPDATED_DESTINATION);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByDestinationIsNotEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where destination not equals to DEFAULT_DESTINATION
        defaultTravelRouteShouldNotBeFound("destination.notEquals=" + DEFAULT_DESTINATION);

        // Get all the travelRouteList where destination not equals to UPDATED_DESTINATION
        defaultTravelRouteShouldBeFound("destination.notEquals=" + UPDATED_DESTINATION);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByDestinationIsInShouldWork() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where destination in DEFAULT_DESTINATION or UPDATED_DESTINATION
        defaultTravelRouteShouldBeFound("destination.in=" + DEFAULT_DESTINATION + "," + UPDATED_DESTINATION);

        // Get all the travelRouteList where destination equals to UPDATED_DESTINATION
        defaultTravelRouteShouldNotBeFound("destination.in=" + UPDATED_DESTINATION);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByDestinationIsNullOrNotNull() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where destination is not null
        defaultTravelRouteShouldBeFound("destination.specified=true");

        // Get all the travelRouteList where destination is null
        defaultTravelRouteShouldNotBeFound("destination.specified=false");
    }
                @Test
    @Transactional
    public void getAllTravelRoutesByDestinationContainsSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where destination contains DEFAULT_DESTINATION
        defaultTravelRouteShouldBeFound("destination.contains=" + DEFAULT_DESTINATION);

        // Get all the travelRouteList where destination contains UPDATED_DESTINATION
        defaultTravelRouteShouldNotBeFound("destination.contains=" + UPDATED_DESTINATION);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByDestinationNotContainsSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where destination does not contain DEFAULT_DESTINATION
        defaultTravelRouteShouldNotBeFound("destination.doesNotContain=" + DEFAULT_DESTINATION);

        // Get all the travelRouteList where destination does not contain UPDATED_DESTINATION
        defaultTravelRouteShouldBeFound("destination.doesNotContain=" + UPDATED_DESTINATION);
    }


    @Test
    @Transactional
    public void getAllTravelRoutesByContinentIsEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where continent equals to DEFAULT_CONTINENT
        defaultTravelRouteShouldBeFound("continent.equals=" + DEFAULT_CONTINENT);

        // Get all the travelRouteList where continent equals to UPDATED_CONTINENT
        defaultTravelRouteShouldNotBeFound("continent.equals=" + UPDATED_CONTINENT);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByContinentIsNotEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where continent not equals to DEFAULT_CONTINENT
        defaultTravelRouteShouldNotBeFound("continent.notEquals=" + DEFAULT_CONTINENT);

        // Get all the travelRouteList where continent not equals to UPDATED_CONTINENT
        defaultTravelRouteShouldBeFound("continent.notEquals=" + UPDATED_CONTINENT);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByContinentIsInShouldWork() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where continent in DEFAULT_CONTINENT or UPDATED_CONTINENT
        defaultTravelRouteShouldBeFound("continent.in=" + DEFAULT_CONTINENT + "," + UPDATED_CONTINENT);

        // Get all the travelRouteList where continent equals to UPDATED_CONTINENT
        defaultTravelRouteShouldNotBeFound("continent.in=" + UPDATED_CONTINENT);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByContinentIsNullOrNotNull() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where continent is not null
        defaultTravelRouteShouldBeFound("continent.specified=true");

        // Get all the travelRouteList where continent is null
        defaultTravelRouteShouldNotBeFound("continent.specified=false");
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByDaysIsEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where days equals to DEFAULT_DAYS
        defaultTravelRouteShouldBeFound("days.equals=" + DEFAULT_DAYS);

        // Get all the travelRouteList where days equals to UPDATED_DAYS
        defaultTravelRouteShouldNotBeFound("days.equals=" + UPDATED_DAYS);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByDaysIsNotEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where days not equals to DEFAULT_DAYS
        defaultTravelRouteShouldNotBeFound("days.notEquals=" + DEFAULT_DAYS);

        // Get all the travelRouteList where days not equals to UPDATED_DAYS
        defaultTravelRouteShouldBeFound("days.notEquals=" + UPDATED_DAYS);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByDaysIsInShouldWork() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where days in DEFAULT_DAYS or UPDATED_DAYS
        defaultTravelRouteShouldBeFound("days.in=" + DEFAULT_DAYS + "," + UPDATED_DAYS);

        // Get all the travelRouteList where days equals to UPDATED_DAYS
        defaultTravelRouteShouldNotBeFound("days.in=" + UPDATED_DAYS);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByDaysIsNullOrNotNull() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where days is not null
        defaultTravelRouteShouldBeFound("days.specified=true");

        // Get all the travelRouteList where days is null
        defaultTravelRouteShouldNotBeFound("days.specified=false");
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByDaysIsGreaterThanOrEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where days is greater than or equal to DEFAULT_DAYS
        defaultTravelRouteShouldBeFound("days.greaterThanOrEqual=" + DEFAULT_DAYS);

        // Get all the travelRouteList where days is greater than or equal to UPDATED_DAYS
        defaultTravelRouteShouldNotBeFound("days.greaterThanOrEqual=" + UPDATED_DAYS);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByDaysIsLessThanOrEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where days is less than or equal to DEFAULT_DAYS
        defaultTravelRouteShouldBeFound("days.lessThanOrEqual=" + DEFAULT_DAYS);

        // Get all the travelRouteList where days is less than or equal to SMALLER_DAYS
        defaultTravelRouteShouldNotBeFound("days.lessThanOrEqual=" + SMALLER_DAYS);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByDaysIsLessThanSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where days is less than DEFAULT_DAYS
        defaultTravelRouteShouldNotBeFound("days.lessThan=" + DEFAULT_DAYS);

        // Get all the travelRouteList where days is less than UPDATED_DAYS
        defaultTravelRouteShouldBeFound("days.lessThan=" + UPDATED_DAYS);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByDaysIsGreaterThanSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where days is greater than DEFAULT_DAYS
        defaultTravelRouteShouldNotBeFound("days.greaterThan=" + DEFAULT_DAYS);

        // Get all the travelRouteList where days is greater than SMALLER_DAYS
        defaultTravelRouteShouldBeFound("days.greaterThan=" + SMALLER_DAYS);
    }


    @Test
    @Transactional
    public void getAllTravelRoutesByWeeksIsEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where weeks equals to DEFAULT_WEEKS
        defaultTravelRouteShouldBeFound("weeks.equals=" + DEFAULT_WEEKS);

        // Get all the travelRouteList where weeks equals to UPDATED_WEEKS
        defaultTravelRouteShouldNotBeFound("weeks.equals=" + UPDATED_WEEKS);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByWeeksIsNotEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where weeks not equals to DEFAULT_WEEKS
        defaultTravelRouteShouldNotBeFound("weeks.notEquals=" + DEFAULT_WEEKS);

        // Get all the travelRouteList where weeks not equals to UPDATED_WEEKS
        defaultTravelRouteShouldBeFound("weeks.notEquals=" + UPDATED_WEEKS);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByWeeksIsInShouldWork() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where weeks in DEFAULT_WEEKS or UPDATED_WEEKS
        defaultTravelRouteShouldBeFound("weeks.in=" + DEFAULT_WEEKS + "," + UPDATED_WEEKS);

        // Get all the travelRouteList where weeks equals to UPDATED_WEEKS
        defaultTravelRouteShouldNotBeFound("weeks.in=" + UPDATED_WEEKS);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByWeeksIsNullOrNotNull() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where weeks is not null
        defaultTravelRouteShouldBeFound("weeks.specified=true");

        // Get all the travelRouteList where weeks is null
        defaultTravelRouteShouldNotBeFound("weeks.specified=false");
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByWeeksIsGreaterThanOrEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where weeks is greater than or equal to DEFAULT_WEEKS
        defaultTravelRouteShouldBeFound("weeks.greaterThanOrEqual=" + DEFAULT_WEEKS);

        // Get all the travelRouteList where weeks is greater than or equal to UPDATED_WEEKS
        defaultTravelRouteShouldNotBeFound("weeks.greaterThanOrEqual=" + UPDATED_WEEKS);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByWeeksIsLessThanOrEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where weeks is less than or equal to DEFAULT_WEEKS
        defaultTravelRouteShouldBeFound("weeks.lessThanOrEqual=" + DEFAULT_WEEKS);

        // Get all the travelRouteList where weeks is less than or equal to SMALLER_WEEKS
        defaultTravelRouteShouldNotBeFound("weeks.lessThanOrEqual=" + SMALLER_WEEKS);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByWeeksIsLessThanSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where weeks is less than DEFAULT_WEEKS
        defaultTravelRouteShouldNotBeFound("weeks.lessThan=" + DEFAULT_WEEKS);

        // Get all the travelRouteList where weeks is less than UPDATED_WEEKS
        defaultTravelRouteShouldBeFound("weeks.lessThan=" + UPDATED_WEEKS);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByWeeksIsGreaterThanSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where weeks is greater than DEFAULT_WEEKS
        defaultTravelRouteShouldNotBeFound("weeks.greaterThan=" + DEFAULT_WEEKS);

        // Get all the travelRouteList where weeks is greater than SMALLER_WEEKS
        defaultTravelRouteShouldBeFound("weeks.greaterThan=" + SMALLER_WEEKS);
    }


    @Test
    @Transactional
    public void getAllTravelRoutesBySeasonIsEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where season equals to DEFAULT_SEASON
        defaultTravelRouteShouldBeFound("season.equals=" + DEFAULT_SEASON);

        // Get all the travelRouteList where season equals to UPDATED_SEASON
        defaultTravelRouteShouldNotBeFound("season.equals=" + UPDATED_SEASON);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesBySeasonIsNotEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where season not equals to DEFAULT_SEASON
        defaultTravelRouteShouldNotBeFound("season.notEquals=" + DEFAULT_SEASON);

        // Get all the travelRouteList where season not equals to UPDATED_SEASON
        defaultTravelRouteShouldBeFound("season.notEquals=" + UPDATED_SEASON);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesBySeasonIsInShouldWork() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where season in DEFAULT_SEASON or UPDATED_SEASON
        defaultTravelRouteShouldBeFound("season.in=" + DEFAULT_SEASON + "," + UPDATED_SEASON);

        // Get all the travelRouteList where season equals to UPDATED_SEASON
        defaultTravelRouteShouldNotBeFound("season.in=" + UPDATED_SEASON);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesBySeasonIsNullOrNotNull() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where season is not null
        defaultTravelRouteShouldBeFound("season.specified=true");

        // Get all the travelRouteList where season is null
        defaultTravelRouteShouldNotBeFound("season.specified=false");
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByBudgetIsEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where budget equals to DEFAULT_BUDGET
        defaultTravelRouteShouldBeFound("budget.equals=" + DEFAULT_BUDGET);

        // Get all the travelRouteList where budget equals to UPDATED_BUDGET
        defaultTravelRouteShouldNotBeFound("budget.equals=" + UPDATED_BUDGET);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByBudgetIsNotEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where budget not equals to DEFAULT_BUDGET
        defaultTravelRouteShouldNotBeFound("budget.notEquals=" + DEFAULT_BUDGET);

        // Get all the travelRouteList where budget not equals to UPDATED_BUDGET
        defaultTravelRouteShouldBeFound("budget.notEquals=" + UPDATED_BUDGET);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByBudgetIsInShouldWork() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where budget in DEFAULT_BUDGET or UPDATED_BUDGET
        defaultTravelRouteShouldBeFound("budget.in=" + DEFAULT_BUDGET + "," + UPDATED_BUDGET);

        // Get all the travelRouteList where budget equals to UPDATED_BUDGET
        defaultTravelRouteShouldNotBeFound("budget.in=" + UPDATED_BUDGET);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByBudgetIsNullOrNotNull() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where budget is not null
        defaultTravelRouteShouldBeFound("budget.specified=true");

        // Get all the travelRouteList where budget is null
        defaultTravelRouteShouldNotBeFound("budget.specified=false");
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByBudgetIsGreaterThanOrEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where budget is greater than or equal to DEFAULT_BUDGET
        defaultTravelRouteShouldBeFound("budget.greaterThanOrEqual=" + DEFAULT_BUDGET);

        // Get all the travelRouteList where budget is greater than or equal to UPDATED_BUDGET
        defaultTravelRouteShouldNotBeFound("budget.greaterThanOrEqual=" + UPDATED_BUDGET);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByBudgetIsLessThanOrEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where budget is less than or equal to DEFAULT_BUDGET
        defaultTravelRouteShouldBeFound("budget.lessThanOrEqual=" + DEFAULT_BUDGET);

        // Get all the travelRouteList where budget is less than or equal to SMALLER_BUDGET
        defaultTravelRouteShouldNotBeFound("budget.lessThanOrEqual=" + SMALLER_BUDGET);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByBudgetIsLessThanSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where budget is less than DEFAULT_BUDGET
        defaultTravelRouteShouldNotBeFound("budget.lessThan=" + DEFAULT_BUDGET);

        // Get all the travelRouteList where budget is less than UPDATED_BUDGET
        defaultTravelRouteShouldBeFound("budget.lessThan=" + UPDATED_BUDGET);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByBudgetIsGreaterThanSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where budget is greater than DEFAULT_BUDGET
        defaultTravelRouteShouldNotBeFound("budget.greaterThan=" + DEFAULT_BUDGET);

        // Get all the travelRouteList where budget is greater than SMALLER_BUDGET
        defaultTravelRouteShouldBeFound("budget.greaterThan=" + SMALLER_BUDGET);
    }


    @Test
    @Transactional
    public void getAllTravelRoutesByCategoryIsEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where category equals to DEFAULT_CATEGORY
        defaultTravelRouteShouldBeFound("category.equals=" + DEFAULT_CATEGORY);

        // Get all the travelRouteList where category equals to UPDATED_CATEGORY
        defaultTravelRouteShouldNotBeFound("category.equals=" + UPDATED_CATEGORY);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByCategoryIsNotEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where category not equals to DEFAULT_CATEGORY
        defaultTravelRouteShouldNotBeFound("category.notEquals=" + DEFAULT_CATEGORY);

        // Get all the travelRouteList where category not equals to UPDATED_CATEGORY
        defaultTravelRouteShouldBeFound("category.notEquals=" + UPDATED_CATEGORY);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByCategoryIsInShouldWork() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where category in DEFAULT_CATEGORY or UPDATED_CATEGORY
        defaultTravelRouteShouldBeFound("category.in=" + DEFAULT_CATEGORY + "," + UPDATED_CATEGORY);

        // Get all the travelRouteList where category equals to UPDATED_CATEGORY
        defaultTravelRouteShouldNotBeFound("category.in=" + UPDATED_CATEGORY);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByCategoryIsNullOrNotNull() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where category is not null
        defaultTravelRouteShouldBeFound("category.specified=true");

        // Get all the travelRouteList where category is null
        defaultTravelRouteShouldNotBeFound("category.specified=false");
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByValueAverageIsEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where valueAverage equals to DEFAULT_VALUE_AVERAGE
        defaultTravelRouteShouldBeFound("valueAverage.equals=" + DEFAULT_VALUE_AVERAGE);

        // Get all the travelRouteList where valueAverage equals to UPDATED_VALUE_AVERAGE
        defaultTravelRouteShouldNotBeFound("valueAverage.equals=" + UPDATED_VALUE_AVERAGE);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByValueAverageIsNotEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where valueAverage not equals to DEFAULT_VALUE_AVERAGE
        defaultTravelRouteShouldNotBeFound("valueAverage.notEquals=" + DEFAULT_VALUE_AVERAGE);

        // Get all the travelRouteList where valueAverage not equals to UPDATED_VALUE_AVERAGE
        defaultTravelRouteShouldBeFound("valueAverage.notEquals=" + UPDATED_VALUE_AVERAGE);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByValueAverageIsInShouldWork() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where valueAverage in DEFAULT_VALUE_AVERAGE or UPDATED_VALUE_AVERAGE
        defaultTravelRouteShouldBeFound("valueAverage.in=" + DEFAULT_VALUE_AVERAGE + "," + UPDATED_VALUE_AVERAGE);

        // Get all the travelRouteList where valueAverage equals to UPDATED_VALUE_AVERAGE
        defaultTravelRouteShouldNotBeFound("valueAverage.in=" + UPDATED_VALUE_AVERAGE);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByValueAverageIsNullOrNotNull() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where valueAverage is not null
        defaultTravelRouteShouldBeFound("valueAverage.specified=true");

        // Get all the travelRouteList where valueAverage is null
        defaultTravelRouteShouldNotBeFound("valueAverage.specified=false");
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByValueAverageIsGreaterThanOrEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where valueAverage is greater than or equal to DEFAULT_VALUE_AVERAGE
        defaultTravelRouteShouldBeFound("valueAverage.greaterThanOrEqual=" + DEFAULT_VALUE_AVERAGE);

        // Get all the travelRouteList where valueAverage is greater than or equal to UPDATED_VALUE_AVERAGE
        defaultTravelRouteShouldNotBeFound("valueAverage.greaterThanOrEqual=" + UPDATED_VALUE_AVERAGE);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByValueAverageIsLessThanOrEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where valueAverage is less than or equal to DEFAULT_VALUE_AVERAGE
        defaultTravelRouteShouldBeFound("valueAverage.lessThanOrEqual=" + DEFAULT_VALUE_AVERAGE);

        // Get all the travelRouteList where valueAverage is less than or equal to SMALLER_VALUE_AVERAGE
        defaultTravelRouteShouldNotBeFound("valueAverage.lessThanOrEqual=" + SMALLER_VALUE_AVERAGE);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByValueAverageIsLessThanSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where valueAverage is less than DEFAULT_VALUE_AVERAGE
        defaultTravelRouteShouldNotBeFound("valueAverage.lessThan=" + DEFAULT_VALUE_AVERAGE);

        // Get all the travelRouteList where valueAverage is less than UPDATED_VALUE_AVERAGE
        defaultTravelRouteShouldBeFound("valueAverage.lessThan=" + UPDATED_VALUE_AVERAGE);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByValueAverageIsGreaterThanSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where valueAverage is greater than DEFAULT_VALUE_AVERAGE
        defaultTravelRouteShouldNotBeFound("valueAverage.greaterThan=" + DEFAULT_VALUE_AVERAGE);

        // Get all the travelRouteList where valueAverage is greater than SMALLER_VALUE_AVERAGE
        defaultTravelRouteShouldBeFound("valueAverage.greaterThan=" + SMALLER_VALUE_AVERAGE);
    }


    @Test
    @Transactional
    public void getAllTravelRoutesByDescriptionRouteSummaryIsEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where descriptionRouteSummary equals to DEFAULT_DESCRIPTION_ROUTE_SUMMARY
        defaultTravelRouteShouldBeFound("descriptionRouteSummary.equals=" + DEFAULT_DESCRIPTION_ROUTE_SUMMARY);

        // Get all the travelRouteList where descriptionRouteSummary equals to UPDATED_DESCRIPTION_ROUTE_SUMMARY
        defaultTravelRouteShouldNotBeFound("descriptionRouteSummary.equals=" + UPDATED_DESCRIPTION_ROUTE_SUMMARY);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByDescriptionRouteSummaryIsNotEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where descriptionRouteSummary not equals to DEFAULT_DESCRIPTION_ROUTE_SUMMARY
        defaultTravelRouteShouldNotBeFound("descriptionRouteSummary.notEquals=" + DEFAULT_DESCRIPTION_ROUTE_SUMMARY);

        // Get all the travelRouteList where descriptionRouteSummary not equals to UPDATED_DESCRIPTION_ROUTE_SUMMARY
        defaultTravelRouteShouldBeFound("descriptionRouteSummary.notEquals=" + UPDATED_DESCRIPTION_ROUTE_SUMMARY);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByDescriptionRouteSummaryIsInShouldWork() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where descriptionRouteSummary in DEFAULT_DESCRIPTION_ROUTE_SUMMARY or UPDATED_DESCRIPTION_ROUTE_SUMMARY
        defaultTravelRouteShouldBeFound("descriptionRouteSummary.in=" + DEFAULT_DESCRIPTION_ROUTE_SUMMARY + "," + UPDATED_DESCRIPTION_ROUTE_SUMMARY);

        // Get all the travelRouteList where descriptionRouteSummary equals to UPDATED_DESCRIPTION_ROUTE_SUMMARY
        defaultTravelRouteShouldNotBeFound("descriptionRouteSummary.in=" + UPDATED_DESCRIPTION_ROUTE_SUMMARY);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByDescriptionRouteSummaryIsNullOrNotNull() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where descriptionRouteSummary is not null
        defaultTravelRouteShouldBeFound("descriptionRouteSummary.specified=true");

        // Get all the travelRouteList where descriptionRouteSummary is null
        defaultTravelRouteShouldNotBeFound("descriptionRouteSummary.specified=false");
    }
                @Test
    @Transactional
    public void getAllTravelRoutesByDescriptionRouteSummaryContainsSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where descriptionRouteSummary contains DEFAULT_DESCRIPTION_ROUTE_SUMMARY
        defaultTravelRouteShouldBeFound("descriptionRouteSummary.contains=" + DEFAULT_DESCRIPTION_ROUTE_SUMMARY);

        // Get all the travelRouteList where descriptionRouteSummary contains UPDATED_DESCRIPTION_ROUTE_SUMMARY
        defaultTravelRouteShouldNotBeFound("descriptionRouteSummary.contains=" + UPDATED_DESCRIPTION_ROUTE_SUMMARY);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByDescriptionRouteSummaryNotContainsSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where descriptionRouteSummary does not contain DEFAULT_DESCRIPTION_ROUTE_SUMMARY
        defaultTravelRouteShouldNotBeFound("descriptionRouteSummary.doesNotContain=" + DEFAULT_DESCRIPTION_ROUTE_SUMMARY);

        // Get all the travelRouteList where descriptionRouteSummary does not contain UPDATED_DESCRIPTION_ROUTE_SUMMARY
        defaultTravelRouteShouldBeFound("descriptionRouteSummary.doesNotContain=" + UPDATED_DESCRIPTION_ROUTE_SUMMARY);
    }


    @Test
    @Transactional
    public void getAllTravelRoutesByDescriptionRouteIsEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where descriptionRoute equals to DEFAULT_DESCRIPTION_ROUTE
        defaultTravelRouteShouldBeFound("descriptionRoute.equals=" + DEFAULT_DESCRIPTION_ROUTE);

        // Get all the travelRouteList where descriptionRoute equals to UPDATED_DESCRIPTION_ROUTE
        defaultTravelRouteShouldNotBeFound("descriptionRoute.equals=" + UPDATED_DESCRIPTION_ROUTE);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByDescriptionRouteIsNotEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where descriptionRoute not equals to DEFAULT_DESCRIPTION_ROUTE
        defaultTravelRouteShouldNotBeFound("descriptionRoute.notEquals=" + DEFAULT_DESCRIPTION_ROUTE);

        // Get all the travelRouteList where descriptionRoute not equals to UPDATED_DESCRIPTION_ROUTE
        defaultTravelRouteShouldBeFound("descriptionRoute.notEquals=" + UPDATED_DESCRIPTION_ROUTE);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByDescriptionRouteIsInShouldWork() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where descriptionRoute in DEFAULT_DESCRIPTION_ROUTE or UPDATED_DESCRIPTION_ROUTE
        defaultTravelRouteShouldBeFound("descriptionRoute.in=" + DEFAULT_DESCRIPTION_ROUTE + "," + UPDATED_DESCRIPTION_ROUTE);

        // Get all the travelRouteList where descriptionRoute equals to UPDATED_DESCRIPTION_ROUTE
        defaultTravelRouteShouldNotBeFound("descriptionRoute.in=" + UPDATED_DESCRIPTION_ROUTE);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByDescriptionRouteIsNullOrNotNull() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where descriptionRoute is not null
        defaultTravelRouteShouldBeFound("descriptionRoute.specified=true");

        // Get all the travelRouteList where descriptionRoute is null
        defaultTravelRouteShouldNotBeFound("descriptionRoute.specified=false");
    }
                @Test
    @Transactional
    public void getAllTravelRoutesByDescriptionRouteContainsSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where descriptionRoute contains DEFAULT_DESCRIPTION_ROUTE
        defaultTravelRouteShouldBeFound("descriptionRoute.contains=" + DEFAULT_DESCRIPTION_ROUTE);

        // Get all the travelRouteList where descriptionRoute contains UPDATED_DESCRIPTION_ROUTE
        defaultTravelRouteShouldNotBeFound("descriptionRoute.contains=" + UPDATED_DESCRIPTION_ROUTE);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByDescriptionRouteNotContainsSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where descriptionRoute does not contain DEFAULT_DESCRIPTION_ROUTE
        defaultTravelRouteShouldNotBeFound("descriptionRoute.doesNotContain=" + DEFAULT_DESCRIPTION_ROUTE);

        // Get all the travelRouteList where descriptionRoute does not contain UPDATED_DESCRIPTION_ROUTE
        defaultTravelRouteShouldBeFound("descriptionRoute.doesNotContain=" + UPDATED_DESCRIPTION_ROUTE);
    }


    @Test
    @Transactional
    public void getAllTravelRoutesByStepsIsEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where steps equals to DEFAULT_STEPS
        defaultTravelRouteShouldBeFound("steps.equals=" + DEFAULT_STEPS);

        // Get all the travelRouteList where steps equals to UPDATED_STEPS
        defaultTravelRouteShouldNotBeFound("steps.equals=" + UPDATED_STEPS);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByStepsIsNotEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where steps not equals to DEFAULT_STEPS
        defaultTravelRouteShouldNotBeFound("steps.notEquals=" + DEFAULT_STEPS);

        // Get all the travelRouteList where steps not equals to UPDATED_STEPS
        defaultTravelRouteShouldBeFound("steps.notEquals=" + UPDATED_STEPS);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByStepsIsInShouldWork() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where steps in DEFAULT_STEPS or UPDATED_STEPS
        defaultTravelRouteShouldBeFound("steps.in=" + DEFAULT_STEPS + "," + UPDATED_STEPS);

        // Get all the travelRouteList where steps equals to UPDATED_STEPS
        defaultTravelRouteShouldNotBeFound("steps.in=" + UPDATED_STEPS);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByStepsIsNullOrNotNull() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where steps is not null
        defaultTravelRouteShouldBeFound("steps.specified=true");

        // Get all the travelRouteList where steps is null
        defaultTravelRouteShouldNotBeFound("steps.specified=false");
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByStepsIsGreaterThanOrEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where steps is greater than or equal to DEFAULT_STEPS
        defaultTravelRouteShouldBeFound("steps.greaterThanOrEqual=" + DEFAULT_STEPS);

        // Get all the travelRouteList where steps is greater than or equal to UPDATED_STEPS
        defaultTravelRouteShouldNotBeFound("steps.greaterThanOrEqual=" + UPDATED_STEPS);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByStepsIsLessThanOrEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where steps is less than or equal to DEFAULT_STEPS
        defaultTravelRouteShouldBeFound("steps.lessThanOrEqual=" + DEFAULT_STEPS);

        // Get all the travelRouteList where steps is less than or equal to SMALLER_STEPS
        defaultTravelRouteShouldNotBeFound("steps.lessThanOrEqual=" + SMALLER_STEPS);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByStepsIsLessThanSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where steps is less than DEFAULT_STEPS
        defaultTravelRouteShouldNotBeFound("steps.lessThan=" + DEFAULT_STEPS);

        // Get all the travelRouteList where steps is less than UPDATED_STEPS
        defaultTravelRouteShouldBeFound("steps.lessThan=" + UPDATED_STEPS);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByStepsIsGreaterThanSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where steps is greater than DEFAULT_STEPS
        defaultTravelRouteShouldNotBeFound("steps.greaterThan=" + DEFAULT_STEPS);

        // Get all the travelRouteList where steps is greater than SMALLER_STEPS
        defaultTravelRouteShouldBeFound("steps.greaterThan=" + SMALLER_STEPS);
    }


    @Test
    @Transactional
    public void getAllTravelRoutesBySummaryMapIsEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where summaryMap equals to DEFAULT_SUMMARY_MAP
        defaultTravelRouteShouldBeFound("summaryMap.equals=" + DEFAULT_SUMMARY_MAP);

        // Get all the travelRouteList where summaryMap equals to UPDATED_SUMMARY_MAP
        defaultTravelRouteShouldNotBeFound("summaryMap.equals=" + UPDATED_SUMMARY_MAP);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesBySummaryMapIsNotEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where summaryMap not equals to DEFAULT_SUMMARY_MAP
        defaultTravelRouteShouldNotBeFound("summaryMap.notEquals=" + DEFAULT_SUMMARY_MAP);

        // Get all the travelRouteList where summaryMap not equals to UPDATED_SUMMARY_MAP
        defaultTravelRouteShouldBeFound("summaryMap.notEquals=" + UPDATED_SUMMARY_MAP);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesBySummaryMapIsInShouldWork() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where summaryMap in DEFAULT_SUMMARY_MAP or UPDATED_SUMMARY_MAP
        defaultTravelRouteShouldBeFound("summaryMap.in=" + DEFAULT_SUMMARY_MAP + "," + UPDATED_SUMMARY_MAP);

        // Get all the travelRouteList where summaryMap equals to UPDATED_SUMMARY_MAP
        defaultTravelRouteShouldNotBeFound("summaryMap.in=" + UPDATED_SUMMARY_MAP);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesBySummaryMapIsNullOrNotNull() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where summaryMap is not null
        defaultTravelRouteShouldBeFound("summaryMap.specified=true");

        // Get all the travelRouteList where summaryMap is null
        defaultTravelRouteShouldNotBeFound("summaryMap.specified=false");
    }
                @Test
    @Transactional
    public void getAllTravelRoutesBySummaryMapContainsSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where summaryMap contains DEFAULT_SUMMARY_MAP
        defaultTravelRouteShouldBeFound("summaryMap.contains=" + DEFAULT_SUMMARY_MAP);

        // Get all the travelRouteList where summaryMap contains UPDATED_SUMMARY_MAP
        defaultTravelRouteShouldNotBeFound("summaryMap.contains=" + UPDATED_SUMMARY_MAP);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesBySummaryMapNotContainsSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where summaryMap does not contain DEFAULT_SUMMARY_MAP
        defaultTravelRouteShouldNotBeFound("summaryMap.doesNotContain=" + DEFAULT_SUMMARY_MAP);

        // Get all the travelRouteList where summaryMap does not contain UPDATED_SUMMARY_MAP
        defaultTravelRouteShouldBeFound("summaryMap.doesNotContain=" + UPDATED_SUMMARY_MAP);
    }


    @Test
    @Transactional
    public void getAllTravelRoutesByCreatedAtIsEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where createdAt equals to DEFAULT_CREATED_AT
        defaultTravelRouteShouldBeFound("createdAt.equals=" + DEFAULT_CREATED_AT);

        // Get all the travelRouteList where createdAt equals to UPDATED_CREATED_AT
        defaultTravelRouteShouldNotBeFound("createdAt.equals=" + UPDATED_CREATED_AT);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByCreatedAtIsNotEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where createdAt not equals to DEFAULT_CREATED_AT
        defaultTravelRouteShouldNotBeFound("createdAt.notEquals=" + DEFAULT_CREATED_AT);

        // Get all the travelRouteList where createdAt not equals to UPDATED_CREATED_AT
        defaultTravelRouteShouldBeFound("createdAt.notEquals=" + UPDATED_CREATED_AT);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByCreatedAtIsInShouldWork() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where createdAt in DEFAULT_CREATED_AT or UPDATED_CREATED_AT
        defaultTravelRouteShouldBeFound("createdAt.in=" + DEFAULT_CREATED_AT + "," + UPDATED_CREATED_AT);

        // Get all the travelRouteList where createdAt equals to UPDATED_CREATED_AT
        defaultTravelRouteShouldNotBeFound("createdAt.in=" + UPDATED_CREATED_AT);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByCreatedAtIsNullOrNotNull() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where createdAt is not null
        defaultTravelRouteShouldBeFound("createdAt.specified=true");

        // Get all the travelRouteList where createdAt is null
        defaultTravelRouteShouldNotBeFound("createdAt.specified=false");
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByCreatedAtIsGreaterThanOrEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where createdAt is greater than or equal to DEFAULT_CREATED_AT
        defaultTravelRouteShouldBeFound("createdAt.greaterThanOrEqual=" + DEFAULT_CREATED_AT);

        // Get all the travelRouteList where createdAt is greater than or equal to UPDATED_CREATED_AT
        defaultTravelRouteShouldNotBeFound("createdAt.greaterThanOrEqual=" + UPDATED_CREATED_AT);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByCreatedAtIsLessThanOrEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where createdAt is less than or equal to DEFAULT_CREATED_AT
        defaultTravelRouteShouldBeFound("createdAt.lessThanOrEqual=" + DEFAULT_CREATED_AT);

        // Get all the travelRouteList where createdAt is less than or equal to SMALLER_CREATED_AT
        defaultTravelRouteShouldNotBeFound("createdAt.lessThanOrEqual=" + SMALLER_CREATED_AT);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByCreatedAtIsLessThanSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where createdAt is less than DEFAULT_CREATED_AT
        defaultTravelRouteShouldNotBeFound("createdAt.lessThan=" + DEFAULT_CREATED_AT);

        // Get all the travelRouteList where createdAt is less than UPDATED_CREATED_AT
        defaultTravelRouteShouldBeFound("createdAt.lessThan=" + UPDATED_CREATED_AT);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByCreatedAtIsGreaterThanSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where createdAt is greater than DEFAULT_CREATED_AT
        defaultTravelRouteShouldNotBeFound("createdAt.greaterThan=" + DEFAULT_CREATED_AT);

        // Get all the travelRouteList where createdAt is greater than SMALLER_CREATED_AT
        defaultTravelRouteShouldBeFound("createdAt.greaterThan=" + SMALLER_CREATED_AT);
    }


    @Test
    @Transactional
    public void getAllTravelRoutesByUpdatedAtIsEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where updatedAt equals to DEFAULT_UPDATED_AT
        defaultTravelRouteShouldBeFound("updatedAt.equals=" + DEFAULT_UPDATED_AT);

        // Get all the travelRouteList where updatedAt equals to UPDATED_UPDATED_AT
        defaultTravelRouteShouldNotBeFound("updatedAt.equals=" + UPDATED_UPDATED_AT);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByUpdatedAtIsNotEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where updatedAt not equals to DEFAULT_UPDATED_AT
        defaultTravelRouteShouldNotBeFound("updatedAt.notEquals=" + DEFAULT_UPDATED_AT);

        // Get all the travelRouteList where updatedAt not equals to UPDATED_UPDATED_AT
        defaultTravelRouteShouldBeFound("updatedAt.notEquals=" + UPDATED_UPDATED_AT);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByUpdatedAtIsInShouldWork() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where updatedAt in DEFAULT_UPDATED_AT or UPDATED_UPDATED_AT
        defaultTravelRouteShouldBeFound("updatedAt.in=" + DEFAULT_UPDATED_AT + "," + UPDATED_UPDATED_AT);

        // Get all the travelRouteList where updatedAt equals to UPDATED_UPDATED_AT
        defaultTravelRouteShouldNotBeFound("updatedAt.in=" + UPDATED_UPDATED_AT);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByUpdatedAtIsNullOrNotNull() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where updatedAt is not null
        defaultTravelRouteShouldBeFound("updatedAt.specified=true");

        // Get all the travelRouteList where updatedAt is null
        defaultTravelRouteShouldNotBeFound("updatedAt.specified=false");
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByUpdatedAtIsGreaterThanOrEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where updatedAt is greater than or equal to DEFAULT_UPDATED_AT
        defaultTravelRouteShouldBeFound("updatedAt.greaterThanOrEqual=" + DEFAULT_UPDATED_AT);

        // Get all the travelRouteList where updatedAt is greater than or equal to UPDATED_UPDATED_AT
        defaultTravelRouteShouldNotBeFound("updatedAt.greaterThanOrEqual=" + UPDATED_UPDATED_AT);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByUpdatedAtIsLessThanOrEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where updatedAt is less than or equal to DEFAULT_UPDATED_AT
        defaultTravelRouteShouldBeFound("updatedAt.lessThanOrEqual=" + DEFAULT_UPDATED_AT);

        // Get all the travelRouteList where updatedAt is less than or equal to SMALLER_UPDATED_AT
        defaultTravelRouteShouldNotBeFound("updatedAt.lessThanOrEqual=" + SMALLER_UPDATED_AT);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByUpdatedAtIsLessThanSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where updatedAt is less than DEFAULT_UPDATED_AT
        defaultTravelRouteShouldNotBeFound("updatedAt.lessThan=" + DEFAULT_UPDATED_AT);

        // Get all the travelRouteList where updatedAt is less than UPDATED_UPDATED_AT
        defaultTravelRouteShouldBeFound("updatedAt.lessThan=" + UPDATED_UPDATED_AT);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByUpdatedAtIsGreaterThanSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where updatedAt is greater than DEFAULT_UPDATED_AT
        defaultTravelRouteShouldNotBeFound("updatedAt.greaterThan=" + DEFAULT_UPDATED_AT);

        // Get all the travelRouteList where updatedAt is greater than SMALLER_UPDATED_AT
        defaultTravelRouteShouldBeFound("updatedAt.greaterThan=" + SMALLER_UPDATED_AT);
    }


    @Test
    @Transactional
    public void getAllTravelRoutesByQrActivationIsEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where qrActivation equals to DEFAULT_QR_ACTIVATION
        defaultTravelRouteShouldBeFound("qrActivation.equals=" + DEFAULT_QR_ACTIVATION);

        // Get all the travelRouteList where qrActivation equals to UPDATED_QR_ACTIVATION
        defaultTravelRouteShouldNotBeFound("qrActivation.equals=" + UPDATED_QR_ACTIVATION);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByQrActivationIsNotEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where qrActivation not equals to DEFAULT_QR_ACTIVATION
        defaultTravelRouteShouldNotBeFound("qrActivation.notEquals=" + DEFAULT_QR_ACTIVATION);

        // Get all the travelRouteList where qrActivation not equals to UPDATED_QR_ACTIVATION
        defaultTravelRouteShouldBeFound("qrActivation.notEquals=" + UPDATED_QR_ACTIVATION);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByQrActivationIsInShouldWork() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where qrActivation in DEFAULT_QR_ACTIVATION or UPDATED_QR_ACTIVATION
        defaultTravelRouteShouldBeFound("qrActivation.in=" + DEFAULT_QR_ACTIVATION + "," + UPDATED_QR_ACTIVATION);

        // Get all the travelRouteList where qrActivation equals to UPDATED_QR_ACTIVATION
        defaultTravelRouteShouldNotBeFound("qrActivation.in=" + UPDATED_QR_ACTIVATION);
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByQrActivationIsNullOrNotNull() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);

        // Get all the travelRouteList where qrActivation is not null
        defaultTravelRouteShouldBeFound("qrActivation.specified=true");

        // Get all the travelRouteList where qrActivation is null
        defaultTravelRouteShouldNotBeFound("qrActivation.specified=false");
    }

    @Test
    @Transactional
    public void getAllTravelRoutesByCountryIsEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);
        Country country = CountryResourceIT.createEntity(em);
        em.persist(country);
        em.flush();
        travelRoute.setCountry(country);
        travelRouteRepository.saveAndFlush(travelRoute);
        Long countryId = country.getId();

        // Get all the travelRouteList where country equals to countryId
        defaultTravelRouteShouldBeFound("countryId.equals=" + countryId);

        // Get all the travelRouteList where country equals to countryId + 1
        defaultTravelRouteShouldNotBeFound("countryId.equals=" + (countryId + 1));
    }


    @Test
    @Transactional
    public void getAllTravelRoutesByLocationIsEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);
        Location location = LocationResourceIT.createEntity(em);
        em.persist(location);
        em.flush();
        travelRoute.addLocation(location);
        travelRouteRepository.saveAndFlush(travelRoute);
        Long locationId = location.getId();

        // Get all the travelRouteList where location equals to locationId
        defaultTravelRouteShouldBeFound("locationId.equals=" + locationId);

        // Get all the travelRouteList where location equals to locationId + 1
        defaultTravelRouteShouldNotBeFound("locationId.equals=" + (locationId + 1));
    }


    @Test
    @Transactional
    public void getAllTravelRoutesByGaleryIsEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);
        Photo galery = PhotoResourceIT.createEntity(em);
        em.persist(galery);
        em.flush();
        travelRoute.addGalery(galery);
        travelRouteRepository.saveAndFlush(travelRoute);
        Long galeryId = galery.getId();

        // Get all the travelRouteList where galery equals to galeryId
        defaultTravelRouteShouldBeFound("galeryId.equals=" + galeryId);

        // Get all the travelRouteList where galery equals to galeryId + 1
        defaultTravelRouteShouldNotBeFound("galeryId.equals=" + (galeryId + 1));
    }


    @Test
    @Transactional
    public void getAllTravelRoutesByValuationIsEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);
        Valuation valuation = ValuationResourceIT.createEntity(em);
        em.persist(valuation);
        em.flush();
        travelRoute.addValuation(valuation);
        travelRouteRepository.saveAndFlush(travelRoute);
        Long valuationId = valuation.getId();

        // Get all the travelRouteList where valuation equals to valuationId
        defaultTravelRouteShouldBeFound("valuationId.equals=" + valuationId);

        // Get all the travelRouteList where valuation equals to valuationId + 1
        defaultTravelRouteShouldNotBeFound("valuationId.equals=" + (valuationId + 1));
    }


    @Test
    @Transactional
    public void getAllTravelRoutesByQrIsEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);
        Qr qr = QrResourceIT.createEntity(em);
        em.persist(qr);
        em.flush();
        travelRoute.addQr(qr);
        travelRouteRepository.saveAndFlush(travelRoute);
        Long qrId = qr.getId();

        // Get all the travelRouteList where qr equals to qrId
        defaultTravelRouteShouldBeFound("qrId.equals=" + qrId);

        // Get all the travelRouteList where qr equals to qrId + 1
        defaultTravelRouteShouldNotBeFound("qrId.equals=" + (qrId + 1));
    }


    @Test
    @Transactional
    public void getAllTravelRoutesByUserProfileIsEqualToSomething() throws Exception {
        // Initialize the database
        travelRouteRepository.saveAndFlush(travelRoute);
        UserProfile userProfile = UserProfileResourceIT.createEntity(em);
        em.persist(userProfile);
        em.flush();
        travelRoute.setUserProfile(userProfile);
        travelRouteRepository.saveAndFlush(travelRoute);
        Long userProfileId = userProfile.getId();

        // Get all the travelRouteList where userProfile equals to userProfileId
        defaultTravelRouteShouldBeFound("userProfileId.equals=" + userProfileId);

        // Get all the travelRouteList where userProfile equals to userProfileId + 1
        defaultTravelRouteShouldNotBeFound("userProfileId.equals=" + (userProfileId + 1));
    }

    /**
     * Executes the search, and checks that the default entity is returned.
     */
    private void defaultTravelRouteShouldBeFound(String filter) throws Exception {
        restTravelRouteMockMvc.perform(get("/api/travel-routes?sort=id,desc&" + filter))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(travelRoute.getId().intValue())))
            .andExpect(jsonPath("$.[*].titleRoute").value(hasItem(DEFAULT_TITLE_ROUTE)))
            .andExpect(jsonPath("$.[*].destination").value(hasItem(DEFAULT_DESTINATION)))
            .andExpect(jsonPath("$.[*].continent").value(hasItem(DEFAULT_CONTINENT.toString())))
            .andExpect(jsonPath("$.[*].days").value(hasItem(DEFAULT_DAYS)))
            .andExpect(jsonPath("$.[*].weeks").value(hasItem(DEFAULT_WEEKS)))
            .andExpect(jsonPath("$.[*].season").value(hasItem(DEFAULT_SEASON.toString())))
            .andExpect(jsonPath("$.[*].budget").value(hasItem(DEFAULT_BUDGET.doubleValue())))
            .andExpect(jsonPath("$.[*].category").value(hasItem(DEFAULT_CATEGORY.toString())))
            .andExpect(jsonPath("$.[*].valueAverage").value(hasItem(DEFAULT_VALUE_AVERAGE.doubleValue())))
            .andExpect(jsonPath("$.[*].descriptionRouteSummary").value(hasItem(DEFAULT_DESCRIPTION_ROUTE_SUMMARY)))
            .andExpect(jsonPath("$.[*].descriptionRoute").value(hasItem(DEFAULT_DESCRIPTION_ROUTE)))
            .andExpect(jsonPath("$.[*].steps").value(hasItem(DEFAULT_STEPS)))
            .andExpect(jsonPath("$.[*].summaryMap").value(hasItem(DEFAULT_SUMMARY_MAP)))
            .andExpect(jsonPath("$.[*].createdAt").value(hasItem(DEFAULT_CREATED_AT.toString())))
            .andExpect(jsonPath("$.[*].updatedAt").value(hasItem(DEFAULT_UPDATED_AT.toString())))
            .andExpect(jsonPath("$.[*].qrActivation").value(hasItem(DEFAULT_QR_ACTIVATION.booleanValue())));

        // Check, that the count call also returns 1
        restTravelRouteMockMvc.perform(get("/api/travel-routes/count?sort=id,desc&" + filter))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(content().string("1"));
    }

    /**
     * Executes the search, and checks that the default entity is not returned.
     */
    private void defaultTravelRouteShouldNotBeFound(String filter) throws Exception {
        restTravelRouteMockMvc.perform(get("/api/travel-routes?sort=id,desc&" + filter))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$").isArray())
            .andExpect(jsonPath("$").isEmpty());

        // Check, that the count call also returns 0
        restTravelRouteMockMvc.perform(get("/api/travel-routes/count?sort=id,desc&" + filter))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(content().string("0"));
    }


    @Test
    @Transactional
    public void getNonExistingTravelRoute() throws Exception {
        // Get the travelRoute
        restTravelRouteMockMvc.perform(get("/api/travel-routes/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateTravelRoute() throws Exception {
        // Initialize the database
        travelRouteService.save(travelRoute);
        // As the test used the service layer, reset the Elasticsearch mock repository
        reset(mockTravelRouteSearchRepository);

        int databaseSizeBeforeUpdate = travelRouteRepository.findAll().size();

        // Update the travelRoute
        TravelRoute updatedTravelRoute = travelRouteRepository.findById(travelRoute.getId()).get();
        // Disconnect from session so that the updates on updatedTravelRoute are not directly saved in db
        em.detach(updatedTravelRoute);
        updatedTravelRoute
            .titleRoute(UPDATED_TITLE_ROUTE)
            .destination(UPDATED_DESTINATION)
            .continent(UPDATED_CONTINENT)
            .days(UPDATED_DAYS)
            .weeks(UPDATED_WEEKS)
            .season(UPDATED_SEASON)
            .budget(UPDATED_BUDGET)
            .category(UPDATED_CATEGORY)
            .valueAverage(UPDATED_VALUE_AVERAGE)
            .descriptionRouteSummary(UPDATED_DESCRIPTION_ROUTE_SUMMARY)
            .descriptionRoute(UPDATED_DESCRIPTION_ROUTE)
            .steps(UPDATED_STEPS)
            .summaryMap(UPDATED_SUMMARY_MAP)
            .createdAt(UPDATED_CREATED_AT)
            .updatedAt(UPDATED_UPDATED_AT)
            .qrActivation(UPDATED_QR_ACTIVATION);

        restTravelRouteMockMvc.perform(put("/api/travel-routes")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(updatedTravelRoute)))
            .andExpect(status().isOk());

        // Validate the TravelRoute in the database
        List<TravelRoute> travelRouteList = travelRouteRepository.findAll();
        assertThat(travelRouteList).hasSize(databaseSizeBeforeUpdate);
        TravelRoute testTravelRoute = travelRouteList.get(travelRouteList.size() - 1);
        assertThat(testTravelRoute.getTitleRoute()).isEqualTo(UPDATED_TITLE_ROUTE);
        assertThat(testTravelRoute.getDestination()).isEqualTo(UPDATED_DESTINATION);
        assertThat(testTravelRoute.getContinent()).isEqualTo(UPDATED_CONTINENT);
        assertThat(testTravelRoute.getDays()).isEqualTo(UPDATED_DAYS);
        assertThat(testTravelRoute.getWeeks()).isEqualTo(UPDATED_WEEKS);
        assertThat(testTravelRoute.getSeason()).isEqualTo(UPDATED_SEASON);
        assertThat(testTravelRoute.getBudget()).isEqualTo(UPDATED_BUDGET);
        assertThat(testTravelRoute.getCategory()).isEqualTo(UPDATED_CATEGORY);
        assertThat(testTravelRoute.getValueAverage()).isEqualTo(UPDATED_VALUE_AVERAGE);
        assertThat(testTravelRoute.getDescriptionRouteSummary()).isEqualTo(UPDATED_DESCRIPTION_ROUTE_SUMMARY);
        assertThat(testTravelRoute.getDescriptionRoute()).isEqualTo(UPDATED_DESCRIPTION_ROUTE);
        assertThat(testTravelRoute.getSteps()).isEqualTo(UPDATED_STEPS);
        assertThat(testTravelRoute.getSummaryMap()).isEqualTo(UPDATED_SUMMARY_MAP);
        assertThat(testTravelRoute.getCreatedAt()).isEqualTo(UPDATED_CREATED_AT);
        assertThat(testTravelRoute.getUpdatedAt()).isEqualTo(UPDATED_UPDATED_AT);
        assertThat(testTravelRoute.isQrActivation()).isEqualTo(UPDATED_QR_ACTIVATION);

        // Validate the TravelRoute in Elasticsearch
        verify(mockTravelRouteSearchRepository, times(1)).save(testTravelRoute);
    }

    @Test
    @Transactional
    public void updateNonExistingTravelRoute() throws Exception {
        int databaseSizeBeforeUpdate = travelRouteRepository.findAll().size();

        // Create the TravelRoute

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restTravelRouteMockMvc.perform(put("/api/travel-routes")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(travelRoute)))
            .andExpect(status().isBadRequest());

        // Validate the TravelRoute in the database
        List<TravelRoute> travelRouteList = travelRouteRepository.findAll();
        assertThat(travelRouteList).hasSize(databaseSizeBeforeUpdate);

        // Validate the TravelRoute in Elasticsearch
        verify(mockTravelRouteSearchRepository, times(0)).save(travelRoute);
    }

    @Test
    @Transactional
    public void deleteTravelRoute() throws Exception {
        // Initialize the database
        travelRouteService.save(travelRoute);

        int databaseSizeBeforeDelete = travelRouteRepository.findAll().size();

        // Delete the travelRoute
        restTravelRouteMockMvc.perform(delete("/api/travel-routes/{id}", travelRoute.getId())
            .accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<TravelRoute> travelRouteList = travelRouteRepository.findAll();
        assertThat(travelRouteList).hasSize(databaseSizeBeforeDelete - 1);

        // Validate the TravelRoute in Elasticsearch
        verify(mockTravelRouteSearchRepository, times(1)).deleteById(travelRoute.getId());
    }

    @Test
    @Transactional
    public void searchTravelRoute() throws Exception {
        // Initialize the database
        travelRouteService.save(travelRoute);
        when(mockTravelRouteSearchRepository.search(queryStringQuery("id:" + travelRoute.getId()), PageRequest.of(0, 20)))
            .thenReturn(new PageImpl<>(Collections.singletonList(travelRoute), PageRequest.of(0, 1), 1));
        // Search the travelRoute
        restTravelRouteMockMvc.perform(get("/api/_search/travel-routes?query=id:" + travelRoute.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(travelRoute.getId().intValue())))
            .andExpect(jsonPath("$.[*].titleRoute").value(hasItem(DEFAULT_TITLE_ROUTE)))
            .andExpect(jsonPath("$.[*].destination").value(hasItem(DEFAULT_DESTINATION)))
            .andExpect(jsonPath("$.[*].continent").value(hasItem(DEFAULT_CONTINENT.toString())))
            .andExpect(jsonPath("$.[*].days").value(hasItem(DEFAULT_DAYS)))
            .andExpect(jsonPath("$.[*].weeks").value(hasItem(DEFAULT_WEEKS)))
            .andExpect(jsonPath("$.[*].season").value(hasItem(DEFAULT_SEASON.toString())))
            .andExpect(jsonPath("$.[*].budget").value(hasItem(DEFAULT_BUDGET.doubleValue())))
            .andExpect(jsonPath("$.[*].category").value(hasItem(DEFAULT_CATEGORY.toString())))
            .andExpect(jsonPath("$.[*].valueAverage").value(hasItem(DEFAULT_VALUE_AVERAGE.doubleValue())))
            .andExpect(jsonPath("$.[*].descriptionRouteSummary").value(hasItem(DEFAULT_DESCRIPTION_ROUTE_SUMMARY)))
            .andExpect(jsonPath("$.[*].descriptionRoute").value(hasItem(DEFAULT_DESCRIPTION_ROUTE)))
            .andExpect(jsonPath("$.[*].steps").value(hasItem(DEFAULT_STEPS)))
            .andExpect(jsonPath("$.[*].summaryMap").value(hasItem(DEFAULT_SUMMARY_MAP)))
            .andExpect(jsonPath("$.[*].createdAt").value(hasItem(DEFAULT_CREATED_AT.toString())))
            .andExpect(jsonPath("$.[*].updatedAt").value(hasItem(DEFAULT_UPDATED_AT.toString())))
            .andExpect(jsonPath("$.[*].qrActivation").value(hasItem(DEFAULT_QR_ACTIVATION.booleanValue())));
    }
}
