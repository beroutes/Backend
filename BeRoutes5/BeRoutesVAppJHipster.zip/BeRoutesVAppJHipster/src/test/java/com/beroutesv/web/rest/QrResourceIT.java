package com.beroutesv.web.rest;

import com.beroutesv.BeRoutesVApp;
import com.beroutesv.domain.Qr;
import com.beroutesv.repository.QrRepository;
import com.beroutesv.repository.search.QrSearchRepository;
import com.beroutesv.service.QrService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;
import javax.persistence.EntityManager;
import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.elasticsearch.index.query.QueryBuilders.queryStringQuery;
import static org.hamcrest.Matchers.hasItem;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Integration tests for the {@link QrResource} REST controller.
 */
@SpringBootTest(classes = BeRoutesVApp.class)
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
@WithMockUser
public class QrResourceIT {

    private static final String DEFAULT_QR_DESCRIPTION = "AAAAAAAAAA";
    private static final String UPDATED_QR_DESCRIPTION = "BBBBBBBBBB";

    private static final Double DEFAULT_DATA_1 = 1D;
    private static final Double UPDATED_DATA_1 = 2D;

    private static final Double DEFAULT_DATA_2 = 1D;
    private static final Double UPDATED_DATA_2 = 2D;

    private static final Double DEFAULT_DATA_3 = 1D;
    private static final Double UPDATED_DATA_3 = 2D;

    @Autowired
    private QrRepository qrRepository;

    @Autowired
    private QrService qrService;

    /**
     * This repository is mocked in the com.beroutesv.repository.search test package.
     *
     * @see com.beroutesv.repository.search.QrSearchRepositoryMockConfiguration
     */
    @Autowired
    private QrSearchRepository mockQrSearchRepository;

    @Autowired
    private EntityManager em;

    @Autowired
    private MockMvc restQrMockMvc;

    private Qr qr;

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Qr createEntity(EntityManager em) {
        Qr qr = new Qr()
            .qrDescription(DEFAULT_QR_DESCRIPTION)
            .data1(DEFAULT_DATA_1)
            .data2(DEFAULT_DATA_2)
            .data3(DEFAULT_DATA_3);
        return qr;
    }
    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Qr createUpdatedEntity(EntityManager em) {
        Qr qr = new Qr()
            .qrDescription(UPDATED_QR_DESCRIPTION)
            .data1(UPDATED_DATA_1)
            .data2(UPDATED_DATA_2)
            .data3(UPDATED_DATA_3);
        return qr;
    }

    @BeforeEach
    public void initTest() {
        qr = createEntity(em);
    }

    @Test
    @Transactional
    public void createQr() throws Exception {
        int databaseSizeBeforeCreate = qrRepository.findAll().size();

        // Create the Qr
        restQrMockMvc.perform(post("/api/qrs")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(qr)))
            .andExpect(status().isCreated());

        // Validate the Qr in the database
        List<Qr> qrList = qrRepository.findAll();
        assertThat(qrList).hasSize(databaseSizeBeforeCreate + 1);
        Qr testQr = qrList.get(qrList.size() - 1);
        assertThat(testQr.getQrDescription()).isEqualTo(DEFAULT_QR_DESCRIPTION);
        assertThat(testQr.getData1()).isEqualTo(DEFAULT_DATA_1);
        assertThat(testQr.getData2()).isEqualTo(DEFAULT_DATA_2);
        assertThat(testQr.getData3()).isEqualTo(DEFAULT_DATA_3);

        // Validate the Qr in Elasticsearch
        verify(mockQrSearchRepository, times(1)).save(testQr);
    }

    @Test
    @Transactional
    public void createQrWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = qrRepository.findAll().size();

        // Create the Qr with an existing ID
        qr.setId(1L);

        // An entity with an existing ID cannot be created, so this API call must fail
        restQrMockMvc.perform(post("/api/qrs")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(qr)))
            .andExpect(status().isBadRequest());

        // Validate the Qr in the database
        List<Qr> qrList = qrRepository.findAll();
        assertThat(qrList).hasSize(databaseSizeBeforeCreate);

        // Validate the Qr in Elasticsearch
        verify(mockQrSearchRepository, times(0)).save(qr);
    }


    @Test
    @Transactional
    public void getAllQrs() throws Exception {
        // Initialize the database
        qrRepository.saveAndFlush(qr);

        // Get all the qrList
        restQrMockMvc.perform(get("/api/qrs?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(qr.getId().intValue())))
            .andExpect(jsonPath("$.[*].qrDescription").value(hasItem(DEFAULT_QR_DESCRIPTION)))
            .andExpect(jsonPath("$.[*].data1").value(hasItem(DEFAULT_DATA_1.doubleValue())))
            .andExpect(jsonPath("$.[*].data2").value(hasItem(DEFAULT_DATA_2.doubleValue())))
            .andExpect(jsonPath("$.[*].data3").value(hasItem(DEFAULT_DATA_3.doubleValue())));
    }
    
    @Test
    @Transactional
    public void getQr() throws Exception {
        // Initialize the database
        qrRepository.saveAndFlush(qr);

        // Get the qr
        restQrMockMvc.perform(get("/api/qrs/{id}", qr.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.id").value(qr.getId().intValue()))
            .andExpect(jsonPath("$.qrDescription").value(DEFAULT_QR_DESCRIPTION))
            .andExpect(jsonPath("$.data1").value(DEFAULT_DATA_1.doubleValue()))
            .andExpect(jsonPath("$.data2").value(DEFAULT_DATA_2.doubleValue()))
            .andExpect(jsonPath("$.data3").value(DEFAULT_DATA_3.doubleValue()));
    }

    @Test
    @Transactional
    public void getNonExistingQr() throws Exception {
        // Get the qr
        restQrMockMvc.perform(get("/api/qrs/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateQr() throws Exception {
        // Initialize the database
        qrService.save(qr);
        // As the test used the service layer, reset the Elasticsearch mock repository
        reset(mockQrSearchRepository);

        int databaseSizeBeforeUpdate = qrRepository.findAll().size();

        // Update the qr
        Qr updatedQr = qrRepository.findById(qr.getId()).get();
        // Disconnect from session so that the updates on updatedQr are not directly saved in db
        em.detach(updatedQr);
        updatedQr
            .qrDescription(UPDATED_QR_DESCRIPTION)
            .data1(UPDATED_DATA_1)
            .data2(UPDATED_DATA_2)
            .data3(UPDATED_DATA_3);

        restQrMockMvc.perform(put("/api/qrs")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(updatedQr)))
            .andExpect(status().isOk());

        // Validate the Qr in the database
        List<Qr> qrList = qrRepository.findAll();
        assertThat(qrList).hasSize(databaseSizeBeforeUpdate);
        Qr testQr = qrList.get(qrList.size() - 1);
        assertThat(testQr.getQrDescription()).isEqualTo(UPDATED_QR_DESCRIPTION);
        assertThat(testQr.getData1()).isEqualTo(UPDATED_DATA_1);
        assertThat(testQr.getData2()).isEqualTo(UPDATED_DATA_2);
        assertThat(testQr.getData3()).isEqualTo(UPDATED_DATA_3);

        // Validate the Qr in Elasticsearch
        verify(mockQrSearchRepository, times(1)).save(testQr);
    }

    @Test
    @Transactional
    public void updateNonExistingQr() throws Exception {
        int databaseSizeBeforeUpdate = qrRepository.findAll().size();

        // Create the Qr

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restQrMockMvc.perform(put("/api/qrs")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(qr)))
            .andExpect(status().isBadRequest());

        // Validate the Qr in the database
        List<Qr> qrList = qrRepository.findAll();
        assertThat(qrList).hasSize(databaseSizeBeforeUpdate);

        // Validate the Qr in Elasticsearch
        verify(mockQrSearchRepository, times(0)).save(qr);
    }

    @Test
    @Transactional
    public void deleteQr() throws Exception {
        // Initialize the database
        qrService.save(qr);

        int databaseSizeBeforeDelete = qrRepository.findAll().size();

        // Delete the qr
        restQrMockMvc.perform(delete("/api/qrs/{id}", qr.getId())
            .accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<Qr> qrList = qrRepository.findAll();
        assertThat(qrList).hasSize(databaseSizeBeforeDelete - 1);

        // Validate the Qr in Elasticsearch
        verify(mockQrSearchRepository, times(1)).deleteById(qr.getId());
    }

    @Test
    @Transactional
    public void searchQr() throws Exception {
        // Initialize the database
        qrService.save(qr);
        when(mockQrSearchRepository.search(queryStringQuery("id:" + qr.getId()), PageRequest.of(0, 20)))
            .thenReturn(new PageImpl<>(Collections.singletonList(qr), PageRequest.of(0, 1), 1));
        // Search the qr
        restQrMockMvc.perform(get("/api/_search/qrs?query=id:" + qr.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(qr.getId().intValue())))
            .andExpect(jsonPath("$.[*].qrDescription").value(hasItem(DEFAULT_QR_DESCRIPTION)))
            .andExpect(jsonPath("$.[*].data1").value(hasItem(DEFAULT_DATA_1.doubleValue())))
            .andExpect(jsonPath("$.[*].data2").value(hasItem(DEFAULT_DATA_2.doubleValue())))
            .andExpect(jsonPath("$.[*].data3").value(hasItem(DEFAULT_DATA_3.doubleValue())));
    }
}
