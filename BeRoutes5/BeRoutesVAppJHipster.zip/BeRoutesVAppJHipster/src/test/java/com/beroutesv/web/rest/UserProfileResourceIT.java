package com.beroutesv.web.rest;

import com.beroutesv.BeRoutesVApp;
import com.beroutesv.domain.UserProfile;
import com.beroutesv.domain.Country;
import com.beroutesv.domain.Photo;
import com.beroutesv.domain.TravelRoute;
import com.beroutesv.domain.Valuation;
import com.beroutesv.domain.Following;
import com.beroutesv.repository.UserProfileRepository;
import com.beroutesv.repository.search.UserProfileSearchRepository;
import com.beroutesv.service.UserProfileService;
import com.beroutesv.service.dto.UserProfileCriteria;
import com.beroutesv.service.UserProfileQueryService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;
import javax.persistence.EntityManager;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.elasticsearch.index.query.QueryBuilders.queryStringQuery;
import static org.hamcrest.Matchers.hasItem;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Integration tests for the {@link UserProfileResource} REST controller.
 */
@SpringBootTest(classes = BeRoutesVApp.class)
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
@WithMockUser
public class UserProfileResourceIT {

    private static final String DEFAULT_FIRST_NAME = "AAAAAAAAAA";
    private static final String UPDATED_FIRST_NAME = "BBBBBBBBBB";

    private static final String DEFAULT_LAST_NAME = "AAAAAAAAAA";
    private static final String UPDATED_LAST_NAME = "BBBBBBBBBB";

    private static final String DEFAULT_EMAIL = "AAAAAAAAAA";
    private static final String UPDATED_EMAIL = "BBBBBBBBBB";

    private static final Integer DEFAULT_TELEPHONE = 1;
    private static final Integer UPDATED_TELEPHONE = 2;
    private static final Integer SMALLER_TELEPHONE = 1 - 1;

    private static final String DEFAULT_USER_NAME = "AAAAAAAAAA";
    private static final String UPDATED_USER_NAME = "BBBBBBBBBB";

    private static final String DEFAULT_PASSWORD = "AAAAAAAAAA";
    private static final String UPDATED_PASSWORD = "BBBBBBBBBB";

    private static final Integer DEFAULT_AGE = 1;
    private static final Integer UPDATED_AGE = 2;
    private static final Integer SMALLER_AGE = 1 - 1;

    private static final String DEFAULT_BIOGRAPHY = "AAAAAAAAAA";
    private static final String UPDATED_BIOGRAPHY = "BBBBBBBBBB";

    private static final LocalDate DEFAULT_CREATED_AT = LocalDate.ofEpochDay(0L);
    private static final LocalDate UPDATED_CREATED_AT = LocalDate.now(ZoneId.systemDefault());
    private static final LocalDate SMALLER_CREATED_AT = LocalDate.ofEpochDay(-1L);

    private static final LocalDate DEFAULT_UPDATED_AT = LocalDate.ofEpochDay(0L);
    private static final LocalDate UPDATED_UPDATED_AT = LocalDate.now(ZoneId.systemDefault());
    private static final LocalDate SMALLER_UPDATED_AT = LocalDate.ofEpochDay(-1L);

    private static final Integer DEFAULT_FOLLOWER = 1;
    private static final Integer UPDATED_FOLLOWER = 2;
    private static final Integer SMALLER_FOLLOWER = 1 - 1;

    private static final Integer DEFAULT_FOLLOWED = 1;
    private static final Integer UPDATED_FOLLOWED = 2;
    private static final Integer SMALLER_FOLLOWED = 1 - 1;

    @Autowired
    private UserProfileRepository userProfileRepository;

    @Autowired
    private UserProfileService userProfileService;

    /**
     * This repository is mocked in the com.beroutesv.repository.search test package.
     *
     * @see com.beroutesv.repository.search.UserProfileSearchRepositoryMockConfiguration
     */
    @Autowired
    private UserProfileSearchRepository mockUserProfileSearchRepository;

    @Autowired
    private UserProfileQueryService userProfileQueryService;

    @Autowired
    private EntityManager em;

    @Autowired
    private MockMvc restUserProfileMockMvc;

    private UserProfile userProfile;

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static UserProfile createEntity(EntityManager em) {
        UserProfile userProfile = new UserProfile()
            .firstName(DEFAULT_FIRST_NAME)
            .lastName(DEFAULT_LAST_NAME)
            .email(DEFAULT_EMAIL)
            .telephone(DEFAULT_TELEPHONE)
            .userName(DEFAULT_USER_NAME)
            .password(DEFAULT_PASSWORD)
            .age(DEFAULT_AGE)
            .biography(DEFAULT_BIOGRAPHY)
            .createdAt(DEFAULT_CREATED_AT)
            .updatedAt(DEFAULT_UPDATED_AT)
            .follower(DEFAULT_FOLLOWER)
            .followed(DEFAULT_FOLLOWED);
        return userProfile;
    }
    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static UserProfile createUpdatedEntity(EntityManager em) {
        UserProfile userProfile = new UserProfile()
            .firstName(UPDATED_FIRST_NAME)
            .lastName(UPDATED_LAST_NAME)
            .email(UPDATED_EMAIL)
            .telephone(UPDATED_TELEPHONE)
            .userName(UPDATED_USER_NAME)
            .password(UPDATED_PASSWORD)
            .age(UPDATED_AGE)
            .biography(UPDATED_BIOGRAPHY)
            .createdAt(UPDATED_CREATED_AT)
            .updatedAt(UPDATED_UPDATED_AT)
            .follower(UPDATED_FOLLOWER)
            .followed(UPDATED_FOLLOWED);
        return userProfile;
    }

    @BeforeEach
    public void initTest() {
        userProfile = createEntity(em);
    }

    @Test
    @Transactional
    public void createUserProfile() throws Exception {
        int databaseSizeBeforeCreate = userProfileRepository.findAll().size();

        // Create the UserProfile
        restUserProfileMockMvc.perform(post("/api/user-profiles")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(userProfile)))
            .andExpect(status().isCreated());

        // Validate the UserProfile in the database
        List<UserProfile> userProfileList = userProfileRepository.findAll();
        assertThat(userProfileList).hasSize(databaseSizeBeforeCreate + 1);
        UserProfile testUserProfile = userProfileList.get(userProfileList.size() - 1);
        assertThat(testUserProfile.getFirstName()).isEqualTo(DEFAULT_FIRST_NAME);
        assertThat(testUserProfile.getLastName()).isEqualTo(DEFAULT_LAST_NAME);
        assertThat(testUserProfile.getEmail()).isEqualTo(DEFAULT_EMAIL);
        assertThat(testUserProfile.getTelephone()).isEqualTo(DEFAULT_TELEPHONE);
        assertThat(testUserProfile.getUserName()).isEqualTo(DEFAULT_USER_NAME);
        assertThat(testUserProfile.getPassword()).isEqualTo(DEFAULT_PASSWORD);
        assertThat(testUserProfile.getAge()).isEqualTo(DEFAULT_AGE);
        assertThat(testUserProfile.getBiography()).isEqualTo(DEFAULT_BIOGRAPHY);
        assertThat(testUserProfile.getCreatedAt()).isEqualTo(DEFAULT_CREATED_AT);
        assertThat(testUserProfile.getUpdatedAt()).isEqualTo(DEFAULT_UPDATED_AT);
        assertThat(testUserProfile.getFollower()).isEqualTo(DEFAULT_FOLLOWER);
        assertThat(testUserProfile.getFollowed()).isEqualTo(DEFAULT_FOLLOWED);

        // Validate the UserProfile in Elasticsearch
        verify(mockUserProfileSearchRepository, times(1)).save(testUserProfile);
    }

    @Test
    @Transactional
    public void createUserProfileWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = userProfileRepository.findAll().size();

        // Create the UserProfile with an existing ID
        userProfile.setId(1L);

        // An entity with an existing ID cannot be created, so this API call must fail
        restUserProfileMockMvc.perform(post("/api/user-profiles")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(userProfile)))
            .andExpect(status().isBadRequest());

        // Validate the UserProfile in the database
        List<UserProfile> userProfileList = userProfileRepository.findAll();
        assertThat(userProfileList).hasSize(databaseSizeBeforeCreate);

        // Validate the UserProfile in Elasticsearch
        verify(mockUserProfileSearchRepository, times(0)).save(userProfile);
    }


    @Test
    @Transactional
    public void getAllUserProfiles() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList
        restUserProfileMockMvc.perform(get("/api/user-profiles?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(userProfile.getId().intValue())))
            .andExpect(jsonPath("$.[*].firstName").value(hasItem(DEFAULT_FIRST_NAME)))
            .andExpect(jsonPath("$.[*].lastName").value(hasItem(DEFAULT_LAST_NAME)))
            .andExpect(jsonPath("$.[*].email").value(hasItem(DEFAULT_EMAIL)))
            .andExpect(jsonPath("$.[*].telephone").value(hasItem(DEFAULT_TELEPHONE)))
            .andExpect(jsonPath("$.[*].userName").value(hasItem(DEFAULT_USER_NAME)))
            .andExpect(jsonPath("$.[*].password").value(hasItem(DEFAULT_PASSWORD)))
            .andExpect(jsonPath("$.[*].age").value(hasItem(DEFAULT_AGE)))
            .andExpect(jsonPath("$.[*].biography").value(hasItem(DEFAULT_BIOGRAPHY)))
            .andExpect(jsonPath("$.[*].createdAt").value(hasItem(DEFAULT_CREATED_AT.toString())))
            .andExpect(jsonPath("$.[*].updatedAt").value(hasItem(DEFAULT_UPDATED_AT.toString())))
            .andExpect(jsonPath("$.[*].follower").value(hasItem(DEFAULT_FOLLOWER)))
            .andExpect(jsonPath("$.[*].followed").value(hasItem(DEFAULT_FOLLOWED)));
    }
    
    @Test
    @Transactional
    public void getUserProfile() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get the userProfile
        restUserProfileMockMvc.perform(get("/api/user-profiles/{id}", userProfile.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.id").value(userProfile.getId().intValue()))
            .andExpect(jsonPath("$.firstName").value(DEFAULT_FIRST_NAME))
            .andExpect(jsonPath("$.lastName").value(DEFAULT_LAST_NAME))
            .andExpect(jsonPath("$.email").value(DEFAULT_EMAIL))
            .andExpect(jsonPath("$.telephone").value(DEFAULT_TELEPHONE))
            .andExpect(jsonPath("$.userName").value(DEFAULT_USER_NAME))
            .andExpect(jsonPath("$.password").value(DEFAULT_PASSWORD))
            .andExpect(jsonPath("$.age").value(DEFAULT_AGE))
            .andExpect(jsonPath("$.biography").value(DEFAULT_BIOGRAPHY))
            .andExpect(jsonPath("$.createdAt").value(DEFAULT_CREATED_AT.toString()))
            .andExpect(jsonPath("$.updatedAt").value(DEFAULT_UPDATED_AT.toString()))
            .andExpect(jsonPath("$.follower").value(DEFAULT_FOLLOWER))
            .andExpect(jsonPath("$.followed").value(DEFAULT_FOLLOWED));
    }


    @Test
    @Transactional
    public void getUserProfilesByIdFiltering() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        Long id = userProfile.getId();

        defaultUserProfileShouldBeFound("id.equals=" + id);
        defaultUserProfileShouldNotBeFound("id.notEquals=" + id);

        defaultUserProfileShouldBeFound("id.greaterThanOrEqual=" + id);
        defaultUserProfileShouldNotBeFound("id.greaterThan=" + id);

        defaultUserProfileShouldBeFound("id.lessThanOrEqual=" + id);
        defaultUserProfileShouldNotBeFound("id.lessThan=" + id);
    }


    @Test
    @Transactional
    public void getAllUserProfilesByFirstNameIsEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where firstName equals to DEFAULT_FIRST_NAME
        defaultUserProfileShouldBeFound("firstName.equals=" + DEFAULT_FIRST_NAME);

        // Get all the userProfileList where firstName equals to UPDATED_FIRST_NAME
        defaultUserProfileShouldNotBeFound("firstName.equals=" + UPDATED_FIRST_NAME);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByFirstNameIsNotEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where firstName not equals to DEFAULT_FIRST_NAME
        defaultUserProfileShouldNotBeFound("firstName.notEquals=" + DEFAULT_FIRST_NAME);

        // Get all the userProfileList where firstName not equals to UPDATED_FIRST_NAME
        defaultUserProfileShouldBeFound("firstName.notEquals=" + UPDATED_FIRST_NAME);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByFirstNameIsInShouldWork() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where firstName in DEFAULT_FIRST_NAME or UPDATED_FIRST_NAME
        defaultUserProfileShouldBeFound("firstName.in=" + DEFAULT_FIRST_NAME + "," + UPDATED_FIRST_NAME);

        // Get all the userProfileList where firstName equals to UPDATED_FIRST_NAME
        defaultUserProfileShouldNotBeFound("firstName.in=" + UPDATED_FIRST_NAME);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByFirstNameIsNullOrNotNull() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where firstName is not null
        defaultUserProfileShouldBeFound("firstName.specified=true");

        // Get all the userProfileList where firstName is null
        defaultUserProfileShouldNotBeFound("firstName.specified=false");
    }
                @Test
    @Transactional
    public void getAllUserProfilesByFirstNameContainsSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where firstName contains DEFAULT_FIRST_NAME
        defaultUserProfileShouldBeFound("firstName.contains=" + DEFAULT_FIRST_NAME);

        // Get all the userProfileList where firstName contains UPDATED_FIRST_NAME
        defaultUserProfileShouldNotBeFound("firstName.contains=" + UPDATED_FIRST_NAME);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByFirstNameNotContainsSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where firstName does not contain DEFAULT_FIRST_NAME
        defaultUserProfileShouldNotBeFound("firstName.doesNotContain=" + DEFAULT_FIRST_NAME);

        // Get all the userProfileList where firstName does not contain UPDATED_FIRST_NAME
        defaultUserProfileShouldBeFound("firstName.doesNotContain=" + UPDATED_FIRST_NAME);
    }


    @Test
    @Transactional
    public void getAllUserProfilesByLastNameIsEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where lastName equals to DEFAULT_LAST_NAME
        defaultUserProfileShouldBeFound("lastName.equals=" + DEFAULT_LAST_NAME);

        // Get all the userProfileList where lastName equals to UPDATED_LAST_NAME
        defaultUserProfileShouldNotBeFound("lastName.equals=" + UPDATED_LAST_NAME);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByLastNameIsNotEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where lastName not equals to DEFAULT_LAST_NAME
        defaultUserProfileShouldNotBeFound("lastName.notEquals=" + DEFAULT_LAST_NAME);

        // Get all the userProfileList where lastName not equals to UPDATED_LAST_NAME
        defaultUserProfileShouldBeFound("lastName.notEquals=" + UPDATED_LAST_NAME);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByLastNameIsInShouldWork() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where lastName in DEFAULT_LAST_NAME or UPDATED_LAST_NAME
        defaultUserProfileShouldBeFound("lastName.in=" + DEFAULT_LAST_NAME + "," + UPDATED_LAST_NAME);

        // Get all the userProfileList where lastName equals to UPDATED_LAST_NAME
        defaultUserProfileShouldNotBeFound("lastName.in=" + UPDATED_LAST_NAME);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByLastNameIsNullOrNotNull() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where lastName is not null
        defaultUserProfileShouldBeFound("lastName.specified=true");

        // Get all the userProfileList where lastName is null
        defaultUserProfileShouldNotBeFound("lastName.specified=false");
    }
                @Test
    @Transactional
    public void getAllUserProfilesByLastNameContainsSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where lastName contains DEFAULT_LAST_NAME
        defaultUserProfileShouldBeFound("lastName.contains=" + DEFAULT_LAST_NAME);

        // Get all the userProfileList where lastName contains UPDATED_LAST_NAME
        defaultUserProfileShouldNotBeFound("lastName.contains=" + UPDATED_LAST_NAME);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByLastNameNotContainsSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where lastName does not contain DEFAULT_LAST_NAME
        defaultUserProfileShouldNotBeFound("lastName.doesNotContain=" + DEFAULT_LAST_NAME);

        // Get all the userProfileList where lastName does not contain UPDATED_LAST_NAME
        defaultUserProfileShouldBeFound("lastName.doesNotContain=" + UPDATED_LAST_NAME);
    }


    @Test
    @Transactional
    public void getAllUserProfilesByEmailIsEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where email equals to DEFAULT_EMAIL
        defaultUserProfileShouldBeFound("email.equals=" + DEFAULT_EMAIL);

        // Get all the userProfileList where email equals to UPDATED_EMAIL
        defaultUserProfileShouldNotBeFound("email.equals=" + UPDATED_EMAIL);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByEmailIsNotEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where email not equals to DEFAULT_EMAIL
        defaultUserProfileShouldNotBeFound("email.notEquals=" + DEFAULT_EMAIL);

        // Get all the userProfileList where email not equals to UPDATED_EMAIL
        defaultUserProfileShouldBeFound("email.notEquals=" + UPDATED_EMAIL);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByEmailIsInShouldWork() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where email in DEFAULT_EMAIL or UPDATED_EMAIL
        defaultUserProfileShouldBeFound("email.in=" + DEFAULT_EMAIL + "," + UPDATED_EMAIL);

        // Get all the userProfileList where email equals to UPDATED_EMAIL
        defaultUserProfileShouldNotBeFound("email.in=" + UPDATED_EMAIL);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByEmailIsNullOrNotNull() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where email is not null
        defaultUserProfileShouldBeFound("email.specified=true");

        // Get all the userProfileList where email is null
        defaultUserProfileShouldNotBeFound("email.specified=false");
    }
                @Test
    @Transactional
    public void getAllUserProfilesByEmailContainsSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where email contains DEFAULT_EMAIL
        defaultUserProfileShouldBeFound("email.contains=" + DEFAULT_EMAIL);

        // Get all the userProfileList where email contains UPDATED_EMAIL
        defaultUserProfileShouldNotBeFound("email.contains=" + UPDATED_EMAIL);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByEmailNotContainsSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where email does not contain DEFAULT_EMAIL
        defaultUserProfileShouldNotBeFound("email.doesNotContain=" + DEFAULT_EMAIL);

        // Get all the userProfileList where email does not contain UPDATED_EMAIL
        defaultUserProfileShouldBeFound("email.doesNotContain=" + UPDATED_EMAIL);
    }


    @Test
    @Transactional
    public void getAllUserProfilesByTelephoneIsEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where telephone equals to DEFAULT_TELEPHONE
        defaultUserProfileShouldBeFound("telephone.equals=" + DEFAULT_TELEPHONE);

        // Get all the userProfileList where telephone equals to UPDATED_TELEPHONE
        defaultUserProfileShouldNotBeFound("telephone.equals=" + UPDATED_TELEPHONE);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByTelephoneIsNotEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where telephone not equals to DEFAULT_TELEPHONE
        defaultUserProfileShouldNotBeFound("telephone.notEquals=" + DEFAULT_TELEPHONE);

        // Get all the userProfileList where telephone not equals to UPDATED_TELEPHONE
        defaultUserProfileShouldBeFound("telephone.notEquals=" + UPDATED_TELEPHONE);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByTelephoneIsInShouldWork() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where telephone in DEFAULT_TELEPHONE or UPDATED_TELEPHONE
        defaultUserProfileShouldBeFound("telephone.in=" + DEFAULT_TELEPHONE + "," + UPDATED_TELEPHONE);

        // Get all the userProfileList where telephone equals to UPDATED_TELEPHONE
        defaultUserProfileShouldNotBeFound("telephone.in=" + UPDATED_TELEPHONE);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByTelephoneIsNullOrNotNull() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where telephone is not null
        defaultUserProfileShouldBeFound("telephone.specified=true");

        // Get all the userProfileList where telephone is null
        defaultUserProfileShouldNotBeFound("telephone.specified=false");
    }

    @Test
    @Transactional
    public void getAllUserProfilesByTelephoneIsGreaterThanOrEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where telephone is greater than or equal to DEFAULT_TELEPHONE
        defaultUserProfileShouldBeFound("telephone.greaterThanOrEqual=" + DEFAULT_TELEPHONE);

        // Get all the userProfileList where telephone is greater than or equal to UPDATED_TELEPHONE
        defaultUserProfileShouldNotBeFound("telephone.greaterThanOrEqual=" + UPDATED_TELEPHONE);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByTelephoneIsLessThanOrEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where telephone is less than or equal to DEFAULT_TELEPHONE
        defaultUserProfileShouldBeFound("telephone.lessThanOrEqual=" + DEFAULT_TELEPHONE);

        // Get all the userProfileList where telephone is less than or equal to SMALLER_TELEPHONE
        defaultUserProfileShouldNotBeFound("telephone.lessThanOrEqual=" + SMALLER_TELEPHONE);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByTelephoneIsLessThanSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where telephone is less than DEFAULT_TELEPHONE
        defaultUserProfileShouldNotBeFound("telephone.lessThan=" + DEFAULT_TELEPHONE);

        // Get all the userProfileList where telephone is less than UPDATED_TELEPHONE
        defaultUserProfileShouldBeFound("telephone.lessThan=" + UPDATED_TELEPHONE);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByTelephoneIsGreaterThanSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where telephone is greater than DEFAULT_TELEPHONE
        defaultUserProfileShouldNotBeFound("telephone.greaterThan=" + DEFAULT_TELEPHONE);

        // Get all the userProfileList where telephone is greater than SMALLER_TELEPHONE
        defaultUserProfileShouldBeFound("telephone.greaterThan=" + SMALLER_TELEPHONE);
    }


    @Test
    @Transactional
    public void getAllUserProfilesByUserNameIsEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where userName equals to DEFAULT_USER_NAME
        defaultUserProfileShouldBeFound("userName.equals=" + DEFAULT_USER_NAME);

        // Get all the userProfileList where userName equals to UPDATED_USER_NAME
        defaultUserProfileShouldNotBeFound("userName.equals=" + UPDATED_USER_NAME);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByUserNameIsNotEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where userName not equals to DEFAULT_USER_NAME
        defaultUserProfileShouldNotBeFound("userName.notEquals=" + DEFAULT_USER_NAME);

        // Get all the userProfileList where userName not equals to UPDATED_USER_NAME
        defaultUserProfileShouldBeFound("userName.notEquals=" + UPDATED_USER_NAME);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByUserNameIsInShouldWork() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where userName in DEFAULT_USER_NAME or UPDATED_USER_NAME
        defaultUserProfileShouldBeFound("userName.in=" + DEFAULT_USER_NAME + "," + UPDATED_USER_NAME);

        // Get all the userProfileList where userName equals to UPDATED_USER_NAME
        defaultUserProfileShouldNotBeFound("userName.in=" + UPDATED_USER_NAME);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByUserNameIsNullOrNotNull() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where userName is not null
        defaultUserProfileShouldBeFound("userName.specified=true");

        // Get all the userProfileList where userName is null
        defaultUserProfileShouldNotBeFound("userName.specified=false");
    }
                @Test
    @Transactional
    public void getAllUserProfilesByUserNameContainsSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where userName contains DEFAULT_USER_NAME
        defaultUserProfileShouldBeFound("userName.contains=" + DEFAULT_USER_NAME);

        // Get all the userProfileList where userName contains UPDATED_USER_NAME
        defaultUserProfileShouldNotBeFound("userName.contains=" + UPDATED_USER_NAME);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByUserNameNotContainsSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where userName does not contain DEFAULT_USER_NAME
        defaultUserProfileShouldNotBeFound("userName.doesNotContain=" + DEFAULT_USER_NAME);

        // Get all the userProfileList where userName does not contain UPDATED_USER_NAME
        defaultUserProfileShouldBeFound("userName.doesNotContain=" + UPDATED_USER_NAME);
    }


    @Test
    @Transactional
    public void getAllUserProfilesByPasswordIsEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where password equals to DEFAULT_PASSWORD
        defaultUserProfileShouldBeFound("password.equals=" + DEFAULT_PASSWORD);

        // Get all the userProfileList where password equals to UPDATED_PASSWORD
        defaultUserProfileShouldNotBeFound("password.equals=" + UPDATED_PASSWORD);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByPasswordIsNotEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where password not equals to DEFAULT_PASSWORD
        defaultUserProfileShouldNotBeFound("password.notEquals=" + DEFAULT_PASSWORD);

        // Get all the userProfileList where password not equals to UPDATED_PASSWORD
        defaultUserProfileShouldBeFound("password.notEquals=" + UPDATED_PASSWORD);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByPasswordIsInShouldWork() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where password in DEFAULT_PASSWORD or UPDATED_PASSWORD
        defaultUserProfileShouldBeFound("password.in=" + DEFAULT_PASSWORD + "," + UPDATED_PASSWORD);

        // Get all the userProfileList where password equals to UPDATED_PASSWORD
        defaultUserProfileShouldNotBeFound("password.in=" + UPDATED_PASSWORD);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByPasswordIsNullOrNotNull() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where password is not null
        defaultUserProfileShouldBeFound("password.specified=true");

        // Get all the userProfileList where password is null
        defaultUserProfileShouldNotBeFound("password.specified=false");
    }
                @Test
    @Transactional
    public void getAllUserProfilesByPasswordContainsSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where password contains DEFAULT_PASSWORD
        defaultUserProfileShouldBeFound("password.contains=" + DEFAULT_PASSWORD);

        // Get all the userProfileList where password contains UPDATED_PASSWORD
        defaultUserProfileShouldNotBeFound("password.contains=" + UPDATED_PASSWORD);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByPasswordNotContainsSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where password does not contain DEFAULT_PASSWORD
        defaultUserProfileShouldNotBeFound("password.doesNotContain=" + DEFAULT_PASSWORD);

        // Get all the userProfileList where password does not contain UPDATED_PASSWORD
        defaultUserProfileShouldBeFound("password.doesNotContain=" + UPDATED_PASSWORD);
    }


    @Test
    @Transactional
    public void getAllUserProfilesByAgeIsEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where age equals to DEFAULT_AGE
        defaultUserProfileShouldBeFound("age.equals=" + DEFAULT_AGE);

        // Get all the userProfileList where age equals to UPDATED_AGE
        defaultUserProfileShouldNotBeFound("age.equals=" + UPDATED_AGE);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByAgeIsNotEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where age not equals to DEFAULT_AGE
        defaultUserProfileShouldNotBeFound("age.notEquals=" + DEFAULT_AGE);

        // Get all the userProfileList where age not equals to UPDATED_AGE
        defaultUserProfileShouldBeFound("age.notEquals=" + UPDATED_AGE);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByAgeIsInShouldWork() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where age in DEFAULT_AGE or UPDATED_AGE
        defaultUserProfileShouldBeFound("age.in=" + DEFAULT_AGE + "," + UPDATED_AGE);

        // Get all the userProfileList where age equals to UPDATED_AGE
        defaultUserProfileShouldNotBeFound("age.in=" + UPDATED_AGE);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByAgeIsNullOrNotNull() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where age is not null
        defaultUserProfileShouldBeFound("age.specified=true");

        // Get all the userProfileList where age is null
        defaultUserProfileShouldNotBeFound("age.specified=false");
    }

    @Test
    @Transactional
    public void getAllUserProfilesByAgeIsGreaterThanOrEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where age is greater than or equal to DEFAULT_AGE
        defaultUserProfileShouldBeFound("age.greaterThanOrEqual=" + DEFAULT_AGE);

        // Get all the userProfileList where age is greater than or equal to UPDATED_AGE
        defaultUserProfileShouldNotBeFound("age.greaterThanOrEqual=" + UPDATED_AGE);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByAgeIsLessThanOrEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where age is less than or equal to DEFAULT_AGE
        defaultUserProfileShouldBeFound("age.lessThanOrEqual=" + DEFAULT_AGE);

        // Get all the userProfileList where age is less than or equal to SMALLER_AGE
        defaultUserProfileShouldNotBeFound("age.lessThanOrEqual=" + SMALLER_AGE);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByAgeIsLessThanSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where age is less than DEFAULT_AGE
        defaultUserProfileShouldNotBeFound("age.lessThan=" + DEFAULT_AGE);

        // Get all the userProfileList where age is less than UPDATED_AGE
        defaultUserProfileShouldBeFound("age.lessThan=" + UPDATED_AGE);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByAgeIsGreaterThanSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where age is greater than DEFAULT_AGE
        defaultUserProfileShouldNotBeFound("age.greaterThan=" + DEFAULT_AGE);

        // Get all the userProfileList where age is greater than SMALLER_AGE
        defaultUserProfileShouldBeFound("age.greaterThan=" + SMALLER_AGE);
    }


    @Test
    @Transactional
    public void getAllUserProfilesByBiographyIsEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where biography equals to DEFAULT_BIOGRAPHY
        defaultUserProfileShouldBeFound("biography.equals=" + DEFAULT_BIOGRAPHY);

        // Get all the userProfileList where biography equals to UPDATED_BIOGRAPHY
        defaultUserProfileShouldNotBeFound("biography.equals=" + UPDATED_BIOGRAPHY);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByBiographyIsNotEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where biography not equals to DEFAULT_BIOGRAPHY
        defaultUserProfileShouldNotBeFound("biography.notEquals=" + DEFAULT_BIOGRAPHY);

        // Get all the userProfileList where biography not equals to UPDATED_BIOGRAPHY
        defaultUserProfileShouldBeFound("biography.notEquals=" + UPDATED_BIOGRAPHY);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByBiographyIsInShouldWork() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where biography in DEFAULT_BIOGRAPHY or UPDATED_BIOGRAPHY
        defaultUserProfileShouldBeFound("biography.in=" + DEFAULT_BIOGRAPHY + "," + UPDATED_BIOGRAPHY);

        // Get all the userProfileList where biography equals to UPDATED_BIOGRAPHY
        defaultUserProfileShouldNotBeFound("biography.in=" + UPDATED_BIOGRAPHY);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByBiographyIsNullOrNotNull() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where biography is not null
        defaultUserProfileShouldBeFound("biography.specified=true");

        // Get all the userProfileList where biography is null
        defaultUserProfileShouldNotBeFound("biography.specified=false");
    }
                @Test
    @Transactional
    public void getAllUserProfilesByBiographyContainsSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where biography contains DEFAULT_BIOGRAPHY
        defaultUserProfileShouldBeFound("biography.contains=" + DEFAULT_BIOGRAPHY);

        // Get all the userProfileList where biography contains UPDATED_BIOGRAPHY
        defaultUserProfileShouldNotBeFound("biography.contains=" + UPDATED_BIOGRAPHY);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByBiographyNotContainsSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where biography does not contain DEFAULT_BIOGRAPHY
        defaultUserProfileShouldNotBeFound("biography.doesNotContain=" + DEFAULT_BIOGRAPHY);

        // Get all the userProfileList where biography does not contain UPDATED_BIOGRAPHY
        defaultUserProfileShouldBeFound("biography.doesNotContain=" + UPDATED_BIOGRAPHY);
    }


    @Test
    @Transactional
    public void getAllUserProfilesByCreatedAtIsEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where createdAt equals to DEFAULT_CREATED_AT
        defaultUserProfileShouldBeFound("createdAt.equals=" + DEFAULT_CREATED_AT);

        // Get all the userProfileList where createdAt equals to UPDATED_CREATED_AT
        defaultUserProfileShouldNotBeFound("createdAt.equals=" + UPDATED_CREATED_AT);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByCreatedAtIsNotEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where createdAt not equals to DEFAULT_CREATED_AT
        defaultUserProfileShouldNotBeFound("createdAt.notEquals=" + DEFAULT_CREATED_AT);

        // Get all the userProfileList where createdAt not equals to UPDATED_CREATED_AT
        defaultUserProfileShouldBeFound("createdAt.notEquals=" + UPDATED_CREATED_AT);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByCreatedAtIsInShouldWork() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where createdAt in DEFAULT_CREATED_AT or UPDATED_CREATED_AT
        defaultUserProfileShouldBeFound("createdAt.in=" + DEFAULT_CREATED_AT + "," + UPDATED_CREATED_AT);

        // Get all the userProfileList where createdAt equals to UPDATED_CREATED_AT
        defaultUserProfileShouldNotBeFound("createdAt.in=" + UPDATED_CREATED_AT);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByCreatedAtIsNullOrNotNull() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where createdAt is not null
        defaultUserProfileShouldBeFound("createdAt.specified=true");

        // Get all the userProfileList where createdAt is null
        defaultUserProfileShouldNotBeFound("createdAt.specified=false");
    }

    @Test
    @Transactional
    public void getAllUserProfilesByCreatedAtIsGreaterThanOrEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where createdAt is greater than or equal to DEFAULT_CREATED_AT
        defaultUserProfileShouldBeFound("createdAt.greaterThanOrEqual=" + DEFAULT_CREATED_AT);

        // Get all the userProfileList where createdAt is greater than or equal to UPDATED_CREATED_AT
        defaultUserProfileShouldNotBeFound("createdAt.greaterThanOrEqual=" + UPDATED_CREATED_AT);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByCreatedAtIsLessThanOrEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where createdAt is less than or equal to DEFAULT_CREATED_AT
        defaultUserProfileShouldBeFound("createdAt.lessThanOrEqual=" + DEFAULT_CREATED_AT);

        // Get all the userProfileList where createdAt is less than or equal to SMALLER_CREATED_AT
        defaultUserProfileShouldNotBeFound("createdAt.lessThanOrEqual=" + SMALLER_CREATED_AT);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByCreatedAtIsLessThanSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where createdAt is less than DEFAULT_CREATED_AT
        defaultUserProfileShouldNotBeFound("createdAt.lessThan=" + DEFAULT_CREATED_AT);

        // Get all the userProfileList where createdAt is less than UPDATED_CREATED_AT
        defaultUserProfileShouldBeFound("createdAt.lessThan=" + UPDATED_CREATED_AT);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByCreatedAtIsGreaterThanSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where createdAt is greater than DEFAULT_CREATED_AT
        defaultUserProfileShouldNotBeFound("createdAt.greaterThan=" + DEFAULT_CREATED_AT);

        // Get all the userProfileList where createdAt is greater than SMALLER_CREATED_AT
        defaultUserProfileShouldBeFound("createdAt.greaterThan=" + SMALLER_CREATED_AT);
    }


    @Test
    @Transactional
    public void getAllUserProfilesByUpdatedAtIsEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where updatedAt equals to DEFAULT_UPDATED_AT
        defaultUserProfileShouldBeFound("updatedAt.equals=" + DEFAULT_UPDATED_AT);

        // Get all the userProfileList where updatedAt equals to UPDATED_UPDATED_AT
        defaultUserProfileShouldNotBeFound("updatedAt.equals=" + UPDATED_UPDATED_AT);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByUpdatedAtIsNotEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where updatedAt not equals to DEFAULT_UPDATED_AT
        defaultUserProfileShouldNotBeFound("updatedAt.notEquals=" + DEFAULT_UPDATED_AT);

        // Get all the userProfileList where updatedAt not equals to UPDATED_UPDATED_AT
        defaultUserProfileShouldBeFound("updatedAt.notEquals=" + UPDATED_UPDATED_AT);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByUpdatedAtIsInShouldWork() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where updatedAt in DEFAULT_UPDATED_AT or UPDATED_UPDATED_AT
        defaultUserProfileShouldBeFound("updatedAt.in=" + DEFAULT_UPDATED_AT + "," + UPDATED_UPDATED_AT);

        // Get all the userProfileList where updatedAt equals to UPDATED_UPDATED_AT
        defaultUserProfileShouldNotBeFound("updatedAt.in=" + UPDATED_UPDATED_AT);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByUpdatedAtIsNullOrNotNull() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where updatedAt is not null
        defaultUserProfileShouldBeFound("updatedAt.specified=true");

        // Get all the userProfileList where updatedAt is null
        defaultUserProfileShouldNotBeFound("updatedAt.specified=false");
    }

    @Test
    @Transactional
    public void getAllUserProfilesByUpdatedAtIsGreaterThanOrEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where updatedAt is greater than or equal to DEFAULT_UPDATED_AT
        defaultUserProfileShouldBeFound("updatedAt.greaterThanOrEqual=" + DEFAULT_UPDATED_AT);

        // Get all the userProfileList where updatedAt is greater than or equal to UPDATED_UPDATED_AT
        defaultUserProfileShouldNotBeFound("updatedAt.greaterThanOrEqual=" + UPDATED_UPDATED_AT);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByUpdatedAtIsLessThanOrEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where updatedAt is less than or equal to DEFAULT_UPDATED_AT
        defaultUserProfileShouldBeFound("updatedAt.lessThanOrEqual=" + DEFAULT_UPDATED_AT);

        // Get all the userProfileList where updatedAt is less than or equal to SMALLER_UPDATED_AT
        defaultUserProfileShouldNotBeFound("updatedAt.lessThanOrEqual=" + SMALLER_UPDATED_AT);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByUpdatedAtIsLessThanSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where updatedAt is less than DEFAULT_UPDATED_AT
        defaultUserProfileShouldNotBeFound("updatedAt.lessThan=" + DEFAULT_UPDATED_AT);

        // Get all the userProfileList where updatedAt is less than UPDATED_UPDATED_AT
        defaultUserProfileShouldBeFound("updatedAt.lessThan=" + UPDATED_UPDATED_AT);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByUpdatedAtIsGreaterThanSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where updatedAt is greater than DEFAULT_UPDATED_AT
        defaultUserProfileShouldNotBeFound("updatedAt.greaterThan=" + DEFAULT_UPDATED_AT);

        // Get all the userProfileList where updatedAt is greater than SMALLER_UPDATED_AT
        defaultUserProfileShouldBeFound("updatedAt.greaterThan=" + SMALLER_UPDATED_AT);
    }


    @Test
    @Transactional
    public void getAllUserProfilesByFollowerIsEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where follower equals to DEFAULT_FOLLOWER
        defaultUserProfileShouldBeFound("follower.equals=" + DEFAULT_FOLLOWER);

        // Get all the userProfileList where follower equals to UPDATED_FOLLOWER
        defaultUserProfileShouldNotBeFound("follower.equals=" + UPDATED_FOLLOWER);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByFollowerIsNotEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where follower not equals to DEFAULT_FOLLOWER
        defaultUserProfileShouldNotBeFound("follower.notEquals=" + DEFAULT_FOLLOWER);

        // Get all the userProfileList where follower not equals to UPDATED_FOLLOWER
        defaultUserProfileShouldBeFound("follower.notEquals=" + UPDATED_FOLLOWER);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByFollowerIsInShouldWork() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where follower in DEFAULT_FOLLOWER or UPDATED_FOLLOWER
        defaultUserProfileShouldBeFound("follower.in=" + DEFAULT_FOLLOWER + "," + UPDATED_FOLLOWER);

        // Get all the userProfileList where follower equals to UPDATED_FOLLOWER
        defaultUserProfileShouldNotBeFound("follower.in=" + UPDATED_FOLLOWER);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByFollowerIsNullOrNotNull() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where follower is not null
        defaultUserProfileShouldBeFound("follower.specified=true");

        // Get all the userProfileList where follower is null
        defaultUserProfileShouldNotBeFound("follower.specified=false");
    }

    @Test
    @Transactional
    public void getAllUserProfilesByFollowerIsGreaterThanOrEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where follower is greater than or equal to DEFAULT_FOLLOWER
        defaultUserProfileShouldBeFound("follower.greaterThanOrEqual=" + DEFAULT_FOLLOWER);

        // Get all the userProfileList where follower is greater than or equal to UPDATED_FOLLOWER
        defaultUserProfileShouldNotBeFound("follower.greaterThanOrEqual=" + UPDATED_FOLLOWER);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByFollowerIsLessThanOrEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where follower is less than or equal to DEFAULT_FOLLOWER
        defaultUserProfileShouldBeFound("follower.lessThanOrEqual=" + DEFAULT_FOLLOWER);

        // Get all the userProfileList where follower is less than or equal to SMALLER_FOLLOWER
        defaultUserProfileShouldNotBeFound("follower.lessThanOrEqual=" + SMALLER_FOLLOWER);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByFollowerIsLessThanSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where follower is less than DEFAULT_FOLLOWER
        defaultUserProfileShouldNotBeFound("follower.lessThan=" + DEFAULT_FOLLOWER);

        // Get all the userProfileList where follower is less than UPDATED_FOLLOWER
        defaultUserProfileShouldBeFound("follower.lessThan=" + UPDATED_FOLLOWER);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByFollowerIsGreaterThanSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where follower is greater than DEFAULT_FOLLOWER
        defaultUserProfileShouldNotBeFound("follower.greaterThan=" + DEFAULT_FOLLOWER);

        // Get all the userProfileList where follower is greater than SMALLER_FOLLOWER
        defaultUserProfileShouldBeFound("follower.greaterThan=" + SMALLER_FOLLOWER);
    }


    @Test
    @Transactional
    public void getAllUserProfilesByFollowedIsEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where followed equals to DEFAULT_FOLLOWED
        defaultUserProfileShouldBeFound("followed.equals=" + DEFAULT_FOLLOWED);

        // Get all the userProfileList where followed equals to UPDATED_FOLLOWED
        defaultUserProfileShouldNotBeFound("followed.equals=" + UPDATED_FOLLOWED);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByFollowedIsNotEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where followed not equals to DEFAULT_FOLLOWED
        defaultUserProfileShouldNotBeFound("followed.notEquals=" + DEFAULT_FOLLOWED);

        // Get all the userProfileList where followed not equals to UPDATED_FOLLOWED
        defaultUserProfileShouldBeFound("followed.notEquals=" + UPDATED_FOLLOWED);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByFollowedIsInShouldWork() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where followed in DEFAULT_FOLLOWED or UPDATED_FOLLOWED
        defaultUserProfileShouldBeFound("followed.in=" + DEFAULT_FOLLOWED + "," + UPDATED_FOLLOWED);

        // Get all the userProfileList where followed equals to UPDATED_FOLLOWED
        defaultUserProfileShouldNotBeFound("followed.in=" + UPDATED_FOLLOWED);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByFollowedIsNullOrNotNull() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where followed is not null
        defaultUserProfileShouldBeFound("followed.specified=true");

        // Get all the userProfileList where followed is null
        defaultUserProfileShouldNotBeFound("followed.specified=false");
    }

    @Test
    @Transactional
    public void getAllUserProfilesByFollowedIsGreaterThanOrEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where followed is greater than or equal to DEFAULT_FOLLOWED
        defaultUserProfileShouldBeFound("followed.greaterThanOrEqual=" + DEFAULT_FOLLOWED);

        // Get all the userProfileList where followed is greater than or equal to UPDATED_FOLLOWED
        defaultUserProfileShouldNotBeFound("followed.greaterThanOrEqual=" + UPDATED_FOLLOWED);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByFollowedIsLessThanOrEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where followed is less than or equal to DEFAULT_FOLLOWED
        defaultUserProfileShouldBeFound("followed.lessThanOrEqual=" + DEFAULT_FOLLOWED);

        // Get all the userProfileList where followed is less than or equal to SMALLER_FOLLOWED
        defaultUserProfileShouldNotBeFound("followed.lessThanOrEqual=" + SMALLER_FOLLOWED);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByFollowedIsLessThanSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where followed is less than DEFAULT_FOLLOWED
        defaultUserProfileShouldNotBeFound("followed.lessThan=" + DEFAULT_FOLLOWED);

        // Get all the userProfileList where followed is less than UPDATED_FOLLOWED
        defaultUserProfileShouldBeFound("followed.lessThan=" + UPDATED_FOLLOWED);
    }

    @Test
    @Transactional
    public void getAllUserProfilesByFollowedIsGreaterThanSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);

        // Get all the userProfileList where followed is greater than DEFAULT_FOLLOWED
        defaultUserProfileShouldNotBeFound("followed.greaterThan=" + DEFAULT_FOLLOWED);

        // Get all the userProfileList where followed is greater than SMALLER_FOLLOWED
        defaultUserProfileShouldBeFound("followed.greaterThan=" + SMALLER_FOLLOWED);
    }


    @Test
    @Transactional
    public void getAllUserProfilesByCountryIsEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);
        Country country = CountryResourceIT.createEntity(em);
        em.persist(country);
        em.flush();
        userProfile.setCountry(country);
        userProfileRepository.saveAndFlush(userProfile);
        Long countryId = country.getId();

        // Get all the userProfileList where country equals to countryId
        defaultUserProfileShouldBeFound("countryId.equals=" + countryId);

        // Get all the userProfileList where country equals to countryId + 1
        defaultUserProfileShouldNotBeFound("countryId.equals=" + (countryId + 1));
    }


    @Test
    @Transactional
    public void getAllUserProfilesByPhotoIsEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);
        Photo photo = PhotoResourceIT.createEntity(em);
        em.persist(photo);
        em.flush();
        userProfile.setPhoto(photo);
        userProfileRepository.saveAndFlush(userProfile);
        Long photoId = photo.getId();

        // Get all the userProfileList where photo equals to photoId
        defaultUserProfileShouldBeFound("photoId.equals=" + photoId);

        // Get all the userProfileList where photo equals to photoId + 1
        defaultUserProfileShouldNotBeFound("photoId.equals=" + (photoId + 1));
    }


    @Test
    @Transactional
    public void getAllUserProfilesByTravelRouteIsEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);
        TravelRoute travelRoute = TravelRouteResourceIT.createEntity(em);
        em.persist(travelRoute);
        em.flush();
        userProfile.addTravelRoute(travelRoute);
        userProfileRepository.saveAndFlush(userProfile);
        Long travelRouteId = travelRoute.getId();

        // Get all the userProfileList where travelRoute equals to travelRouteId
        defaultUserProfileShouldBeFound("travelRouteId.equals=" + travelRouteId);

        // Get all the userProfileList where travelRoute equals to travelRouteId + 1
        defaultUserProfileShouldNotBeFound("travelRouteId.equals=" + (travelRouteId + 1));
    }


    @Test
    @Transactional
    public void getAllUserProfilesByValuationIsEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);
        Valuation valuation = ValuationResourceIT.createEntity(em);
        em.persist(valuation);
        em.flush();
        userProfile.addValuation(valuation);
        userProfileRepository.saveAndFlush(userProfile);
        Long valuationId = valuation.getId();

        // Get all the userProfileList where valuation equals to valuationId
        defaultUserProfileShouldBeFound("valuationId.equals=" + valuationId);

        // Get all the userProfileList where valuation equals to valuationId + 1
        defaultUserProfileShouldNotBeFound("valuationId.equals=" + (valuationId + 1));
    }


    @Test
    @Transactional
    public void getAllUserProfilesByFollowingIsEqualToSomething() throws Exception {
        // Initialize the database
        userProfileRepository.saveAndFlush(userProfile);
        Following following = FollowingResourceIT.createEntity(em);
        em.persist(following);
        em.flush();
        userProfile.addFollowing(following);
        userProfileRepository.saveAndFlush(userProfile);
        Long followingId = following.getId();

        // Get all the userProfileList where following equals to followingId
        defaultUserProfileShouldBeFound("followingId.equals=" + followingId);

        // Get all the userProfileList where following equals to followingId + 1
        defaultUserProfileShouldNotBeFound("followingId.equals=" + (followingId + 1));
    }

    /**
     * Executes the search, and checks that the default entity is returned.
     */
    private void defaultUserProfileShouldBeFound(String filter) throws Exception {
        restUserProfileMockMvc.perform(get("/api/user-profiles?sort=id,desc&" + filter))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(userProfile.getId().intValue())))
            .andExpect(jsonPath("$.[*].firstName").value(hasItem(DEFAULT_FIRST_NAME)))
            .andExpect(jsonPath("$.[*].lastName").value(hasItem(DEFAULT_LAST_NAME)))
            .andExpect(jsonPath("$.[*].email").value(hasItem(DEFAULT_EMAIL)))
            .andExpect(jsonPath("$.[*].telephone").value(hasItem(DEFAULT_TELEPHONE)))
            .andExpect(jsonPath("$.[*].userName").value(hasItem(DEFAULT_USER_NAME)))
            .andExpect(jsonPath("$.[*].password").value(hasItem(DEFAULT_PASSWORD)))
            .andExpect(jsonPath("$.[*].age").value(hasItem(DEFAULT_AGE)))
            .andExpect(jsonPath("$.[*].biography").value(hasItem(DEFAULT_BIOGRAPHY)))
            .andExpect(jsonPath("$.[*].createdAt").value(hasItem(DEFAULT_CREATED_AT.toString())))
            .andExpect(jsonPath("$.[*].updatedAt").value(hasItem(DEFAULT_UPDATED_AT.toString())))
            .andExpect(jsonPath("$.[*].follower").value(hasItem(DEFAULT_FOLLOWER)))
            .andExpect(jsonPath("$.[*].followed").value(hasItem(DEFAULT_FOLLOWED)));

        // Check, that the count call also returns 1
        restUserProfileMockMvc.perform(get("/api/user-profiles/count?sort=id,desc&" + filter))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(content().string("1"));
    }

    /**
     * Executes the search, and checks that the default entity is not returned.
     */
    private void defaultUserProfileShouldNotBeFound(String filter) throws Exception {
        restUserProfileMockMvc.perform(get("/api/user-profiles?sort=id,desc&" + filter))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$").isArray())
            .andExpect(jsonPath("$").isEmpty());

        // Check, that the count call also returns 0
        restUserProfileMockMvc.perform(get("/api/user-profiles/count?sort=id,desc&" + filter))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(content().string("0"));
    }


    @Test
    @Transactional
    public void getNonExistingUserProfile() throws Exception {
        // Get the userProfile
        restUserProfileMockMvc.perform(get("/api/user-profiles/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateUserProfile() throws Exception {
        // Initialize the database
        userProfileService.save(userProfile);
        // As the test used the service layer, reset the Elasticsearch mock repository
        reset(mockUserProfileSearchRepository);

        int databaseSizeBeforeUpdate = userProfileRepository.findAll().size();

        // Update the userProfile
        UserProfile updatedUserProfile = userProfileRepository.findById(userProfile.getId()).get();
        // Disconnect from session so that the updates on updatedUserProfile are not directly saved in db
        em.detach(updatedUserProfile);
        updatedUserProfile
            .firstName(UPDATED_FIRST_NAME)
            .lastName(UPDATED_LAST_NAME)
            .email(UPDATED_EMAIL)
            .telephone(UPDATED_TELEPHONE)
            .userName(UPDATED_USER_NAME)
            .password(UPDATED_PASSWORD)
            .age(UPDATED_AGE)
            .biography(UPDATED_BIOGRAPHY)
            .createdAt(UPDATED_CREATED_AT)
            .updatedAt(UPDATED_UPDATED_AT)
            .follower(UPDATED_FOLLOWER)
            .followed(UPDATED_FOLLOWED);

        restUserProfileMockMvc.perform(put("/api/user-profiles")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(updatedUserProfile)))
            .andExpect(status().isOk());

        // Validate the UserProfile in the database
        List<UserProfile> userProfileList = userProfileRepository.findAll();
        assertThat(userProfileList).hasSize(databaseSizeBeforeUpdate);
        UserProfile testUserProfile = userProfileList.get(userProfileList.size() - 1);
        assertThat(testUserProfile.getFirstName()).isEqualTo(UPDATED_FIRST_NAME);
        assertThat(testUserProfile.getLastName()).isEqualTo(UPDATED_LAST_NAME);
        assertThat(testUserProfile.getEmail()).isEqualTo(UPDATED_EMAIL);
        assertThat(testUserProfile.getTelephone()).isEqualTo(UPDATED_TELEPHONE);
        assertThat(testUserProfile.getUserName()).isEqualTo(UPDATED_USER_NAME);
        assertThat(testUserProfile.getPassword()).isEqualTo(UPDATED_PASSWORD);
        assertThat(testUserProfile.getAge()).isEqualTo(UPDATED_AGE);
        assertThat(testUserProfile.getBiography()).isEqualTo(UPDATED_BIOGRAPHY);
        assertThat(testUserProfile.getCreatedAt()).isEqualTo(UPDATED_CREATED_AT);
        assertThat(testUserProfile.getUpdatedAt()).isEqualTo(UPDATED_UPDATED_AT);
        assertThat(testUserProfile.getFollower()).isEqualTo(UPDATED_FOLLOWER);
        assertThat(testUserProfile.getFollowed()).isEqualTo(UPDATED_FOLLOWED);

        // Validate the UserProfile in Elasticsearch
        verify(mockUserProfileSearchRepository, times(1)).save(testUserProfile);
    }

    @Test
    @Transactional
    public void updateNonExistingUserProfile() throws Exception {
        int databaseSizeBeforeUpdate = userProfileRepository.findAll().size();

        // Create the UserProfile

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restUserProfileMockMvc.perform(put("/api/user-profiles")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(userProfile)))
            .andExpect(status().isBadRequest());

        // Validate the UserProfile in the database
        List<UserProfile> userProfileList = userProfileRepository.findAll();
        assertThat(userProfileList).hasSize(databaseSizeBeforeUpdate);

        // Validate the UserProfile in Elasticsearch
        verify(mockUserProfileSearchRepository, times(0)).save(userProfile);
    }

    @Test
    @Transactional
    public void deleteUserProfile() throws Exception {
        // Initialize the database
        userProfileService.save(userProfile);

        int databaseSizeBeforeDelete = userProfileRepository.findAll().size();

        // Delete the userProfile
        restUserProfileMockMvc.perform(delete("/api/user-profiles/{id}", userProfile.getId())
            .accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<UserProfile> userProfileList = userProfileRepository.findAll();
        assertThat(userProfileList).hasSize(databaseSizeBeforeDelete - 1);

        // Validate the UserProfile in Elasticsearch
        verify(mockUserProfileSearchRepository, times(1)).deleteById(userProfile.getId());
    }

    @Test
    @Transactional
    public void searchUserProfile() throws Exception {
        // Initialize the database
        userProfileService.save(userProfile);
        when(mockUserProfileSearchRepository.search(queryStringQuery("id:" + userProfile.getId()), PageRequest.of(0, 20)))
            .thenReturn(new PageImpl<>(Collections.singletonList(userProfile), PageRequest.of(0, 1), 1));
        // Search the userProfile
        restUserProfileMockMvc.perform(get("/api/_search/user-profiles?query=id:" + userProfile.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(userProfile.getId().intValue())))
            .andExpect(jsonPath("$.[*].firstName").value(hasItem(DEFAULT_FIRST_NAME)))
            .andExpect(jsonPath("$.[*].lastName").value(hasItem(DEFAULT_LAST_NAME)))
            .andExpect(jsonPath("$.[*].email").value(hasItem(DEFAULT_EMAIL)))
            .andExpect(jsonPath("$.[*].telephone").value(hasItem(DEFAULT_TELEPHONE)))
            .andExpect(jsonPath("$.[*].userName").value(hasItem(DEFAULT_USER_NAME)))
            .andExpect(jsonPath("$.[*].password").value(hasItem(DEFAULT_PASSWORD)))
            .andExpect(jsonPath("$.[*].age").value(hasItem(DEFAULT_AGE)))
            .andExpect(jsonPath("$.[*].biography").value(hasItem(DEFAULT_BIOGRAPHY)))
            .andExpect(jsonPath("$.[*].createdAt").value(hasItem(DEFAULT_CREATED_AT.toString())))
            .andExpect(jsonPath("$.[*].updatedAt").value(hasItem(DEFAULT_UPDATED_AT.toString())))
            .andExpect(jsonPath("$.[*].follower").value(hasItem(DEFAULT_FOLLOWER)))
            .andExpect(jsonPath("$.[*].followed").value(hasItem(DEFAULT_FOLLOWED)));
    }
}
