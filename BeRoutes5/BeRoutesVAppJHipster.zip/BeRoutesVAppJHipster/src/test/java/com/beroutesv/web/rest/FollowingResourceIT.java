package com.beroutesv.web.rest;

import com.beroutesv.BeRoutesVApp;
import com.beroutesv.domain.Following;
import com.beroutesv.repository.FollowingRepository;
import com.beroutesv.repository.search.FollowingSearchRepository;
import com.beroutesv.service.FollowingService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;
import javax.persistence.EntityManager;
import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.elasticsearch.index.query.QueryBuilders.queryStringQuery;
import static org.hamcrest.Matchers.hasItem;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Integration tests for the {@link FollowingResource} REST controller.
 */
@SpringBootTest(classes = BeRoutesVApp.class)
@ExtendWith(MockitoExtension.class)
@AutoConfigureMockMvc
@WithMockUser
public class FollowingResourceIT {

    private static final Boolean DEFAULT_FOLLOW = false;
    private static final Boolean UPDATED_FOLLOW = true;

    private static final Boolean DEFAULT_ACCEPTED = false;
    private static final Boolean UPDATED_ACCEPTED = true;

    private static final Integer DEFAULT_USER_FOLLOWER = 1;
    private static final Integer UPDATED_USER_FOLLOWER = 2;

    private static final Integer DEFAULT_USER_FOLLOWED = 1;
    private static final Integer UPDATED_USER_FOLLOWED = 2;

    @Autowired
    private FollowingRepository followingRepository;

    @Autowired
    private FollowingService followingService;

    /**
     * This repository is mocked in the com.beroutesv.repository.search test package.
     *
     * @see com.beroutesv.repository.search.FollowingSearchRepositoryMockConfiguration
     */
    @Autowired
    private FollowingSearchRepository mockFollowingSearchRepository;

    @Autowired
    private EntityManager em;

    @Autowired
    private MockMvc restFollowingMockMvc;

    private Following following;

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Following createEntity(EntityManager em) {
        Following following = new Following()
            .follow(DEFAULT_FOLLOW)
            .accepted(DEFAULT_ACCEPTED)
            .userFollower(DEFAULT_USER_FOLLOWER)
            .userFollowed(DEFAULT_USER_FOLLOWED);
        return following;
    }
    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Following createUpdatedEntity(EntityManager em) {
        Following following = new Following()
            .follow(UPDATED_FOLLOW)
            .accepted(UPDATED_ACCEPTED)
            .userFollower(UPDATED_USER_FOLLOWER)
            .userFollowed(UPDATED_USER_FOLLOWED);
        return following;
    }

    @BeforeEach
    public void initTest() {
        following = createEntity(em);
    }

    @Test
    @Transactional
    public void createFollowing() throws Exception {
        int databaseSizeBeforeCreate = followingRepository.findAll().size();

        // Create the Following
        restFollowingMockMvc.perform(post("/api/followings")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(following)))
            .andExpect(status().isCreated());

        // Validate the Following in the database
        List<Following> followingList = followingRepository.findAll();
        assertThat(followingList).hasSize(databaseSizeBeforeCreate + 1);
        Following testFollowing = followingList.get(followingList.size() - 1);
        assertThat(testFollowing.isFollow()).isEqualTo(DEFAULT_FOLLOW);
        assertThat(testFollowing.isAccepted()).isEqualTo(DEFAULT_ACCEPTED);
        assertThat(testFollowing.getUserFollower()).isEqualTo(DEFAULT_USER_FOLLOWER);
        assertThat(testFollowing.getUserFollowed()).isEqualTo(DEFAULT_USER_FOLLOWED);

        // Validate the Following in Elasticsearch
        verify(mockFollowingSearchRepository, times(1)).save(testFollowing);
    }

    @Test
    @Transactional
    public void createFollowingWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = followingRepository.findAll().size();

        // Create the Following with an existing ID
        following.setId(1L);

        // An entity with an existing ID cannot be created, so this API call must fail
        restFollowingMockMvc.perform(post("/api/followings")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(following)))
            .andExpect(status().isBadRequest());

        // Validate the Following in the database
        List<Following> followingList = followingRepository.findAll();
        assertThat(followingList).hasSize(databaseSizeBeforeCreate);

        // Validate the Following in Elasticsearch
        verify(mockFollowingSearchRepository, times(0)).save(following);
    }


    @Test
    @Transactional
    public void getAllFollowings() throws Exception {
        // Initialize the database
        followingRepository.saveAndFlush(following);

        // Get all the followingList
        restFollowingMockMvc.perform(get("/api/followings?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(following.getId().intValue())))
            .andExpect(jsonPath("$.[*].follow").value(hasItem(DEFAULT_FOLLOW.booleanValue())))
            .andExpect(jsonPath("$.[*].accepted").value(hasItem(DEFAULT_ACCEPTED.booleanValue())))
            .andExpect(jsonPath("$.[*].userFollower").value(hasItem(DEFAULT_USER_FOLLOWER)))
            .andExpect(jsonPath("$.[*].userFollowed").value(hasItem(DEFAULT_USER_FOLLOWED)));
    }
    
    @Test
    @Transactional
    public void getFollowing() throws Exception {
        // Initialize the database
        followingRepository.saveAndFlush(following);

        // Get the following
        restFollowingMockMvc.perform(get("/api/followings/{id}", following.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.id").value(following.getId().intValue()))
            .andExpect(jsonPath("$.follow").value(DEFAULT_FOLLOW.booleanValue()))
            .andExpect(jsonPath("$.accepted").value(DEFAULT_ACCEPTED.booleanValue()))
            .andExpect(jsonPath("$.userFollower").value(DEFAULT_USER_FOLLOWER))
            .andExpect(jsonPath("$.userFollowed").value(DEFAULT_USER_FOLLOWED));
    }

    @Test
    @Transactional
    public void getNonExistingFollowing() throws Exception {
        // Get the following
        restFollowingMockMvc.perform(get("/api/followings/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateFollowing() throws Exception {
        // Initialize the database
        followingService.save(following);
        // As the test used the service layer, reset the Elasticsearch mock repository
        reset(mockFollowingSearchRepository);

        int databaseSizeBeforeUpdate = followingRepository.findAll().size();

        // Update the following
        Following updatedFollowing = followingRepository.findById(following.getId()).get();
        // Disconnect from session so that the updates on updatedFollowing are not directly saved in db
        em.detach(updatedFollowing);
        updatedFollowing
            .follow(UPDATED_FOLLOW)
            .accepted(UPDATED_ACCEPTED)
            .userFollower(UPDATED_USER_FOLLOWER)
            .userFollowed(UPDATED_USER_FOLLOWED);

        restFollowingMockMvc.perform(put("/api/followings")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(updatedFollowing)))
            .andExpect(status().isOk());

        // Validate the Following in the database
        List<Following> followingList = followingRepository.findAll();
        assertThat(followingList).hasSize(databaseSizeBeforeUpdate);
        Following testFollowing = followingList.get(followingList.size() - 1);
        assertThat(testFollowing.isFollow()).isEqualTo(UPDATED_FOLLOW);
        assertThat(testFollowing.isAccepted()).isEqualTo(UPDATED_ACCEPTED);
        assertThat(testFollowing.getUserFollower()).isEqualTo(UPDATED_USER_FOLLOWER);
        assertThat(testFollowing.getUserFollowed()).isEqualTo(UPDATED_USER_FOLLOWED);

        // Validate the Following in Elasticsearch
        verify(mockFollowingSearchRepository, times(1)).save(testFollowing);
    }

    @Test
    @Transactional
    public void updateNonExistingFollowing() throws Exception {
        int databaseSizeBeforeUpdate = followingRepository.findAll().size();

        // Create the Following

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restFollowingMockMvc.perform(put("/api/followings")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(following)))
            .andExpect(status().isBadRequest());

        // Validate the Following in the database
        List<Following> followingList = followingRepository.findAll();
        assertThat(followingList).hasSize(databaseSizeBeforeUpdate);

        // Validate the Following in Elasticsearch
        verify(mockFollowingSearchRepository, times(0)).save(following);
    }

    @Test
    @Transactional
    public void deleteFollowing() throws Exception {
        // Initialize the database
        followingService.save(following);

        int databaseSizeBeforeDelete = followingRepository.findAll().size();

        // Delete the following
        restFollowingMockMvc.perform(delete("/api/followings/{id}", following.getId())
            .accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<Following> followingList = followingRepository.findAll();
        assertThat(followingList).hasSize(databaseSizeBeforeDelete - 1);

        // Validate the Following in Elasticsearch
        verify(mockFollowingSearchRepository, times(1)).deleteById(following.getId());
    }

    @Test
    @Transactional
    public void searchFollowing() throws Exception {
        // Initialize the database
        followingService.save(following);
        when(mockFollowingSearchRepository.search(queryStringQuery("id:" + following.getId()), PageRequest.of(0, 20)))
            .thenReturn(new PageImpl<>(Collections.singletonList(following), PageRequest.of(0, 1), 1));
        // Search the following
        restFollowingMockMvc.perform(get("/api/_search/followings?query=id:" + following.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(following.getId().intValue())))
            .andExpect(jsonPath("$.[*].follow").value(hasItem(DEFAULT_FOLLOW.booleanValue())))
            .andExpect(jsonPath("$.[*].accepted").value(hasItem(DEFAULT_ACCEPTED.booleanValue())))
            .andExpect(jsonPath("$.[*].userFollower").value(hasItem(DEFAULT_USER_FOLLOWER)))
            .andExpect(jsonPath("$.[*].userFollowed").value(hasItem(DEFAULT_USER_FOLLOWED)));
    }
}
