package com.beroutesv.domain;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;
import com.beroutesv.web.rest.TestUtil;

public class QrTest {

    @Test
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(Qr.class);
        Qr qr1 = new Qr();
        qr1.setId(1L);
        Qr qr2 = new Qr();
        qr2.setId(qr1.getId());
        assertThat(qr1).isEqualTo(qr2);
        qr2.setId(2L);
        assertThat(qr1).isNotEqualTo(qr2);
        qr1.setId(null);
        assertThat(qr1).isNotEqualTo(qr2);
    }
}
