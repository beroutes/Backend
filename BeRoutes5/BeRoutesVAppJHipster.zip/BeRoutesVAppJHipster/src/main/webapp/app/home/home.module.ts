import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { BeRoutesVSharedModule } from 'app/shared/shared.module';
import { HOME_ROUTE } from './home.route';
import { HomeComponent } from './home.component';

@NgModule({
  imports: [BeRoutesVSharedModule, RouterModule.forChild([HOME_ROUTE])],
  declarations: [HomeComponent]
})
export class BeRoutesVHomeModule {}
