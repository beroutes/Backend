import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

@NgModule({
  imports: [
    RouterModule.forChild([
      {
        path: 'country',
        loadChildren: () => import('./country/country.module').then(m => m.BeRoutesVCountryModule)
      },
      {
        path: 'location',
        loadChildren: () => import('./location/location.module').then(m => m.BeRoutesVLocationModule)
      },
      {
        path: 'travel-route',
        loadChildren: () => import('./travel-route/travel-route.module').then(m => m.BeRoutesVTravelRouteModule)
      },
      {
        path: 'user-profile',
        loadChildren: () => import('./user-profile/user-profile.module').then(m => m.BeRoutesVUserProfileModule)
      },
      {
        path: 'following',
        loadChildren: () => import('./following/following.module').then(m => m.BeRoutesVFollowingModule)
      },
      {
        path: 'photo',
        loadChildren: () => import('./photo/photo.module').then(m => m.BeRoutesVPhotoModule)
      },
      {
        path: 'valuation',
        loadChildren: () => import('./valuation/valuation.module').then(m => m.BeRoutesVValuationModule)
      },
      {
        path: 'qr',
        loadChildren: () => import('./qr/qr.module').then(m => m.BeRoutesVQrModule)
      }
      /* jhipster-needle-add-entity-route - JHipster will add entity modules routes here */
    ])
  ]
})
export class BeRoutesVEntityModule {}
