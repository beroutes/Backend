import { Component, OnInit } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { ITravelRoute, TravelRoute } from 'app/shared/model/travel-route.model';
import { TravelRouteService } from './travel-route.service';
import { ICountry } from 'app/shared/model/country.model';
import { CountryService } from 'app/entities/country/country.service';
import { IUserProfile } from 'app/shared/model/user-profile.model';
import { UserProfileService } from 'app/entities/user-profile/user-profile.service';

type SelectableEntity = ICountry | IUserProfile;

@Component({
  selector: 'jhi-travel-route-update',
  templateUrl: './travel-route-update.component.html'
})
export class TravelRouteUpdateComponent implements OnInit {
  isSaving = false;
  countries: ICountry[] = [];
  userprofiles: IUserProfile[] = [];
  createdAtDp: any;
  updatedAtDp: any;

  editForm = this.fb.group({
    id: [],
    titleRoute: [],
    destination: [],
    continent: [],
    days: [],
    weeks: [],
    season: [],
    budget: [],
    category: [],
    valueAverage: [],
    descriptionRouteSummary: [],
    descriptionRoute: [],
    steps: [],
    summaryMap: [],
    createdAt: [],
    updatedAt: [],
    qrActivation: [],
    country: [],
    userProfile: []
  });

  constructor(
    protected travelRouteService: TravelRouteService,
    protected countryService: CountryService,
    protected userProfileService: UserProfileService,
    protected activatedRoute: ActivatedRoute,
    private fb: FormBuilder
  ) {}

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ travelRoute }) => {
      this.updateForm(travelRoute);

      this.countryService
        .query({ filter: 'travelroute-is-null' })
        .pipe(
          map((res: HttpResponse<ICountry[]>) => {
            return res.body || [];
          })
        )
        .subscribe((resBody: ICountry[]) => {
          if (!travelRoute.country || !travelRoute.country.id) {
            this.countries = resBody;
          } else {
            this.countryService
              .find(travelRoute.country.id)
              .pipe(
                map((subRes: HttpResponse<ICountry>) => {
                  return subRes.body ? [subRes.body].concat(resBody) : resBody;
                })
              )
              .subscribe((concatRes: ICountry[]) => (this.countries = concatRes));
          }
        });

      this.userProfileService.query().subscribe((res: HttpResponse<IUserProfile[]>) => (this.userprofiles = res.body || []));
    });
  }

  updateForm(travelRoute: ITravelRoute): void {
    this.editForm.patchValue({
      id: travelRoute.id,
      titleRoute: travelRoute.titleRoute,
      destination: travelRoute.destination,
      continent: travelRoute.continent,
      days: travelRoute.days,
      weeks: travelRoute.weeks,
      season: travelRoute.season,
      budget: travelRoute.budget,
      category: travelRoute.category,
      valueAverage: travelRoute.valueAverage,
      descriptionRouteSummary: travelRoute.descriptionRouteSummary,
      descriptionRoute: travelRoute.descriptionRoute,
      steps: travelRoute.steps,
      summaryMap: travelRoute.summaryMap,
      createdAt: travelRoute.createdAt,
      updatedAt: travelRoute.updatedAt,
      qrActivation: travelRoute.qrActivation,
      country: travelRoute.country,
      userProfile: travelRoute.userProfile
    });
  }

  previousState(): void {
    window.history.back();
  }

  save(): void {
    this.isSaving = true;
    const travelRoute = this.createFromForm();
    if (travelRoute.id !== undefined) {
      this.subscribeToSaveResponse(this.travelRouteService.update(travelRoute));
    } else {
      this.subscribeToSaveResponse(this.travelRouteService.create(travelRoute));
    }
  }

  private createFromForm(): ITravelRoute {
    return {
      ...new TravelRoute(),
      id: this.editForm.get(['id'])!.value,
      titleRoute: this.editForm.get(['titleRoute'])!.value,
      destination: this.editForm.get(['destination'])!.value,
      continent: this.editForm.get(['continent'])!.value,
      days: this.editForm.get(['days'])!.value,
      weeks: this.editForm.get(['weeks'])!.value,
      season: this.editForm.get(['season'])!.value,
      budget: this.editForm.get(['budget'])!.value,
      category: this.editForm.get(['category'])!.value,
      valueAverage: this.editForm.get(['valueAverage'])!.value,
      descriptionRouteSummary: this.editForm.get(['descriptionRouteSummary'])!.value,
      descriptionRoute: this.editForm.get(['descriptionRoute'])!.value,
      steps: this.editForm.get(['steps'])!.value,
      summaryMap: this.editForm.get(['summaryMap'])!.value,
      createdAt: this.editForm.get(['createdAt'])!.value,
      updatedAt: this.editForm.get(['updatedAt'])!.value,
      qrActivation: this.editForm.get(['qrActivation'])!.value,
      country: this.editForm.get(['country'])!.value,
      userProfile: this.editForm.get(['userProfile'])!.value
    };
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<ITravelRoute>>): void {
    result.subscribe(
      () => this.onSaveSuccess(),
      () => this.onSaveError()
    );
  }

  protected onSaveSuccess(): void {
    this.isSaving = false;
    this.previousState();
  }

  protected onSaveError(): void {
    this.isSaving = false;
  }

  trackById(index: number, item: SelectableEntity): any {
    return item.id;
  }
}
