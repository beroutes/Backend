import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { BeRoutesVSharedModule } from 'app/shared/shared.module';
import { FollowingComponent } from './following.component';
import { FollowingDetailComponent } from './following-detail.component';
import { FollowingUpdateComponent } from './following-update.component';
import { FollowingDeleteDialogComponent } from './following-delete-dialog.component';
import { followingRoute } from './following.route';

@NgModule({
  imports: [BeRoutesVSharedModule, RouterModule.forChild(followingRoute)],
  declarations: [FollowingComponent, FollowingDetailComponent, FollowingUpdateComponent, FollowingDeleteDialogComponent],
  entryComponents: [FollowingDeleteDialogComponent]
})
export class BeRoutesVFollowingModule {}
