import { Moment } from 'moment';
import { ICountry } from 'app/shared/model/country.model';
import { ILocation } from 'app/shared/model/location.model';
import { IPhoto } from 'app/shared/model/photo.model';
import { IValuation } from 'app/shared/model/valuation.model';
import { IQr } from 'app/shared/model/qr.model';
import { IUserProfile } from 'app/shared/model/user-profile.model';
import { Continent } from 'app/shared/model/enumerations/continent.model';
import { Season } from 'app/shared/model/enumerations/season.model';
import { Category } from 'app/shared/model/enumerations/category.model';

export interface ITravelRoute {
  id?: number;
  titleRoute?: string;
  destination?: string;
  continent?: Continent;
  days?: number;
  weeks?: number;
  season?: Season;
  budget?: number;
  category?: Category;
  valueAverage?: number;
  descriptionRouteSummary?: string;
  descriptionRoute?: string;
  steps?: number;
  summaryMap?: string;
  createdAt?: Moment;
  updatedAt?: Moment;
  qrActivation?: boolean;
  country?: ICountry;
  locations?: ILocation[];
  galeries?: IPhoto[];
  valuations?: IValuation[];
  qrs?: IQr[];
  userProfile?: IUserProfile;
}

export class TravelRoute implements ITravelRoute {
  constructor(
    public id?: number,
    public titleRoute?: string,
    public destination?: string,
    public continent?: Continent,
    public days?: number,
    public weeks?: number,
    public season?: Season,
    public budget?: number,
    public category?: Category,
    public valueAverage?: number,
    public descriptionRouteSummary?: string,
    public descriptionRoute?: string,
    public steps?: number,
    public summaryMap?: string,
    public createdAt?: Moment,
    public updatedAt?: Moment,
    public qrActivation?: boolean,
    public country?: ICountry,
    public locations?: ILocation[],
    public galeries?: IPhoto[],
    public valuations?: IValuation[],
    public qrs?: IQr[],
    public userProfile?: IUserProfile
  ) {
    this.qrActivation = this.qrActivation || false;
  }
}
