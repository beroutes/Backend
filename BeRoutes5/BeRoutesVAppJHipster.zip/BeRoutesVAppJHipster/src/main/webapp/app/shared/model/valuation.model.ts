import { ITravelRoute } from 'app/shared/model/travel-route.model';
import { IUserProfile } from 'app/shared/model/user-profile.model';

export interface IValuation {
  id?: number;
  rating?: number;
  comment?: string;
  travelRoute?: ITravelRoute;
  userProfile?: IUserProfile;
}

export class Valuation implements IValuation {
  constructor(
    public id?: number,
    public rating?: number,
    public comment?: string,
    public travelRoute?: ITravelRoute,
    public userProfile?: IUserProfile
  ) {}
}
