import { ILocation } from 'app/shared/model/location.model';
import { ITravelRoute } from 'app/shared/model/travel-route.model';
import { IUserProfile } from 'app/shared/model/user-profile.model';

export interface ICountry {
  id?: number;
  countryName?: string;
  region?: string;
  city?: string;
  location?: ILocation;
  travelRoute?: ITravelRoute;
  userProfile?: IUserProfile;
}

export class Country implements ICountry {
  constructor(
    public id?: number,
    public countryName?: string,
    public region?: string,
    public city?: string,
    public location?: ILocation,
    public travelRoute?: ITravelRoute,
    public userProfile?: IUserProfile
  ) {}
}
