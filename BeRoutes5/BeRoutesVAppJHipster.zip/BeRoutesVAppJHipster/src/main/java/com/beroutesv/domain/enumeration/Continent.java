package com.beroutesv.domain.enumeration;

/**
 * The Continent enumeration.
 */
public enum Continent {
    ASIA, AFRICA, EUROPE, AUSTRALIA, AMERICANORTH, AMERICASOUTH, ANTARCTICA
}
