/**
 * View Models used by Spring MVC REST controllers.
 */
package com.beroutesv.web.rest.vm;
