package com.beroutesv.domain.enumeration;

/**
 * The Category enumeration.
 */
public enum Category {
    CHEAP, LUXURY, LONELY, FRIENDS, ROMANTIC, KIDS, SPORT, RELAXATION, ART, FOOD, NATURE, CITY
}
