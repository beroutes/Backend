/**
 * Spring Data JPA repositories.
 */
package com.beroutesv.repository;
