package com.beroutesv.service.dto;

import java.io.Serializable;
import java.util.Objects;
import io.github.jhipster.service.Criteria;
import io.github.jhipster.service.filter.BooleanFilter;
import io.github.jhipster.service.filter.DoubleFilter;
import io.github.jhipster.service.filter.Filter;
import io.github.jhipster.service.filter.FloatFilter;
import io.github.jhipster.service.filter.IntegerFilter;
import io.github.jhipster.service.filter.LongFilter;
import io.github.jhipster.service.filter.StringFilter;
import io.github.jhipster.service.filter.LocalDateFilter;

/**
 * Criteria class for the {@link com.beroutesv.domain.UserProfile} entity. This class is used
 * in {@link com.beroutesv.web.rest.UserProfileResource} to receive all the possible filtering options from
 * the Http GET request parameters.
 * For example the following could be a valid request:
 * {@code /user-profiles?id.greaterThan=5&attr1.contains=something&attr2.specified=false}
 * As Spring is unable to properly convert the types, unless specific {@link Filter} class are used, we need to use
 * fix type specific filters.
 */
public class UserProfileCriteria implements Serializable, Criteria {

    private static final long serialVersionUID = 1L;

    private LongFilter id;

    private StringFilter firstName;

    private StringFilter lastName;

    private StringFilter email;

    private IntegerFilter telephone;

    private StringFilter userName;

    private StringFilter password;

    private IntegerFilter age;

    private StringFilter biography;

    private LocalDateFilter createdAt;

    private LocalDateFilter updatedAt;

    private IntegerFilter follower;

    private IntegerFilter followed;

    private LongFilter countryId;

    private LongFilter photoId;

    private LongFilter travelRouteId;

    private LongFilter valuationId;

    private LongFilter followingId;

    public UserProfileCriteria() {
    }

    public UserProfileCriteria(UserProfileCriteria other) {
        this.id = other.id == null ? null : other.id.copy();
        this.firstName = other.firstName == null ? null : other.firstName.copy();
        this.lastName = other.lastName == null ? null : other.lastName.copy();
        this.email = other.email == null ? null : other.email.copy();
        this.telephone = other.telephone == null ? null : other.telephone.copy();
        this.userName = other.userName == null ? null : other.userName.copy();
        this.password = other.password == null ? null : other.password.copy();
        this.age = other.age == null ? null : other.age.copy();
        this.biography = other.biography == null ? null : other.biography.copy();
        this.createdAt = other.createdAt == null ? null : other.createdAt.copy();
        this.updatedAt = other.updatedAt == null ? null : other.updatedAt.copy();
        this.follower = other.follower == null ? null : other.follower.copy();
        this.followed = other.followed == null ? null : other.followed.copy();
        this.countryId = other.countryId == null ? null : other.countryId.copy();
        this.photoId = other.photoId == null ? null : other.photoId.copy();
        this.travelRouteId = other.travelRouteId == null ? null : other.travelRouteId.copy();
        this.valuationId = other.valuationId == null ? null : other.valuationId.copy();
        this.followingId = other.followingId == null ? null : other.followingId.copy();
    }

    @Override
    public UserProfileCriteria copy() {
        return new UserProfileCriteria(this);
    }

    public LongFilter getId() {
        return id;
    }

    public void setId(LongFilter id) {
        this.id = id;
    }

    public StringFilter getFirstName() {
        return firstName;
    }

    public void setFirstName(StringFilter firstName) {
        this.firstName = firstName;
    }

    public StringFilter getLastName() {
        return lastName;
    }

    public void setLastName(StringFilter lastName) {
        this.lastName = lastName;
    }

    public StringFilter getEmail() {
        return email;
    }

    public void setEmail(StringFilter email) {
        this.email = email;
    }

    public IntegerFilter getTelephone() {
        return telephone;
    }

    public void setTelephone(IntegerFilter telephone) {
        this.telephone = telephone;
    }

    public StringFilter getUserName() {
        return userName;
    }

    public void setUserName(StringFilter userName) {
        this.userName = userName;
    }

    public StringFilter getPassword() {
        return password;
    }

    public void setPassword(StringFilter password) {
        this.password = password;
    }

    public IntegerFilter getAge() {
        return age;
    }

    public void setAge(IntegerFilter age) {
        this.age = age;
    }

    public StringFilter getBiography() {
        return biography;
    }

    public void setBiography(StringFilter biography) {
        this.biography = biography;
    }

    public LocalDateFilter getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateFilter createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateFilter getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateFilter updatedAt) {
        this.updatedAt = updatedAt;
    }

    public IntegerFilter getFollower() {
        return follower;
    }

    public void setFollower(IntegerFilter follower) {
        this.follower = follower;
    }

    public IntegerFilter getFollowed() {
        return followed;
    }

    public void setFollowed(IntegerFilter followed) {
        this.followed = followed;
    }

    public LongFilter getCountryId() {
        return countryId;
    }

    public void setCountryId(LongFilter countryId) {
        this.countryId = countryId;
    }

    public LongFilter getPhotoId() {
        return photoId;
    }

    public void setPhotoId(LongFilter photoId) {
        this.photoId = photoId;
    }

    public LongFilter getTravelRouteId() {
        return travelRouteId;
    }

    public void setTravelRouteId(LongFilter travelRouteId) {
        this.travelRouteId = travelRouteId;
    }

    public LongFilter getValuationId() {
        return valuationId;
    }

    public void setValuationId(LongFilter valuationId) {
        this.valuationId = valuationId;
    }

    public LongFilter getFollowingId() {
        return followingId;
    }

    public void setFollowingId(LongFilter followingId) {
        this.followingId = followingId;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        final UserProfileCriteria that = (UserProfileCriteria) o;
        return
            Objects.equals(id, that.id) &&
            Objects.equals(firstName, that.firstName) &&
            Objects.equals(lastName, that.lastName) &&
            Objects.equals(email, that.email) &&
            Objects.equals(telephone, that.telephone) &&
            Objects.equals(userName, that.userName) &&
            Objects.equals(password, that.password) &&
            Objects.equals(age, that.age) &&
            Objects.equals(biography, that.biography) &&
            Objects.equals(createdAt, that.createdAt) &&
            Objects.equals(updatedAt, that.updatedAt) &&
            Objects.equals(follower, that.follower) &&
            Objects.equals(followed, that.followed) &&
            Objects.equals(countryId, that.countryId) &&
            Objects.equals(photoId, that.photoId) &&
            Objects.equals(travelRouteId, that.travelRouteId) &&
            Objects.equals(valuationId, that.valuationId) &&
            Objects.equals(followingId, that.followingId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(
        id,
        firstName,
        lastName,
        email,
        telephone,
        userName,
        password,
        age,
        biography,
        createdAt,
        updatedAt,
        follower,
        followed,
        countryId,
        photoId,
        travelRouteId,
        valuationId,
        followingId
        );
    }

    @Override
    public String toString() {
        return "UserProfileCriteria{" +
                (id != null ? "id=" + id + ", " : "") +
                (firstName != null ? "firstName=" + firstName + ", " : "") +
                (lastName != null ? "lastName=" + lastName + ", " : "") +
                (email != null ? "email=" + email + ", " : "") +
                (telephone != null ? "telephone=" + telephone + ", " : "") +
                (userName != null ? "userName=" + userName + ", " : "") +
                (password != null ? "password=" + password + ", " : "") +
                (age != null ? "age=" + age + ", " : "") +
                (biography != null ? "biography=" + biography + ", " : "") +
                (createdAt != null ? "createdAt=" + createdAt + ", " : "") +
                (updatedAt != null ? "updatedAt=" + updatedAt + ", " : "") +
                (follower != null ? "follower=" + follower + ", " : "") +
                (followed != null ? "followed=" + followed + ", " : "") +
                (countryId != null ? "countryId=" + countryId + ", " : "") +
                (photoId != null ? "photoId=" + photoId + ", " : "") +
                (travelRouteId != null ? "travelRouteId=" + travelRouteId + ", " : "") +
                (valuationId != null ? "valuationId=" + valuationId + ", " : "") +
                (followingId != null ? "followingId=" + followingId + ", " : "") +
            "}";
    }

}
