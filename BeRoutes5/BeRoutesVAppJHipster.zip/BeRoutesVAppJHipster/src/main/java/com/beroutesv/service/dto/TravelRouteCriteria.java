package com.beroutesv.service.dto;

import java.io.Serializable;
import java.util.Objects;
import io.github.jhipster.service.Criteria;
import com.beroutesv.domain.enumeration.Continent;
import com.beroutesv.domain.enumeration.Season;
import com.beroutesv.domain.enumeration.Category;
import io.github.jhipster.service.filter.BooleanFilter;
import io.github.jhipster.service.filter.DoubleFilter;
import io.github.jhipster.service.filter.Filter;
import io.github.jhipster.service.filter.FloatFilter;
import io.github.jhipster.service.filter.IntegerFilter;
import io.github.jhipster.service.filter.LongFilter;
import io.github.jhipster.service.filter.StringFilter;
import io.github.jhipster.service.filter.LocalDateFilter;

/**
 * Criteria class for the {@link com.beroutesv.domain.TravelRoute} entity. This class is used
 * in {@link com.beroutesv.web.rest.TravelRouteResource} to receive all the possible filtering options from
 * the Http GET request parameters.
 * For example the following could be a valid request:
 * {@code /travel-routes?id.greaterThan=5&attr1.contains=something&attr2.specified=false}
 * As Spring is unable to properly convert the types, unless specific {@link Filter} class are used, we need to use
 * fix type specific filters.
 */
public class TravelRouteCriteria implements Serializable, Criteria {
    /**
     * Class for filtering Continent
     */
    public static class ContinentFilter extends Filter<Continent> {

        public ContinentFilter() {
        }

        public ContinentFilter(ContinentFilter filter) {
            super(filter);
        }

        @Override
        public ContinentFilter copy() {
            return new ContinentFilter(this);
        }

    }
    /**
     * Class for filtering Season
     */
    public static class SeasonFilter extends Filter<Season> {

        public SeasonFilter() {
        }

        public SeasonFilter(SeasonFilter filter) {
            super(filter);
        }

        @Override
        public SeasonFilter copy() {
            return new SeasonFilter(this);
        }

    }
    /**
     * Class for filtering Category
     */
    public static class CategoryFilter extends Filter<Category> {

        public CategoryFilter() {
        }

        public CategoryFilter(CategoryFilter filter) {
            super(filter);
        }

        @Override
        public CategoryFilter copy() {
            return new CategoryFilter(this);
        }

    }

    private static final long serialVersionUID = 1L;

    private LongFilter id;

    private StringFilter titleRoute;

    private StringFilter destination;

    private ContinentFilter continent;

    private IntegerFilter days;

    private IntegerFilter weeks;

    private SeasonFilter season;

    private DoubleFilter budget;

    private CategoryFilter category;

    private DoubleFilter valueAverage;

    private StringFilter descriptionRouteSummary;

    private StringFilter descriptionRoute;

    private IntegerFilter steps;

    private StringFilter summaryMap;

    private LocalDateFilter createdAt;

    private LocalDateFilter updatedAt;

    private BooleanFilter qrActivation;

    private LongFilter countryId;

    private LongFilter locationId;

    private LongFilter galeryId;

    private LongFilter valuationId;

    private LongFilter qrId;

    private LongFilter userProfileId;

    public TravelRouteCriteria() {
    }

    public TravelRouteCriteria(TravelRouteCriteria other) {
        this.id = other.id == null ? null : other.id.copy();
        this.titleRoute = other.titleRoute == null ? null : other.titleRoute.copy();
        this.destination = other.destination == null ? null : other.destination.copy();
        this.continent = other.continent == null ? null : other.continent.copy();
        this.days = other.days == null ? null : other.days.copy();
        this.weeks = other.weeks == null ? null : other.weeks.copy();
        this.season = other.season == null ? null : other.season.copy();
        this.budget = other.budget == null ? null : other.budget.copy();
        this.category = other.category == null ? null : other.category.copy();
        this.valueAverage = other.valueAverage == null ? null : other.valueAverage.copy();
        this.descriptionRouteSummary = other.descriptionRouteSummary == null ? null : other.descriptionRouteSummary.copy();
        this.descriptionRoute = other.descriptionRoute == null ? null : other.descriptionRoute.copy();
        this.steps = other.steps == null ? null : other.steps.copy();
        this.summaryMap = other.summaryMap == null ? null : other.summaryMap.copy();
        this.createdAt = other.createdAt == null ? null : other.createdAt.copy();
        this.updatedAt = other.updatedAt == null ? null : other.updatedAt.copy();
        this.qrActivation = other.qrActivation == null ? null : other.qrActivation.copy();
        this.countryId = other.countryId == null ? null : other.countryId.copy();
        this.locationId = other.locationId == null ? null : other.locationId.copy();
        this.galeryId = other.galeryId == null ? null : other.galeryId.copy();
        this.valuationId = other.valuationId == null ? null : other.valuationId.copy();
        this.qrId = other.qrId == null ? null : other.qrId.copy();
        this.userProfileId = other.userProfileId == null ? null : other.userProfileId.copy();
    }

    @Override
    public TravelRouteCriteria copy() {
        return new TravelRouteCriteria(this);
    }

    public LongFilter getId() {
        return id;
    }

    public void setId(LongFilter id) {
        this.id = id;
    }

    public StringFilter getTitleRoute() {
        return titleRoute;
    }

    public void setTitleRoute(StringFilter titleRoute) {
        this.titleRoute = titleRoute;
    }

    public StringFilter getDestination() {
        return destination;
    }

    public void setDestination(StringFilter destination) {
        this.destination = destination;
    }

    public ContinentFilter getContinent() {
        return continent;
    }

    public void setContinent(ContinentFilter continent) {
        this.continent = continent;
    }

    public IntegerFilter getDays() {
        return days;
    }

    public void setDays(IntegerFilter days) {
        this.days = days;
    }

    public IntegerFilter getWeeks() {
        return weeks;
    }

    public void setWeeks(IntegerFilter weeks) {
        this.weeks = weeks;
    }

    public SeasonFilter getSeason() {
        return season;
    }

    public void setSeason(SeasonFilter season) {
        this.season = season;
    }

    public DoubleFilter getBudget() {
        return budget;
    }

    public void setBudget(DoubleFilter budget) {
        this.budget = budget;
    }

    public CategoryFilter getCategory() {
        return category;
    }

    public void setCategory(CategoryFilter category) {
        this.category = category;
    }

    public DoubleFilter getValueAverage() {
        return valueAverage;
    }

    public void setValueAverage(DoubleFilter valueAverage) {
        this.valueAverage = valueAverage;
    }

    public StringFilter getDescriptionRouteSummary() {
        return descriptionRouteSummary;
    }

    public void setDescriptionRouteSummary(StringFilter descriptionRouteSummary) {
        this.descriptionRouteSummary = descriptionRouteSummary;
    }

    public StringFilter getDescriptionRoute() {
        return descriptionRoute;
    }

    public void setDescriptionRoute(StringFilter descriptionRoute) {
        this.descriptionRoute = descriptionRoute;
    }

    public IntegerFilter getSteps() {
        return steps;
    }

    public void setSteps(IntegerFilter steps) {
        this.steps = steps;
    }

    public StringFilter getSummaryMap() {
        return summaryMap;
    }

    public void setSummaryMap(StringFilter summaryMap) {
        this.summaryMap = summaryMap;
    }

    public LocalDateFilter getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateFilter createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateFilter getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateFilter updatedAt) {
        this.updatedAt = updatedAt;
    }

    public BooleanFilter getQrActivation() {
        return qrActivation;
    }

    public void setQrActivation(BooleanFilter qrActivation) {
        this.qrActivation = qrActivation;
    }

    public LongFilter getCountryId() {
        return countryId;
    }

    public void setCountryId(LongFilter countryId) {
        this.countryId = countryId;
    }

    public LongFilter getLocationId() {
        return locationId;
    }

    public void setLocationId(LongFilter locationId) {
        this.locationId = locationId;
    }

    public LongFilter getGaleryId() {
        return galeryId;
    }

    public void setGaleryId(LongFilter galeryId) {
        this.galeryId = galeryId;
    }

    public LongFilter getValuationId() {
        return valuationId;
    }

    public void setValuationId(LongFilter valuationId) {
        this.valuationId = valuationId;
    }

    public LongFilter getQrId() {
        return qrId;
    }

    public void setQrId(LongFilter qrId) {
        this.qrId = qrId;
    }

    public LongFilter getUserProfileId() {
        return userProfileId;
    }

    public void setUserProfileId(LongFilter userProfileId) {
        this.userProfileId = userProfileId;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        final TravelRouteCriteria that = (TravelRouteCriteria) o;
        return
            Objects.equals(id, that.id) &&
            Objects.equals(titleRoute, that.titleRoute) &&
            Objects.equals(destination, that.destination) &&
            Objects.equals(continent, that.continent) &&
            Objects.equals(days, that.days) &&
            Objects.equals(weeks, that.weeks) &&
            Objects.equals(season, that.season) &&
            Objects.equals(budget, that.budget) &&
            Objects.equals(category, that.category) &&
            Objects.equals(valueAverage, that.valueAverage) &&
            Objects.equals(descriptionRouteSummary, that.descriptionRouteSummary) &&
            Objects.equals(descriptionRoute, that.descriptionRoute) &&
            Objects.equals(steps, that.steps) &&
            Objects.equals(summaryMap, that.summaryMap) &&
            Objects.equals(createdAt, that.createdAt) &&
            Objects.equals(updatedAt, that.updatedAt) &&
            Objects.equals(qrActivation, that.qrActivation) &&
            Objects.equals(countryId, that.countryId) &&
            Objects.equals(locationId, that.locationId) &&
            Objects.equals(galeryId, that.galeryId) &&
            Objects.equals(valuationId, that.valuationId) &&
            Objects.equals(qrId, that.qrId) &&
            Objects.equals(userProfileId, that.userProfileId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(
        id,
        titleRoute,
        destination,
        continent,
        days,
        weeks,
        season,
        budget,
        category,
        valueAverage,
        descriptionRouteSummary,
        descriptionRoute,
        steps,
        summaryMap,
        createdAt,
        updatedAt,
        qrActivation,
        countryId,
        locationId,
        galeryId,
        valuationId,
        qrId,
        userProfileId
        );
    }

    @Override
    public String toString() {
        return "TravelRouteCriteria{" +
                (id != null ? "id=" + id + ", " : "") +
                (titleRoute != null ? "titleRoute=" + titleRoute + ", " : "") +
                (destination != null ? "destination=" + destination + ", " : "") +
                (continent != null ? "continent=" + continent + ", " : "") +
                (days != null ? "days=" + days + ", " : "") +
                (weeks != null ? "weeks=" + weeks + ", " : "") +
                (season != null ? "season=" + season + ", " : "") +
                (budget != null ? "budget=" + budget + ", " : "") +
                (category != null ? "category=" + category + ", " : "") +
                (valueAverage != null ? "valueAverage=" + valueAverage + ", " : "") +
                (descriptionRouteSummary != null ? "descriptionRouteSummary=" + descriptionRouteSummary + ", " : "") +
                (descriptionRoute != null ? "descriptionRoute=" + descriptionRoute + ", " : "") +
                (steps != null ? "steps=" + steps + ", " : "") +
                (summaryMap != null ? "summaryMap=" + summaryMap + ", " : "") +
                (createdAt != null ? "createdAt=" + createdAt + ", " : "") +
                (updatedAt != null ? "updatedAt=" + updatedAt + ", " : "") +
                (qrActivation != null ? "qrActivation=" + qrActivation + ", " : "") +
                (countryId != null ? "countryId=" + countryId + ", " : "") +
                (locationId != null ? "locationId=" + locationId + ", " : "") +
                (galeryId != null ? "galeryId=" + galeryId + ", " : "") +
                (valuationId != null ? "valuationId=" + valuationId + ", " : "") +
                (qrId != null ? "qrId=" + qrId + ", " : "") +
                (userProfileId != null ? "userProfileId=" + userProfileId + ", " : "") +
            "}";
    }

}
