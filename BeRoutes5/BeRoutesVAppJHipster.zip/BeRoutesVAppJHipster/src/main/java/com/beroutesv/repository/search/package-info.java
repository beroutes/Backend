/**
 * Spring Data Elasticsearch repositories.
 */
package com.beroutesv.repository.search;
