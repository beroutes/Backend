package com.beroutesv.service;

import com.beroutesv.domain.Following;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Optional;

/**
 * Service Interface for managing {@link Following}.
 */
public interface FollowingService {

    /**
     * Save a following.
     *
     * @param following the entity to save.
     * @return the persisted entity.
     */
    Following save(Following following);

    /**
     * Get all the followings.
     *
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    Page<Following> findAll(Pageable pageable);

    /**
     * Get the "id" following.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<Following> findOne(Long id);

    /**
     * Delete the "id" following.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);

    /**
     * Search for the following corresponding to the query.
     *
     * @param query the query of the search.
     * 
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    Page<Following> search(String query, Pageable pageable);
}
