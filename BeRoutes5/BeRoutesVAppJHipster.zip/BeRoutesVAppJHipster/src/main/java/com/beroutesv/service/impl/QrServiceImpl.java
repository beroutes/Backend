package com.beroutesv.service.impl;

import com.beroutesv.service.QrService;
import com.beroutesv.domain.Qr;
import com.beroutesv.repository.QrRepository;
import com.beroutesv.repository.search.QrSearchRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing {@link Qr}.
 */
@Service
@Transactional
public class QrServiceImpl implements QrService {

    private final Logger log = LoggerFactory.getLogger(QrServiceImpl.class);

    private final QrRepository qrRepository;

    private final QrSearchRepository qrSearchRepository;

    public QrServiceImpl(QrRepository qrRepository, QrSearchRepository qrSearchRepository) {
        this.qrRepository = qrRepository;
        this.qrSearchRepository = qrSearchRepository;
    }

    /**
     * Save a qr.
     *
     * @param qr the entity to save.
     * @return the persisted entity.
     */
    @Override
    public Qr save(Qr qr) {
        log.debug("Request to save Qr : {}", qr);
        Qr result = qrRepository.save(qr);
        qrSearchRepository.save(result);
        return result;
    }

    /**
     * Get all the qrs.
     *
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    @Override
    @Transactional(readOnly = true)
    public Page<Qr> findAll(Pageable pageable) {
        log.debug("Request to get all Qrs");
        return qrRepository.findAll(pageable);
    }


    /**
     *  Get all the qrs where Location is {@code null}.
     *  @return the list of entities.
     */
    @Transactional(readOnly = true) 
    public List<Qr> findAllWhereLocationIsNull() {
        log.debug("Request to get all qrs where Location is null");
        return StreamSupport
            .stream(qrRepository.findAll().spliterator(), false)
            .filter(qr -> qr.getLocation() == null)
            .collect(Collectors.toList());
    }

    /**
     * Get one qr by id.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    @Override
    @Transactional(readOnly = true)
    public Optional<Qr> findOne(Long id) {
        log.debug("Request to get Qr : {}", id);
        return qrRepository.findById(id);
    }

    /**
     * Delete the qr by id.
     *
     * @param id the id of the entity.
     */
    @Override
    public void delete(Long id) {
        log.debug("Request to delete Qr : {}", id);
        qrRepository.deleteById(id);
        qrSearchRepository.deleteById(id);
    }

    /**
     * Search for the qr corresponding to the query.
     *
     * @param query the query of the search.
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    @Override
    @Transactional(readOnly = true)
    public Page<Qr> search(String query, Pageable pageable) {
        log.debug("Request to search for a page of Qrs for query {}", query);
        return qrSearchRepository.search(queryStringQuery(query), pageable);    }
}
