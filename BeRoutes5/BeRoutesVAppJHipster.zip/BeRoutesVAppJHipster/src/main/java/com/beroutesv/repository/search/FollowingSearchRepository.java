package com.beroutesv.repository.search;

import com.beroutesv.domain.Following;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

/**
 * Spring Data Elasticsearch repository for the {@link Following} entity.
 */
public interface FollowingSearchRepository extends ElasticsearchRepository<Following, Long> {
}
