/**
 * Service layer beans.
 */
package com.beroutesv.service;
