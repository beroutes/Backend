package com.beroutesv.service;

import java.util.List;

import javax.persistence.criteria.JoinType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import io.github.jhipster.service.QueryService;

import com.beroutesv.domain.TravelRoute;
import com.beroutesv.domain.*; // for static metamodels
import com.beroutesv.repository.TravelRouteRepository;
import com.beroutesv.repository.search.TravelRouteSearchRepository;
import com.beroutesv.service.dto.TravelRouteCriteria;

/**
 * Service for executing complex queries for {@link TravelRoute} entities in the database.
 * The main input is a {@link TravelRouteCriteria} which gets converted to {@link Specification},
 * in a way that all the filters must apply.
 * It returns a {@link List} of {@link TravelRoute} or a {@link Page} of {@link TravelRoute} which fulfills the criteria.
 */
@Service
@Transactional(readOnly = true)
public class TravelRouteQueryService extends QueryService<TravelRoute> {

    private final Logger log = LoggerFactory.getLogger(TravelRouteQueryService.class);

    private final TravelRouteRepository travelRouteRepository;

    private final TravelRouteSearchRepository travelRouteSearchRepository;

    public TravelRouteQueryService(TravelRouteRepository travelRouteRepository, TravelRouteSearchRepository travelRouteSearchRepository) {
        this.travelRouteRepository = travelRouteRepository;
        this.travelRouteSearchRepository = travelRouteSearchRepository;
    }

    /**
     * Return a {@link List} of {@link TravelRoute} which matches the criteria from the database.
     * @param criteria The object which holds all the filters, which the entities should match.
     * @return the matching entities.
     */
    @Transactional(readOnly = true)
    public List<TravelRoute> findByCriteria(TravelRouteCriteria criteria) {
        log.debug("find by criteria : {}", criteria);
        final Specification<TravelRoute> specification = createSpecification(criteria);
        return travelRouteRepository.findAll(specification);
    }

    /**
     * Return a {@link Page} of {@link TravelRoute} which matches the criteria from the database.
     * @param criteria The object which holds all the filters, which the entities should match.
     * @param page The page, which should be returned.
     * @return the matching entities.
     */
    @Transactional(readOnly = true)
    public Page<TravelRoute> findByCriteria(TravelRouteCriteria criteria, Pageable page) {
        log.debug("find by criteria : {}, page: {}", criteria, page);
        final Specification<TravelRoute> specification = createSpecification(criteria);
        return travelRouteRepository.findAll(specification, page);
    }

    /**
     * Return the number of matching entities in the database.
     * @param criteria The object which holds all the filters, which the entities should match.
     * @return the number of matching entities.
     */
    @Transactional(readOnly = true)
    public long countByCriteria(TravelRouteCriteria criteria) {
        log.debug("count by criteria : {}", criteria);
        final Specification<TravelRoute> specification = createSpecification(criteria);
        return travelRouteRepository.count(specification);
    }

    /**
     * Function to convert {@link TravelRouteCriteria} to a {@link Specification}
     * @param criteria The object which holds all the filters, which the entities should match.
     * @return the matching {@link Specification} of the entity.
     */
    protected Specification<TravelRoute> createSpecification(TravelRouteCriteria criteria) {
        Specification<TravelRoute> specification = Specification.where(null);
        if (criteria != null) {
            if (criteria.getId() != null) {
                specification = specification.and(buildRangeSpecification(criteria.getId(), TravelRoute_.id));
            }
            if (criteria.getTitleRoute() != null) {
                specification = specification.and(buildStringSpecification(criteria.getTitleRoute(), TravelRoute_.titleRoute));
            }
            if (criteria.getDestination() != null) {
                specification = specification.and(buildStringSpecification(criteria.getDestination(), TravelRoute_.destination));
            }
            if (criteria.getContinent() != null) {
                specification = specification.and(buildSpecification(criteria.getContinent(), TravelRoute_.continent));
            }
            if (criteria.getDays() != null) {
                specification = specification.and(buildRangeSpecification(criteria.getDays(), TravelRoute_.days));
            }
            if (criteria.getWeeks() != null) {
                specification = specification.and(buildRangeSpecification(criteria.getWeeks(), TravelRoute_.weeks));
            }
            if (criteria.getSeason() != null) {
                specification = specification.and(buildSpecification(criteria.getSeason(), TravelRoute_.season));
            }
            if (criteria.getBudget() != null) {
                specification = specification.and(buildRangeSpecification(criteria.getBudget(), TravelRoute_.budget));
            }
            if (criteria.getCategory() != null) {
                specification = specification.and(buildSpecification(criteria.getCategory(), TravelRoute_.category));
            }
            if (criteria.getValueAverage() != null) {
                specification = specification.and(buildRangeSpecification(criteria.getValueAverage(), TravelRoute_.valueAverage));
            }
            if (criteria.getDescriptionRouteSummary() != null) {
                specification = specification.and(buildStringSpecification(criteria.getDescriptionRouteSummary(), TravelRoute_.descriptionRouteSummary));
            }
            if (criteria.getDescriptionRoute() != null) {
                specification = specification.and(buildStringSpecification(criteria.getDescriptionRoute(), TravelRoute_.descriptionRoute));
            }
            if (criteria.getSteps() != null) {
                specification = specification.and(buildRangeSpecification(criteria.getSteps(), TravelRoute_.steps));
            }
            if (criteria.getSummaryMap() != null) {
                specification = specification.and(buildStringSpecification(criteria.getSummaryMap(), TravelRoute_.summaryMap));
            }
            if (criteria.getCreatedAt() != null) {
                specification = specification.and(buildRangeSpecification(criteria.getCreatedAt(), TravelRoute_.createdAt));
            }
            if (criteria.getUpdatedAt() != null) {
                specification = specification.and(buildRangeSpecification(criteria.getUpdatedAt(), TravelRoute_.updatedAt));
            }
            if (criteria.getQrActivation() != null) {
                specification = specification.and(buildSpecification(criteria.getQrActivation(), TravelRoute_.qrActivation));
            }
            if (criteria.getCountryId() != null) {
                specification = specification.and(buildSpecification(criteria.getCountryId(),
                    root -> root.join(TravelRoute_.country, JoinType.LEFT).get(Country_.id)));
            }
            if (criteria.getLocationId() != null) {
                specification = specification.and(buildSpecification(criteria.getLocationId(),
                    root -> root.join(TravelRoute_.locations, JoinType.LEFT).get(Location_.id)));
            }
            if (criteria.getGaleryId() != null) {
                specification = specification.and(buildSpecification(criteria.getGaleryId(),
                    root -> root.join(TravelRoute_.galeries, JoinType.LEFT).get(Photo_.id)));
            }
            if (criteria.getValuationId() != null) {
                specification = specification.and(buildSpecification(criteria.getValuationId(),
                    root -> root.join(TravelRoute_.valuations, JoinType.LEFT).get(Valuation_.id)));
            }
            if (criteria.getQrId() != null) {
                specification = specification.and(buildSpecification(criteria.getQrId(),
                    root -> root.join(TravelRoute_.qrs, JoinType.LEFT).get(Qr_.id)));
            }
            if (criteria.getUserProfileId() != null) {
                specification = specification.and(buildSpecification(criteria.getUserProfileId(),
                    root -> root.join(TravelRoute_.userProfile, JoinType.LEFT).get(UserProfile_.id)));
            }
        }
        return specification;
    }
}
