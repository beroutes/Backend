/**
 * JPA domain objects.
 */
package com.beroutesv.domain;
