package com.beroutesv.repository.search;

import com.beroutesv.domain.Valuation;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

/**
 * Spring Data Elasticsearch repository for the {@link Valuation} entity.
 */
public interface ValuationSearchRepository extends ElasticsearchRepository<Valuation, Long> {
}
