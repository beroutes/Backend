package com.beroutesv.repository.search;

import com.beroutesv.domain.TravelRoute;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

/**
 * Spring Data Elasticsearch repository for the {@link TravelRoute} entity.
 */
public interface TravelRouteSearchRepository extends ElasticsearchRepository<TravelRoute, Long> {
}
