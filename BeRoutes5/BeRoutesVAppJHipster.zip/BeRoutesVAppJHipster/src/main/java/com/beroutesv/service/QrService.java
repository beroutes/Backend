package com.beroutesv.service;

import com.beroutesv.domain.Qr;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing {@link Qr}.
 */
public interface QrService {

    /**
     * Save a qr.
     *
     * @param qr the entity to save.
     * @return the persisted entity.
     */
    Qr save(Qr qr);

    /**
     * Get all the qrs.
     *
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    Page<Qr> findAll(Pageable pageable);
    /**
     * Get all the QrDTO where Location is {@code null}.
     *
     * @return the list of entities.
     */
    List<Qr> findAllWhereLocationIsNull();

    /**
     * Get the "id" qr.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<Qr> findOne(Long id);

    /**
     * Delete the "id" qr.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);

    /**
     * Search for the qr corresponding to the query.
     *
     * @param query the query of the search.
     * 
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    Page<Qr> search(String query, Pageable pageable);
}
