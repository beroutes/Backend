package com.beroutesv.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;

import org.springframework.data.elasticsearch.annotations.FieldType;
import java.io.Serializable;
import java.util.Objects;

/**
 * A Following.
 */
@Entity
@Table(name = "following")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@org.springframework.data.elasticsearch.annotations.Document(indexName = "following")
public class Following implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "follow")
    private Boolean follow;

    @Column(name = "accepted")
    private Boolean accepted;

    @Column(name = "user_follower")
    private Integer userFollower;

    @Column(name = "user_followed")
    private Integer userFollowed;

    @ManyToOne
    @JsonIgnoreProperties("followings")
    private UserProfile userProfile;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Boolean isFollow() {
        return follow;
    }

    public Following follow(Boolean follow) {
        this.follow = follow;
        return this;
    }

    public void setFollow(Boolean follow) {
        this.follow = follow;
    }

    public Boolean isAccepted() {
        return accepted;
    }

    public Following accepted(Boolean accepted) {
        this.accepted = accepted;
        return this;
    }

    public void setAccepted(Boolean accepted) {
        this.accepted = accepted;
    }

    public Integer getUserFollower() {
        return userFollower;
    }

    public Following userFollower(Integer userFollower) {
        this.userFollower = userFollower;
        return this;
    }

    public void setUserFollower(Integer userFollower) {
        this.userFollower = userFollower;
    }

    public Integer getUserFollowed() {
        return userFollowed;
    }

    public Following userFollowed(Integer userFollowed) {
        this.userFollowed = userFollowed;
        return this;
    }

    public void setUserFollowed(Integer userFollowed) {
        this.userFollowed = userFollowed;
    }

    public UserProfile getUserProfile() {
        return userProfile;
    }

    public Following userProfile(UserProfile userProfile) {
        this.userProfile = userProfile;
        return this;
    }

    public void setUserProfile(UserProfile userProfile) {
        this.userProfile = userProfile;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Following)) {
            return false;
        }
        return id != null && id.equals(((Following) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "Following{" +
            "id=" + getId() +
            ", follow='" + isFollow() + "'" +
            ", accepted='" + isAccepted() + "'" +
            ", userFollower=" + getUserFollower() +
            ", userFollowed=" + getUserFollowed() +
            "}";
    }
}
